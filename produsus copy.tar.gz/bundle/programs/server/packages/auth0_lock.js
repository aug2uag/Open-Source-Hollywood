(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var Accounts = Package['accounts-base'].Accounts;
var _ = Package.underscore._;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

var require = meteorInstall({"node_modules":{"meteor":{"auth0:lock":{"auth0-lock.server.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/auth0_lock/auth0-lock.server.js                                                                         //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
if (Meteor.isServer) {                                                                                              // 1
    // Calculate the absolute path for the app                                                                      //
    var _getAppPath = function _getAppPath() {                                                                      // 3
        // On Windows the tokenizer must include a backslash                                                        //
        if (process.platform === 'win32' || process.platform === 'win64') {                                         // 5
            return __meteor_bootstrap__.serverDir.split('\\.meteor')[0] + '\\';                                     // 6
        }                                                                                                           //
        return __meteor_bootstrap__.serverDir.split('/.meteor')[0] + '/';                                           // 8
    };                                                                                                              //
                                                                                                                    //
    // Register the Auth0 login handler for Meteor.                                                                 //
    Accounts.registerLoginHandler(function (options) {                                                              // 1
        if (!options.auth0) return undefined; // Do not handle                                                      // 13
                                                                                                                    //
        if (!_.contains(Accounts.oauth.serviceNames(), 'auth0')) {                                                  // 12
            // If the auth0 service was removed from serviceConfiguration                                           //
            return {                                                                                                // 18
                type: "auth0",                                                                                      // 19
                error: new Meteor.Error(Accounts.LoginCancelledError.numericError, "No registered oauth service found for: Auth0")
            };                                                                                                      //
        }                                                                                                           //
                                                                                                                    //
        // Do nothing if the profile is not received.                                                               //
        if (!options.auth0.profile || !options.auth0.profile.user_id) return null;                                  // 12
                                                                                                                    //
        // Accounts.updateOrCreateUserFromExternalService                                                           //
        // expects the unique user id to be stored in the 'id'                                                      //
        // property of serviceData.                                                                                 //
        options.auth0.profile.id = options.auth0.profile.user_id;                                                   // 12
                                                                                                                    //
        // Run the Accounts method to store the profile and                                                         //
        // optional data (token) in Meteor users collection.                                                        //
        return Accounts.updateOrCreateUserFromExternalService("auth0", options.auth0.profile, options.auth0.token);
    });                                                                                                             //
                                                                                                                    //
    // Send the user details to the client. Complete profile when logged in user,                                   //
    // only id and name to all other users. This data is stored in the local users collection.                      //
    // It is created or updated locally when logging in.                                                            //
    Accounts.addAutopublishFields({                                                                                 // 1
        forLoggedInUser: ['services.auth0'],                                                                        // 44
        forOtherUsers: ['services.auth0.id', 'services.auth0.name']                                                 // 45
    });                                                                                                             //
                                                                                                                    //
    // Publish server methods                                                                                       //
    Meteor.methods({                                                                                                // 1
        // Sends the Auth0 account attributes to the client upon request.                                           //
        // Gets called from the Meteor.startup function on the client.                                              //
        'getAuth0Attributes': function () {                                                                         // 54
            function getAuth0Attributes() {                                                                         // 54
                return {                                                                                            // 55
                    AUTH0_CLIENTID: Meteor.settings['private'].AUTH0_CLIENT_ID,                                     // 56
                    AUTH0_DOMAIN: Meteor.settings['private'].AUTH0_DOMAIN                                           // 57
                };                                                                                                  //
            }                                                                                                       //
                                                                                                                    //
            return getAuth0Attributes;                                                                              //
        }()                                                                                                         //
    });                                                                                                             //
}                                                                                                                   //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"auth0-lock.common.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/auth0_lock/auth0-lock.common.js                                                                         //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
Accounts.oauth.registerService('auth0');                                                                            // 1
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{"extensions":[".js",".json"]});
require("./node_modules/meteor/auth0:lock/auth0-lock.server.js");
require("./node_modules/meteor/auth0:lock/auth0-lock.common.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['auth0:lock'] = {};

})();

//# sourceMappingURL=auth0_lock.js.map
