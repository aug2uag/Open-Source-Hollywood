(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;

/* Package-scope variables */
var exports, module, marked;

(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                              //
// packages/chuangbo_marked/packages/chuangbo_marked.js                                         //
//                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                //
(function () {

//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// packages/chuangbo:marked/pre-marked.js                                               //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //
exports = {};                                                                           // 1
module = {};                                                                            // 2
//////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// packages/chuangbo:marked/marked/lib/marked.js                                        //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //
/**                                                                                     // 1
 * marked - a markdown parser                                                           // 2
 * Copyright (c) 2011-2014, Christopher Jeffrey. (MIT Licensed)                         // 3
 * https://github.com/chjj/marked                                                       // 4
 */                                                                                     // 5
                                                                                        // 6
;(function() {                                                                          // 7
                                                                                        // 8
/**                                                                                     // 9
 * Block-Level Grammar                                                                  // 10
 */                                                                                     // 11
                                                                                        // 12
var block = {                                                                           // 13
  newline: /^\n+/,                                                                      // 14
  code: /^( {4}[^\n]+\n*)+/,                                                            // 15
  fences: noop,                                                                         // 16
  hr: /^( *[-*_]){3,} *(?:\n+|$)/,                                                      // 17
  heading: /^ *(#{1,6}) *([^\n]+?) *#* *(?:\n+|$)/,                                     // 18
  nptable: noop,                                                                        // 19
  lheading: /^([^\n]+)\n *(=|-){2,} *(?:\n+|$)/,                                        // 20
  blockquote: /^( *>[^\n]+(\n(?!def)[^\n]+)*\n*)+/,                                     // 21
  list: /^( *)(bull) [\s\S]+?(?:hr|def|\n{2,}(?! )(?!\1bull )\n*|\s*$)/,                // 22
  html: /^ *(?:comment *(?:\n|\s*$)|closed *(?:\n{2,}|\s*$)|closing *(?:\n{2,}|\s*$))/, // 23
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +["(]([^\n]+)[")])? *(?:\n+|$)/,             // 24
  table: noop,                                                                          // 25
  paragraph: /^((?:[^\n]+\n?(?!hr|heading|lheading|blockquote|tag|def))+)\n*/,          // 26
  text: /^[^\n]+/                                                                       // 27
};                                                                                      // 28
                                                                                        // 29
block.bullet = /(?:[*+-]|\d+\.)/;                                                       // 30
block.item = /^( *)(bull) [^\n]*(?:\n(?!\1bull )[^\n]*)*/;                              // 31
block.item = replace(block.item, 'gm')                                                  // 32
  (/bull/g, block.bullet)                                                               // 33
  ();                                                                                   // 34
                                                                                        // 35
block.list = replace(block.list)                                                        // 36
  (/bull/g, block.bullet)                                                               // 37
  ('hr', '\\n+(?=\\1?(?:[-*_] *){3,}(?:\\n+|$))')                                       // 38
  ('def', '\\n+(?=' + block.def.source + ')')                                           // 39
  ();                                                                                   // 40
                                                                                        // 41
block.blockquote = replace(block.blockquote)                                            // 42
  ('def', block.def)                                                                    // 43
  ();                                                                                   // 44
                                                                                        // 45
block._tag = '(?!(?:'                                                                   // 46
  + 'a|em|strong|small|s|cite|q|dfn|abbr|data|time|code'                                // 47
  + '|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo'                               // 48
  + '|span|br|wbr|ins|del|img)\\b)\\w+(?!:/|[^\\w\\s@]*@)\\b';                          // 49
                                                                                        // 50
block.html = replace(block.html)                                                        // 51
  ('comment', /<!--[\s\S]*?-->/)                                                        // 52
  ('closed', /<(tag)[\s\S]+?<\/\1>/)                                                    // 53
  ('closing', /<tag(?:"[^"]*"|'[^']*'|[^'">])*?>/)                                      // 54
  (/tag/g, block._tag)                                                                  // 55
  ();                                                                                   // 56
                                                                                        // 57
block.paragraph = replace(block.paragraph)                                              // 58
  ('hr', block.hr)                                                                      // 59
  ('heading', block.heading)                                                            // 60
  ('lheading', block.lheading)                                                          // 61
  ('blockquote', block.blockquote)                                                      // 62
  ('tag', '<' + block._tag)                                                             // 63
  ('def', block.def)                                                                    // 64
  ();                                                                                   // 65
                                                                                        // 66
/**                                                                                     // 67
 * Normal Block Grammar                                                                 // 68
 */                                                                                     // 69
                                                                                        // 70
block.normal = merge({}, block);                                                        // 71
                                                                                        // 72
/**                                                                                     // 73
 * GFM Block Grammar                                                                    // 74
 */                                                                                     // 75
                                                                                        // 76
block.gfm = merge({}, block.normal, {                                                   // 77
  fences: /^ *(`{3,}|~{3,})[ \.]*(\S+)? *\n([\s\S]*?)\s*\1 *(?:\n+|$)/,                 // 78
  paragraph: /^/,                                                                       // 79
  heading: /^ *(#{1,6}) +([^\n]+?) *#* *(?:\n+|$)/                                      // 80
});                                                                                     // 81
                                                                                        // 82
block.gfm.paragraph = replace(block.paragraph)                                          // 83
  ('(?!', '(?!'                                                                         // 84
    + block.gfm.fences.source.replace('\\1', '\\2') + '|'                               // 85
    + block.list.source.replace('\\1', '\\3') + '|')                                    // 86
  ();                                                                                   // 87
                                                                                        // 88
/**                                                                                     // 89
 * GFM + Tables Block Grammar                                                           // 90
 */                                                                                     // 91
                                                                                        // 92
block.tables = merge({}, block.gfm, {                                                   // 93
  nptable: /^ *(\S.*\|.*)\n *([-:]+ *\|[-| :]*)\n((?:.*\|.*(?:\n|$))*)\n*/,             // 94
  table: /^ *\|(.+)\n *\|( *[-:]+[-| :]*)\n((?: *\|.*(?:\n|$))*)\n*/                    // 95
});                                                                                     // 96
                                                                                        // 97
/**                                                                                     // 98
 * Block Lexer                                                                          // 99
 */                                                                                     // 100
                                                                                        // 101
function Lexer(options) {                                                               // 102
  this.tokens = [];                                                                     // 103
  this.tokens.links = {};                                                               // 104
  this.options = options || marked.defaults;                                            // 105
  this.rules = block.normal;                                                            // 106
                                                                                        // 107
  if (this.options.gfm) {                                                               // 108
    if (this.options.tables) {                                                          // 109
      this.rules = block.tables;                                                        // 110
    } else {                                                                            // 111
      this.rules = block.gfm;                                                           // 112
    }                                                                                   // 113
  }                                                                                     // 114
}                                                                                       // 115
                                                                                        // 116
/**                                                                                     // 117
 * Expose Block Rules                                                                   // 118
 */                                                                                     // 119
                                                                                        // 120
Lexer.rules = block;                                                                    // 121
                                                                                        // 122
/**                                                                                     // 123
 * Static Lex Method                                                                    // 124
 */                                                                                     // 125
                                                                                        // 126
Lexer.lex = function(src, options) {                                                    // 127
  var lexer = new Lexer(options);                                                       // 128
  return lexer.lex(src);                                                                // 129
};                                                                                      // 130
                                                                                        // 131
/**                                                                                     // 132
 * Preprocessing                                                                        // 133
 */                                                                                     // 134
                                                                                        // 135
Lexer.prototype.lex = function(src) {                                                   // 136
  src = src                                                                             // 137
    .replace(/\r\n|\r/g, '\n')                                                          // 138
    .replace(/\t/g, '    ')                                                             // 139
    .replace(/\u00a0/g, ' ')                                                            // 140
    .replace(/\u2424/g, '\n');                                                          // 141
                                                                                        // 142
  return this.token(src, true);                                                         // 143
};                                                                                      // 144
                                                                                        // 145
/**                                                                                     // 146
 * Lexing                                                                               // 147
 */                                                                                     // 148
                                                                                        // 149
Lexer.prototype.token = function(src, top, bq) {                                        // 150
  var src = src.replace(/^ +$/gm, '')                                                   // 151
    , next                                                                              // 152
    , loose                                                                             // 153
    , cap                                                                               // 154
    , bull                                                                              // 155
    , b                                                                                 // 156
    , item                                                                              // 157
    , space                                                                             // 158
    , i                                                                                 // 159
    , l;                                                                                // 160
                                                                                        // 161
  while (src) {                                                                         // 162
    // newline                                                                          // 163
    if (cap = this.rules.newline.exec(src)) {                                           // 164
      src = src.substring(cap[0].length);                                               // 165
      if (cap[0].length > 1) {                                                          // 166
        this.tokens.push({                                                              // 167
          type: 'space'                                                                 // 168
        });                                                                             // 169
      }                                                                                 // 170
    }                                                                                   // 171
                                                                                        // 172
    // code                                                                             // 173
    if (cap = this.rules.code.exec(src)) {                                              // 174
      src = src.substring(cap[0].length);                                               // 175
      cap = cap[0].replace(/^ {4}/gm, '');                                              // 176
      this.tokens.push({                                                                // 177
        type: 'code',                                                                   // 178
        text: !this.options.pedantic                                                    // 179
          ? cap.replace(/\n+$/, '')                                                     // 180
          : cap                                                                         // 181
      });                                                                               // 182
      continue;                                                                         // 183
    }                                                                                   // 184
                                                                                        // 185
    // fences (gfm)                                                                     // 186
    if (cap = this.rules.fences.exec(src)) {                                            // 187
      src = src.substring(cap[0].length);                                               // 188
      this.tokens.push({                                                                // 189
        type: 'code',                                                                   // 190
        lang: cap[2],                                                                   // 191
        text: cap[3] || ''                                                              // 192
      });                                                                               // 193
      continue;                                                                         // 194
    }                                                                                   // 195
                                                                                        // 196
    // heading                                                                          // 197
    if (cap = this.rules.heading.exec(src)) {                                           // 198
      src = src.substring(cap[0].length);                                               // 199
      this.tokens.push({                                                                // 200
        type: 'heading',                                                                // 201
        depth: cap[1].length,                                                           // 202
        text: cap[2]                                                                    // 203
      });                                                                               // 204
      continue;                                                                         // 205
    }                                                                                   // 206
                                                                                        // 207
    // table no leading pipe (gfm)                                                      // 208
    if (top && (cap = this.rules.nptable.exec(src))) {                                  // 209
      src = src.substring(cap[0].length);                                               // 210
                                                                                        // 211
      item = {                                                                          // 212
        type: 'table',                                                                  // 213
        header: cap[1].replace(/^ *| *\| *$/g, '').split(/ *\| */),                     // 214
        align: cap[2].replace(/^ *|\| *$/g, '').split(/ *\| */),                        // 215
        cells: cap[3].replace(/\n$/, '').split('\n')                                    // 216
      };                                                                                // 217
                                                                                        // 218
      for (i = 0; i < item.align.length; i++) {                                         // 219
        if (/^ *-+: *$/.test(item.align[i])) {                                          // 220
          item.align[i] = 'right';                                                      // 221
        } else if (/^ *:-+: *$/.test(item.align[i])) {                                  // 222
          item.align[i] = 'center';                                                     // 223
        } else if (/^ *:-+ *$/.test(item.align[i])) {                                   // 224
          item.align[i] = 'left';                                                       // 225
        } else {                                                                        // 226
          item.align[i] = null;                                                         // 227
        }                                                                               // 228
      }                                                                                 // 229
                                                                                        // 230
      for (i = 0; i < item.cells.length; i++) {                                         // 231
        item.cells[i] = item.cells[i].split(/ *\| */);                                  // 232
      }                                                                                 // 233
                                                                                        // 234
      this.tokens.push(item);                                                           // 235
                                                                                        // 236
      continue;                                                                         // 237
    }                                                                                   // 238
                                                                                        // 239
    // lheading                                                                         // 240
    if (cap = this.rules.lheading.exec(src)) {                                          // 241
      src = src.substring(cap[0].length);                                               // 242
      this.tokens.push({                                                                // 243
        type: 'heading',                                                                // 244
        depth: cap[2] === '=' ? 1 : 2,                                                  // 245
        text: cap[1]                                                                    // 246
      });                                                                               // 247
      continue;                                                                         // 248
    }                                                                                   // 249
                                                                                        // 250
    // hr                                                                               // 251
    if (cap = this.rules.hr.exec(src)) {                                                // 252
      src = src.substring(cap[0].length);                                               // 253
      this.tokens.push({                                                                // 254
        type: 'hr'                                                                      // 255
      });                                                                               // 256
      continue;                                                                         // 257
    }                                                                                   // 258
                                                                                        // 259
    // blockquote                                                                       // 260
    if (cap = this.rules.blockquote.exec(src)) {                                        // 261
      src = src.substring(cap[0].length);                                               // 262
                                                                                        // 263
      this.tokens.push({                                                                // 264
        type: 'blockquote_start'                                                        // 265
      });                                                                               // 266
                                                                                        // 267
      cap = cap[0].replace(/^ *> ?/gm, '');                                             // 268
                                                                                        // 269
      // Pass `top` to keep the current                                                 // 270
      // "toplevel" state. This is exactly                                              // 271
      // how markdown.pl works.                                                         // 272
      this.token(cap, top, true);                                                       // 273
                                                                                        // 274
      this.tokens.push({                                                                // 275
        type: 'blockquote_end'                                                          // 276
      });                                                                               // 277
                                                                                        // 278
      continue;                                                                         // 279
    }                                                                                   // 280
                                                                                        // 281
    // list                                                                             // 282
    if (cap = this.rules.list.exec(src)) {                                              // 283
      src = src.substring(cap[0].length);                                               // 284
      bull = cap[2];                                                                    // 285
                                                                                        // 286
      this.tokens.push({                                                                // 287
        type: 'list_start',                                                             // 288
        ordered: bull.length > 1                                                        // 289
      });                                                                               // 290
                                                                                        // 291
      // Get each top-level item.                                                       // 292
      cap = cap[0].match(this.rules.item);                                              // 293
                                                                                        // 294
      next = false;                                                                     // 295
      l = cap.length;                                                                   // 296
      i = 0;                                                                            // 297
                                                                                        // 298
      for (; i < l; i++) {                                                              // 299
        item = cap[i];                                                                  // 300
                                                                                        // 301
        // Remove the list item's bullet                                                // 302
        // so it is seen as the next token.                                             // 303
        space = item.length;                                                            // 304
        item = item.replace(/^ *([*+-]|\d+\.) +/, '');                                  // 305
                                                                                        // 306
        // Outdent whatever the                                                         // 307
        // list item contains. Hacky.                                                   // 308
        if (~item.indexOf('\n ')) {                                                     // 309
          space -= item.length;                                                         // 310
          item = !this.options.pedantic                                                 // 311
            ? item.replace(new RegExp('^ {1,' + space + '}', 'gm'), '')                 // 312
            : item.replace(/^ {1,4}/gm, '');                                            // 313
        }                                                                               // 314
                                                                                        // 315
        // Determine whether the next list item belongs here.                           // 316
        // Backpedal if it does not belong in this list.                                // 317
        if (this.options.smartLists && i !== l - 1) {                                   // 318
          b = block.bullet.exec(cap[i + 1])[0];                                         // 319
          if (bull !== b && !(bull.length > 1 && b.length > 1)) {                       // 320
            src = cap.slice(i + 1).join('\n') + src;                                    // 321
            i = l - 1;                                                                  // 322
          }                                                                             // 323
        }                                                                               // 324
                                                                                        // 325
        // Determine whether item is loose or not.                                      // 326
        // Use: /(^|\n)(?! )[^\n]+\n\n(?!\s*$)/                                         // 327
        // for discount behavior.                                                       // 328
        loose = next || /\n\n(?!\s*$)/.test(item);                                      // 329
        if (i !== l - 1) {                                                              // 330
          next = item.charAt(item.length - 1) === '\n';                                 // 331
          if (!loose) loose = next;                                                     // 332
        }                                                                               // 333
                                                                                        // 334
        this.tokens.push({                                                              // 335
          type: loose                                                                   // 336
            ? 'loose_item_start'                                                        // 337
            : 'list_item_start'                                                         // 338
        });                                                                             // 339
                                                                                        // 340
        // Recurse.                                                                     // 341
        this.token(item, false, bq);                                                    // 342
                                                                                        // 343
        this.tokens.push({                                                              // 344
          type: 'list_item_end'                                                         // 345
        });                                                                             // 346
      }                                                                                 // 347
                                                                                        // 348
      this.tokens.push({                                                                // 349
        type: 'list_end'                                                                // 350
      });                                                                               // 351
                                                                                        // 352
      continue;                                                                         // 353
    }                                                                                   // 354
                                                                                        // 355
    // html                                                                             // 356
    if (cap = this.rules.html.exec(src)) {                                              // 357
      src = src.substring(cap[0].length);                                               // 358
      this.tokens.push({                                                                // 359
        type: this.options.sanitize                                                     // 360
          ? 'paragraph'                                                                 // 361
          : 'html',                                                                     // 362
        pre: !this.options.sanitizer                                                    // 363
          && (cap[1] === 'pre' || cap[1] === 'script' || cap[1] === 'style'),           // 364
        text: cap[0]                                                                    // 365
      });                                                                               // 366
      continue;                                                                         // 367
    }                                                                                   // 368
                                                                                        // 369
    // def                                                                              // 370
    if ((!bq && top) && (cap = this.rules.def.exec(src))) {                             // 371
      src = src.substring(cap[0].length);                                               // 372
      this.tokens.links[cap[1].toLowerCase()] = {                                       // 373
        href: cap[2],                                                                   // 374
        title: cap[3]                                                                   // 375
      };                                                                                // 376
      continue;                                                                         // 377
    }                                                                                   // 378
                                                                                        // 379
    // table (gfm)                                                                      // 380
    if (top && (cap = this.rules.table.exec(src))) {                                    // 381
      src = src.substring(cap[0].length);                                               // 382
                                                                                        // 383
      item = {                                                                          // 384
        type: 'table',                                                                  // 385
        header: cap[1].replace(/^ *| *\| *$/g, '').split(/ *\| */),                     // 386
        align: cap[2].replace(/^ *|\| *$/g, '').split(/ *\| */),                        // 387
        cells: cap[3].replace(/(?: *\| *)?\n$/, '').split('\n')                         // 388
      };                                                                                // 389
                                                                                        // 390
      for (i = 0; i < item.align.length; i++) {                                         // 391
        if (/^ *-+: *$/.test(item.align[i])) {                                          // 392
          item.align[i] = 'right';                                                      // 393
        } else if (/^ *:-+: *$/.test(item.align[i])) {                                  // 394
          item.align[i] = 'center';                                                     // 395
        } else if (/^ *:-+ *$/.test(item.align[i])) {                                   // 396
          item.align[i] = 'left';                                                       // 397
        } else {                                                                        // 398
          item.align[i] = null;                                                         // 399
        }                                                                               // 400
      }                                                                                 // 401
                                                                                        // 402
      for (i = 0; i < item.cells.length; i++) {                                         // 403
        item.cells[i] = item.cells[i]                                                   // 404
          .replace(/^ *\| *| *\| *$/g, '')                                              // 405
          .split(/ *\| */);                                                             // 406
      }                                                                                 // 407
                                                                                        // 408
      this.tokens.push(item);                                                           // 409
                                                                                        // 410
      continue;                                                                         // 411
    }                                                                                   // 412
                                                                                        // 413
    // top-level paragraph                                                              // 414
    if (top && (cap = this.rules.paragraph.exec(src))) {                                // 415
      src = src.substring(cap[0].length);                                               // 416
      this.tokens.push({                                                                // 417
        type: 'paragraph',                                                              // 418
        text: cap[1].charAt(cap[1].length - 1) === '\n'                                 // 419
          ? cap[1].slice(0, -1)                                                         // 420
          : cap[1]                                                                      // 421
      });                                                                               // 422
      continue;                                                                         // 423
    }                                                                                   // 424
                                                                                        // 425
    // text                                                                             // 426
    if (cap = this.rules.text.exec(src)) {                                              // 427
      // Top-level should never reach here.                                             // 428
      src = src.substring(cap[0].length);                                               // 429
      this.tokens.push({                                                                // 430
        type: 'text',                                                                   // 431
        text: cap[0]                                                                    // 432
      });                                                                               // 433
      continue;                                                                         // 434
    }                                                                                   // 435
                                                                                        // 436
    if (src) {                                                                          // 437
      throw new                                                                         // 438
        Error('Infinite loop on byte: ' + src.charCodeAt(0));                           // 439
    }                                                                                   // 440
  }                                                                                     // 441
                                                                                        // 442
  return this.tokens;                                                                   // 443
};                                                                                      // 444
                                                                                        // 445
/**                                                                                     // 446
 * Inline-Level Grammar                                                                 // 447
 */                                                                                     // 448
                                                                                        // 449
var inline = {                                                                          // 450
  escape: /^\\([\\`*{}\[\]()#+\-.!_>])/,                                                // 451
  autolink: /^<([^ >]+(@|:\/)[^ >]+)>/,                                                 // 452
  url: noop,                                                                            // 453
  tag: /^<!--[\s\S]*?-->|^<\/?\w+(?:"[^"]*"|'[^']*'|[^'">])*?>/,                        // 454
  link: /^!?\[(inside)\]\(href\)/,                                                      // 455
  reflink: /^!?\[(inside)\]\s*\[([^\]]*)\]/,                                            // 456
  nolink: /^!?\[((?:\[[^\]]*\]|[^\[\]])*)\]/,                                           // 457
  strong: /^__([\s\S]+?)__(?!_)|^\*\*([\s\S]+?)\*\*(?!\*)/,                             // 458
  em: /^\b_((?:[^_]|__)+?)_\b|^\*((?:\*\*|[\s\S])+?)\*(?!\*)/,                          // 459
  code: /^(`+)\s*([\s\S]*?[^`])\s*\1(?!`)/,                                             // 460
  br: /^ {2,}\n(?!\s*$)/,                                                               // 461
  del: noop,                                                                            // 462
  text: /^[\s\S]+?(?=[\\<!\[_*`]| {2,}\n|$)/                                            // 463
};                                                                                      // 464
                                                                                        // 465
inline._inside = /(?:\[[^\]]*\]|[^\[\]]|\](?=[^\[]*\]))*/;                              // 466
inline._href = /\s*<?([\s\S]*?)>?(?:\s+['"]([\s\S]*?)['"])?\s*/;                        // 467
                                                                                        // 468
inline.link = replace(inline.link)                                                      // 469
  ('inside', inline._inside)                                                            // 470
  ('href', inline._href)                                                                // 471
  ();                                                                                   // 472
                                                                                        // 473
inline.reflink = replace(inline.reflink)                                                // 474
  ('inside', inline._inside)                                                            // 475
  ();                                                                                   // 476
                                                                                        // 477
/**                                                                                     // 478
 * Normal Inline Grammar                                                                // 479
 */                                                                                     // 480
                                                                                        // 481
inline.normal = merge({}, inline);                                                      // 482
                                                                                        // 483
/**                                                                                     // 484
 * Pedantic Inline Grammar                                                              // 485
 */                                                                                     // 486
                                                                                        // 487
inline.pedantic = merge({}, inline.normal, {                                            // 488
  strong: /^__(?=\S)([\s\S]*?\S)__(?!_)|^\*\*(?=\S)([\s\S]*?\S)\*\*(?!\*)/,             // 489
  em: /^_(?=\S)([\s\S]*?\S)_(?!_)|^\*(?=\S)([\s\S]*?\S)\*(?!\*)/                        // 490
});                                                                                     // 491
                                                                                        // 492
/**                                                                                     // 493
 * GFM Inline Grammar                                                                   // 494
 */                                                                                     // 495
                                                                                        // 496
inline.gfm = merge({}, inline.normal, {                                                 // 497
  escape: replace(inline.escape)('])', '~|])')(),                                       // 498
  url: /^(https?:\/\/[^\s<]+[^<.,:;"')\]\s])/,                                          // 499
  del: /^~~(?=\S)([\s\S]*?\S)~~/,                                                       // 500
  text: replace(inline.text)                                                            // 501
    (']|', '~]|')                                                                       // 502
    ('|', '|https?://|')                                                                // 503
    ()                                                                                  // 504
});                                                                                     // 505
                                                                                        // 506
/**                                                                                     // 507
 * GFM + Line Breaks Inline Grammar                                                     // 508
 */                                                                                     // 509
                                                                                        // 510
inline.breaks = merge({}, inline.gfm, {                                                 // 511
  br: replace(inline.br)('{2,}', '*')(),                                                // 512
  text: replace(inline.gfm.text)('{2,}', '*')()                                         // 513
});                                                                                     // 514
                                                                                        // 515
/**                                                                                     // 516
 * Inline Lexer & Compiler                                                              // 517
 */                                                                                     // 518
                                                                                        // 519
function InlineLexer(links, options) {                                                  // 520
  this.options = options || marked.defaults;                                            // 521
  this.links = links;                                                                   // 522
  this.rules = inline.normal;                                                           // 523
  this.renderer = this.options.renderer || new Renderer;                                // 524
  this.renderer.options = this.options;                                                 // 525
                                                                                        // 526
  if (!this.links) {                                                                    // 527
    throw new                                                                           // 528
      Error('Tokens array requires a `links` property.');                               // 529
  }                                                                                     // 530
                                                                                        // 531
  if (this.options.gfm) {                                                               // 532
    if (this.options.breaks) {                                                          // 533
      this.rules = inline.breaks;                                                       // 534
    } else {                                                                            // 535
      this.rules = inline.gfm;                                                          // 536
    }                                                                                   // 537
  } else if (this.options.pedantic) {                                                   // 538
    this.rules = inline.pedantic;                                                       // 539
  }                                                                                     // 540
}                                                                                       // 541
                                                                                        // 542
/**                                                                                     // 543
 * Expose Inline Rules                                                                  // 544
 */                                                                                     // 545
                                                                                        // 546
InlineLexer.rules = inline;                                                             // 547
                                                                                        // 548
/**                                                                                     // 549
 * Static Lexing/Compiling Method                                                       // 550
 */                                                                                     // 551
                                                                                        // 552
InlineLexer.output = function(src, links, options) {                                    // 553
  var inline = new InlineLexer(links, options);                                         // 554
  return inline.output(src);                                                            // 555
};                                                                                      // 556
                                                                                        // 557
/**                                                                                     // 558
 * Lexing/Compiling                                                                     // 559
 */                                                                                     // 560
                                                                                        // 561
InlineLexer.prototype.output = function(src) {                                          // 562
  var out = ''                                                                          // 563
    , link                                                                              // 564
    , text                                                                              // 565
    , href                                                                              // 566
    , cap;                                                                              // 567
                                                                                        // 568
  while (src) {                                                                         // 569
    // escape                                                                           // 570
    if (cap = this.rules.escape.exec(src)) {                                            // 571
      src = src.substring(cap[0].length);                                               // 572
      out += cap[1];                                                                    // 573
      continue;                                                                         // 574
    }                                                                                   // 575
                                                                                        // 576
    // autolink                                                                         // 577
    if (cap = this.rules.autolink.exec(src)) {                                          // 578
      src = src.substring(cap[0].length);                                               // 579
      if (cap[2] === '@') {                                                             // 580
        text = cap[1].charAt(6) === ':'                                                 // 581
          ? this.mangle(cap[1].substring(7))                                            // 582
          : this.mangle(cap[1]);                                                        // 583
        href = this.mangle('mailto:') + text;                                           // 584
      } else {                                                                          // 585
        text = escape(cap[1]);                                                          // 586
        href = text;                                                                    // 587
      }                                                                                 // 588
      out += this.renderer.link(href, null, text);                                      // 589
      continue;                                                                         // 590
    }                                                                                   // 591
                                                                                        // 592
    // url (gfm)                                                                        // 593
    if (!this.inLink && (cap = this.rules.url.exec(src))) {                             // 594
      src = src.substring(cap[0].length);                                               // 595
      text = escape(cap[1]);                                                            // 596
      href = text;                                                                      // 597
      out += this.renderer.link(href, null, text);                                      // 598
      continue;                                                                         // 599
    }                                                                                   // 600
                                                                                        // 601
    // tag                                                                              // 602
    if (cap = this.rules.tag.exec(src)) {                                               // 603
      if (!this.inLink && /^<a /i.test(cap[0])) {                                       // 604
        this.inLink = true;                                                             // 605
      } else if (this.inLink && /^<\/a>/i.test(cap[0])) {                               // 606
        this.inLink = false;                                                            // 607
      }                                                                                 // 608
      src = src.substring(cap[0].length);                                               // 609
      out += this.options.sanitize                                                      // 610
        ? this.options.sanitizer                                                        // 611
          ? this.options.sanitizer(cap[0])                                              // 612
          : escape(cap[0])                                                              // 613
        : cap[0]                                                                        // 614
      continue;                                                                         // 615
    }                                                                                   // 616
                                                                                        // 617
    // link                                                                             // 618
    if (cap = this.rules.link.exec(src)) {                                              // 619
      src = src.substring(cap[0].length);                                               // 620
      this.inLink = true;                                                               // 621
      out += this.outputLink(cap, {                                                     // 622
        href: cap[2],                                                                   // 623
        title: cap[3]                                                                   // 624
      });                                                                               // 625
      this.inLink = false;                                                              // 626
      continue;                                                                         // 627
    }                                                                                   // 628
                                                                                        // 629
    // reflink, nolink                                                                  // 630
    if ((cap = this.rules.reflink.exec(src))                                            // 631
        || (cap = this.rules.nolink.exec(src))) {                                       // 632
      src = src.substring(cap[0].length);                                               // 633
      link = (cap[2] || cap[1]).replace(/\s+/g, ' ');                                   // 634
      link = this.links[link.toLowerCase()];                                            // 635
      if (!link || !link.href) {                                                        // 636
        out += cap[0].charAt(0);                                                        // 637
        src = cap[0].substring(1) + src;                                                // 638
        continue;                                                                       // 639
      }                                                                                 // 640
      this.inLink = true;                                                               // 641
      out += this.outputLink(cap, link);                                                // 642
      this.inLink = false;                                                              // 643
      continue;                                                                         // 644
    }                                                                                   // 645
                                                                                        // 646
    // strong                                                                           // 647
    if (cap = this.rules.strong.exec(src)) {                                            // 648
      src = src.substring(cap[0].length);                                               // 649
      out += this.renderer.strong(this.output(cap[2] || cap[1]));                       // 650
      continue;                                                                         // 651
    }                                                                                   // 652
                                                                                        // 653
    // em                                                                               // 654
    if (cap = this.rules.em.exec(src)) {                                                // 655
      src = src.substring(cap[0].length);                                               // 656
      out += this.renderer.em(this.output(cap[2] || cap[1]));                           // 657
      continue;                                                                         // 658
    }                                                                                   // 659
                                                                                        // 660
    // code                                                                             // 661
    if (cap = this.rules.code.exec(src)) {                                              // 662
      src = src.substring(cap[0].length);                                               // 663
      out += this.renderer.codespan(escape(cap[2], true));                              // 664
      continue;                                                                         // 665
    }                                                                                   // 666
                                                                                        // 667
    // br                                                                               // 668
    if (cap = this.rules.br.exec(src)) {                                                // 669
      src = src.substring(cap[0].length);                                               // 670
      out += this.renderer.br();                                                        // 671
      continue;                                                                         // 672
    }                                                                                   // 673
                                                                                        // 674
    // del (gfm)                                                                        // 675
    if (cap = this.rules.del.exec(src)) {                                               // 676
      src = src.substring(cap[0].length);                                               // 677
      out += this.renderer.del(this.output(cap[1]));                                    // 678
      continue;                                                                         // 679
    }                                                                                   // 680
                                                                                        // 681
    // text                                                                             // 682
    if (cap = this.rules.text.exec(src)) {                                              // 683
      src = src.substring(cap[0].length);                                               // 684
      out += this.renderer.text(escape(this.smartypants(cap[0])));                      // 685
      continue;                                                                         // 686
    }                                                                                   // 687
                                                                                        // 688
    if (src) {                                                                          // 689
      throw new                                                                         // 690
        Error('Infinite loop on byte: ' + src.charCodeAt(0));                           // 691
    }                                                                                   // 692
  }                                                                                     // 693
                                                                                        // 694
  return out;                                                                           // 695
};                                                                                      // 696
                                                                                        // 697
/**                                                                                     // 698
 * Compile Link                                                                         // 699
 */                                                                                     // 700
                                                                                        // 701
InlineLexer.prototype.outputLink = function(cap, link) {                                // 702
  var href = escape(link.href)                                                          // 703
    , title = link.title ? escape(link.title) : null;                                   // 704
                                                                                        // 705
  return cap[0].charAt(0) !== '!'                                                       // 706
    ? this.renderer.link(href, title, this.output(cap[1]))                              // 707
    : this.renderer.image(href, title, escape(cap[1]));                                 // 708
};                                                                                      // 709
                                                                                        // 710
/**                                                                                     // 711
 * Smartypants Transformations                                                          // 712
 */                                                                                     // 713
                                                                                        // 714
InlineLexer.prototype.smartypants = function(text) {                                    // 715
  if (!this.options.smartypants) return text;                                           // 716
  return text                                                                           // 717
    // em-dashes                                                                        // 718
    .replace(/---/g, '\u2014')                                                          // 719
    // en-dashes                                                                        // 720
    .replace(/--/g, '\u2013')                                                           // 721
    // opening singles                                                                  // 722
    .replace(/(^|[-\u2014/(\[{"\s])'/g, '$1\u2018')                                     // 723
    // closing singles & apostrophes                                                    // 724
    .replace(/'/g, '\u2019')                                                            // 725
    // opening doubles                                                                  // 726
    .replace(/(^|[-\u2014/(\[{\u2018\s])"/g, '$1\u201c')                                // 727
    // closing doubles                                                                  // 728
    .replace(/"/g, '\u201d')                                                            // 729
    // ellipses                                                                         // 730
    .replace(/\.{3}/g, '\u2026');                                                       // 731
};                                                                                      // 732
                                                                                        // 733
/**                                                                                     // 734
 * Mangle Links                                                                         // 735
 */                                                                                     // 736
                                                                                        // 737
InlineLexer.prototype.mangle = function(text) {                                         // 738
  if (!this.options.mangle) return text;                                                // 739
  var out = ''                                                                          // 740
    , l = text.length                                                                   // 741
    , i = 0                                                                             // 742
    , ch;                                                                               // 743
                                                                                        // 744
  for (; i < l; i++) {                                                                  // 745
    ch = text.charCodeAt(i);                                                            // 746
    if (Math.random() > 0.5) {                                                          // 747
      ch = 'x' + ch.toString(16);                                                       // 748
    }                                                                                   // 749
    out += '&#' + ch + ';';                                                             // 750
  }                                                                                     // 751
                                                                                        // 752
  return out;                                                                           // 753
};                                                                                      // 754
                                                                                        // 755
/**                                                                                     // 756
 * Renderer                                                                             // 757
 */                                                                                     // 758
                                                                                        // 759
function Renderer(options) {                                                            // 760
  this.options = options || {};                                                         // 761
}                                                                                       // 762
                                                                                        // 763
Renderer.prototype.code = function(code, lang, escaped) {                               // 764
  if (this.options.highlight) {                                                         // 765
    var out = this.options.highlight(code, lang);                                       // 766
    if (out != null && out !== code) {                                                  // 767
      escaped = true;                                                                   // 768
      code = out;                                                                       // 769
    }                                                                                   // 770
  }                                                                                     // 771
                                                                                        // 772
  if (!lang) {                                                                          // 773
    return '<pre><code>'                                                                // 774
      + (escaped ? code : escape(code, true))                                           // 775
      + '\n</code></pre>';                                                              // 776
  }                                                                                     // 777
                                                                                        // 778
  return '<pre><code class="'                                                           // 779
    + this.options.langPrefix                                                           // 780
    + escape(lang, true)                                                                // 781
    + '">'                                                                              // 782
    + (escaped ? code : escape(code, true))                                             // 783
    + '\n</code></pre>\n';                                                              // 784
};                                                                                      // 785
                                                                                        // 786
Renderer.prototype.blockquote = function(quote) {                                       // 787
  return '<blockquote>\n' + quote + '</blockquote>\n';                                  // 788
};                                                                                      // 789
                                                                                        // 790
Renderer.prototype.html = function(html) {                                              // 791
  return html;                                                                          // 792
};                                                                                      // 793
                                                                                        // 794
Renderer.prototype.heading = function(text, level, raw) {                               // 795
  return '<h'                                                                           // 796
    + level                                                                             // 797
    + ' id="'                                                                           // 798
    + this.options.headerPrefix                                                         // 799
    + raw.toLowerCase().replace(/[^\w]+/g, '-')                                         // 800
    + '">'                                                                              // 801
    + text                                                                              // 802
    + '</h'                                                                             // 803
    + level                                                                             // 804
    + '>\n';                                                                            // 805
};                                                                                      // 806
                                                                                        // 807
Renderer.prototype.hr = function() {                                                    // 808
  return this.options.xhtml ? '<hr/>\n' : '<hr>\n';                                     // 809
};                                                                                      // 810
                                                                                        // 811
Renderer.prototype.list = function(body, ordered) {                                     // 812
  var type = ordered ? 'ol' : 'ul';                                                     // 813
  return '<' + type + '>\n' + body + '</' + type + '>\n';                               // 814
};                                                                                      // 815
                                                                                        // 816
Renderer.prototype.listitem = function(text) {                                          // 817
  return '<li>' + text + '</li>\n';                                                     // 818
};                                                                                      // 819
                                                                                        // 820
Renderer.prototype.paragraph = function(text) {                                         // 821
  return '<p>' + text + '</p>\n';                                                       // 822
};                                                                                      // 823
                                                                                        // 824
Renderer.prototype.table = function(header, body) {                                     // 825
  return '<table>\n'                                                                    // 826
    + '<thead>\n'                                                                       // 827
    + header                                                                            // 828
    + '</thead>\n'                                                                      // 829
    + '<tbody>\n'                                                                       // 830
    + body                                                                              // 831
    + '</tbody>\n'                                                                      // 832
    + '</table>\n';                                                                     // 833
};                                                                                      // 834
                                                                                        // 835
Renderer.prototype.tablerow = function(content) {                                       // 836
  return '<tr>\n' + content + '</tr>\n';                                                // 837
};                                                                                      // 838
                                                                                        // 839
Renderer.prototype.tablecell = function(content, flags) {                               // 840
  var type = flags.header ? 'th' : 'td';                                                // 841
  var tag = flags.align                                                                 // 842
    ? '<' + type + ' style="text-align:' + flags.align + '">'                           // 843
    : '<' + type + '>';                                                                 // 844
  return tag + content + '</' + type + '>\n';                                           // 845
};                                                                                      // 846
                                                                                        // 847
// span level renderer                                                                  // 848
Renderer.prototype.strong = function(text) {                                            // 849
  return '<strong>' + text + '</strong>';                                               // 850
};                                                                                      // 851
                                                                                        // 852
Renderer.prototype.em = function(text) {                                                // 853
  return '<em>' + text + '</em>';                                                       // 854
};                                                                                      // 855
                                                                                        // 856
Renderer.prototype.codespan = function(text) {                                          // 857
  return '<code>' + text + '</code>';                                                   // 858
};                                                                                      // 859
                                                                                        // 860
Renderer.prototype.br = function() {                                                    // 861
  return this.options.xhtml ? '<br/>' : '<br>';                                         // 862
};                                                                                      // 863
                                                                                        // 864
Renderer.prototype.del = function(text) {                                               // 865
  return '<del>' + text + '</del>';                                                     // 866
};                                                                                      // 867
                                                                                        // 868
Renderer.prototype.link = function(href, title, text) {                                 // 869
  if (this.options.sanitize) {                                                          // 870
    try {                                                                               // 871
      var prot = decodeURIComponent(unescape(href))                                     // 872
        .replace(/[^\w:]/g, '')                                                         // 873
        .toLowerCase();                                                                 // 874
    } catch (e) {                                                                       // 875
      return '';                                                                        // 876
    }                                                                                   // 877
    if (prot.indexOf('javascript:') === 0 || prot.indexOf('vbscript:') === 0) {         // 878
      return '';                                                                        // 879
    }                                                                                   // 880
  }                                                                                     // 881
  var out = '<a href="' + href + '"';                                                   // 882
  if (title) {                                                                          // 883
    out += ' title="' + title + '"';                                                    // 884
  }                                                                                     // 885
  out += '>' + text + '</a>';                                                           // 886
  return out;                                                                           // 887
};                                                                                      // 888
                                                                                        // 889
Renderer.prototype.image = function(href, title, text) {                                // 890
  var out = '<img src="' + href + '" alt="' + text + '"';                               // 891
  if (title) {                                                                          // 892
    out += ' title="' + title + '"';                                                    // 893
  }                                                                                     // 894
  out += this.options.xhtml ? '/>' : '>';                                               // 895
  return out;                                                                           // 896
};                                                                                      // 897
                                                                                        // 898
Renderer.prototype.text = function(text) {                                              // 899
  return text;                                                                          // 900
};                                                                                      // 901
                                                                                        // 902
/**                                                                                     // 903
 * Parsing & Compiling                                                                  // 904
 */                                                                                     // 905
                                                                                        // 906
function Parser(options) {                                                              // 907
  this.tokens = [];                                                                     // 908
  this.token = null;                                                                    // 909
  this.options = options || marked.defaults;                                            // 910
  this.options.renderer = this.options.renderer || new Renderer;                        // 911
  this.renderer = this.options.renderer;                                                // 912
  this.renderer.options = this.options;                                                 // 913
}                                                                                       // 914
                                                                                        // 915
/**                                                                                     // 916
 * Static Parse Method                                                                  // 917
 */                                                                                     // 918
                                                                                        // 919
Parser.parse = function(src, options, renderer) {                                       // 920
  var parser = new Parser(options, renderer);                                           // 921
  return parser.parse(src);                                                             // 922
};                                                                                      // 923
                                                                                        // 924
/**                                                                                     // 925
 * Parse Loop                                                                           // 926
 */                                                                                     // 927
                                                                                        // 928
Parser.prototype.parse = function(src) {                                                // 929
  this.inline = new InlineLexer(src.links, this.options, this.renderer);                // 930
  this.tokens = src.reverse();                                                          // 931
                                                                                        // 932
  var out = '';                                                                         // 933
  while (this.next()) {                                                                 // 934
    out += this.tok();                                                                  // 935
  }                                                                                     // 936
                                                                                        // 937
  return out;                                                                           // 938
};                                                                                      // 939
                                                                                        // 940
/**                                                                                     // 941
 * Next Token                                                                           // 942
 */                                                                                     // 943
                                                                                        // 944
Parser.prototype.next = function() {                                                    // 945
  return this.token = this.tokens.pop();                                                // 946
};                                                                                      // 947
                                                                                        // 948
/**                                                                                     // 949
 * Preview Next Token                                                                   // 950
 */                                                                                     // 951
                                                                                        // 952
Parser.prototype.peek = function() {                                                    // 953
  return this.tokens[this.tokens.length - 1] || 0;                                      // 954
};                                                                                      // 955
                                                                                        // 956
/**                                                                                     // 957
 * Parse Text Tokens                                                                    // 958
 */                                                                                     // 959
                                                                                        // 960
Parser.prototype.parseText = function() {                                               // 961
  var body = this.token.text;                                                           // 962
                                                                                        // 963
  while (this.peek().type === 'text') {                                                 // 964
    body += '\n' + this.next().text;                                                    // 965
  }                                                                                     // 966
                                                                                        // 967
  return this.inline.output(body);                                                      // 968
};                                                                                      // 969
                                                                                        // 970
/**                                                                                     // 971
 * Parse Current Token                                                                  // 972
 */                                                                                     // 973
                                                                                        // 974
Parser.prototype.tok = function() {                                                     // 975
  switch (this.token.type) {                                                            // 976
    case 'space': {                                                                     // 977
      return '';                                                                        // 978
    }                                                                                   // 979
    case 'hr': {                                                                        // 980
      return this.renderer.hr();                                                        // 981
    }                                                                                   // 982
    case 'heading': {                                                                   // 983
      return this.renderer.heading(                                                     // 984
        this.inline.output(this.token.text),                                            // 985
        this.token.depth,                                                               // 986
        this.token.text);                                                               // 987
    }                                                                                   // 988
    case 'code': {                                                                      // 989
      return this.renderer.code(this.token.text,                                        // 990
        this.token.lang,                                                                // 991
        this.token.escaped);                                                            // 992
    }                                                                                   // 993
    case 'table': {                                                                     // 994
      var header = ''                                                                   // 995
        , body = ''                                                                     // 996
        , i                                                                             // 997
        , row                                                                           // 998
        , cell                                                                          // 999
        , flags                                                                         // 1000
        , j;                                                                            // 1001
                                                                                        // 1002
      // header                                                                         // 1003
      cell = '';                                                                        // 1004
      for (i = 0; i < this.token.header.length; i++) {                                  // 1005
        flags = { header: true, align: this.token.align[i] };                           // 1006
        cell += this.renderer.tablecell(                                                // 1007
          this.inline.output(this.token.header[i]),                                     // 1008
          { header: true, align: this.token.align[i] }                                  // 1009
        );                                                                              // 1010
      }                                                                                 // 1011
      header += this.renderer.tablerow(cell);                                           // 1012
                                                                                        // 1013
      for (i = 0; i < this.token.cells.length; i++) {                                   // 1014
        row = this.token.cells[i];                                                      // 1015
                                                                                        // 1016
        cell = '';                                                                      // 1017
        for (j = 0; j < row.length; j++) {                                              // 1018
          cell += this.renderer.tablecell(                                              // 1019
            this.inline.output(row[j]),                                                 // 1020
            { header: false, align: this.token.align[j] }                               // 1021
          );                                                                            // 1022
        }                                                                               // 1023
                                                                                        // 1024
        body += this.renderer.tablerow(cell);                                           // 1025
      }                                                                                 // 1026
      return this.renderer.table(header, body);                                         // 1027
    }                                                                                   // 1028
    case 'blockquote_start': {                                                          // 1029
      var body = '';                                                                    // 1030
                                                                                        // 1031
      while (this.next().type !== 'blockquote_end') {                                   // 1032
        body += this.tok();                                                             // 1033
      }                                                                                 // 1034
                                                                                        // 1035
      return this.renderer.blockquote(body);                                            // 1036
    }                                                                                   // 1037
    case 'list_start': {                                                                // 1038
      var body = ''                                                                     // 1039
        , ordered = this.token.ordered;                                                 // 1040
                                                                                        // 1041
      while (this.next().type !== 'list_end') {                                         // 1042
        body += this.tok();                                                             // 1043
      }                                                                                 // 1044
                                                                                        // 1045
      return this.renderer.list(body, ordered);                                         // 1046
    }                                                                                   // 1047
    case 'list_item_start': {                                                           // 1048
      var body = '';                                                                    // 1049
                                                                                        // 1050
      while (this.next().type !== 'list_item_end') {                                    // 1051
        body += this.token.type === 'text'                                              // 1052
          ? this.parseText()                                                            // 1053
          : this.tok();                                                                 // 1054
      }                                                                                 // 1055
                                                                                        // 1056
      return this.renderer.listitem(body);                                              // 1057
    }                                                                                   // 1058
    case 'loose_item_start': {                                                          // 1059
      var body = '';                                                                    // 1060
                                                                                        // 1061
      while (this.next().type !== 'list_item_end') {                                    // 1062
        body += this.tok();                                                             // 1063
      }                                                                                 // 1064
                                                                                        // 1065
      return this.renderer.listitem(body);                                              // 1066
    }                                                                                   // 1067
    case 'html': {                                                                      // 1068
      var html = !this.token.pre && !this.options.pedantic                              // 1069
        ? this.inline.output(this.token.text)                                           // 1070
        : this.token.text;                                                              // 1071
      return this.renderer.html(html);                                                  // 1072
    }                                                                                   // 1073
    case 'paragraph': {                                                                 // 1074
      return this.renderer.paragraph(this.inline.output(this.token.text));              // 1075
    }                                                                                   // 1076
    case 'text': {                                                                      // 1077
      return this.renderer.paragraph(this.parseText());                                 // 1078
    }                                                                                   // 1079
  }                                                                                     // 1080
};                                                                                      // 1081
                                                                                        // 1082
/**                                                                                     // 1083
 * Helpers                                                                              // 1084
 */                                                                                     // 1085
                                                                                        // 1086
function escape(html, encode) {                                                         // 1087
  return html                                                                           // 1088
    .replace(!encode ? /&(?!#?\w+;)/g : /&/g, '&amp;')                                  // 1089
    .replace(/</g, '&lt;')                                                              // 1090
    .replace(/>/g, '&gt;')                                                              // 1091
    .replace(/"/g, '&quot;')                                                            // 1092
    .replace(/'/g, '&#39;');                                                            // 1093
}                                                                                       // 1094
                                                                                        // 1095
function unescape(html) {                                                               // 1096
  return html.replace(/&([#\w]+);/g, function(_, n) {                                   // 1097
    n = n.toLowerCase();                                                                // 1098
    if (n === 'colon') return ':';                                                      // 1099
    if (n.charAt(0) === '#') {                                                          // 1100
      return n.charAt(1) === 'x'                                                        // 1101
        ? String.fromCharCode(parseInt(n.substring(2), 16))                             // 1102
        : String.fromCharCode(+n.substring(1));                                         // 1103
    }                                                                                   // 1104
    return '';                                                                          // 1105
  });                                                                                   // 1106
}                                                                                       // 1107
                                                                                        // 1108
function replace(regex, opt) {                                                          // 1109
  regex = regex.source;                                                                 // 1110
  opt = opt || '';                                                                      // 1111
  return function self(name, val) {                                                     // 1112
    if (!name) return new RegExp(regex, opt);                                           // 1113
    val = val.source || val;                                                            // 1114
    val = val.replace(/(^|[^\[])\^/g, '$1');                                            // 1115
    regex = regex.replace(name, val);                                                   // 1116
    return self;                                                                        // 1117
  };                                                                                    // 1118
}                                                                                       // 1119
                                                                                        // 1120
function noop() {}                                                                      // 1121
noop.exec = noop;                                                                       // 1122
                                                                                        // 1123
function merge(obj) {                                                                   // 1124
  var i = 1                                                                             // 1125
    , target                                                                            // 1126
    , key;                                                                              // 1127
                                                                                        // 1128
  for (; i < arguments.length; i++) {                                                   // 1129
    target = arguments[i];                                                              // 1130
    for (key in target) {                                                               // 1131
      if (Object.prototype.hasOwnProperty.call(target, key)) {                          // 1132
        obj[key] = target[key];                                                         // 1133
      }                                                                                 // 1134
    }                                                                                   // 1135
  }                                                                                     // 1136
                                                                                        // 1137
  return obj;                                                                           // 1138
}                                                                                       // 1139
                                                                                        // 1140
                                                                                        // 1141
/**                                                                                     // 1142
 * Marked                                                                               // 1143
 */                                                                                     // 1144
                                                                                        // 1145
function marked(src, opt, callback) {                                                   // 1146
  if (callback || typeof opt === 'function') {                                          // 1147
    if (!callback) {                                                                    // 1148
      callback = opt;                                                                   // 1149
      opt = null;                                                                       // 1150
    }                                                                                   // 1151
                                                                                        // 1152
    opt = merge({}, marked.defaults, opt || {});                                        // 1153
                                                                                        // 1154
    var highlight = opt.highlight                                                       // 1155
      , tokens                                                                          // 1156
      , pending                                                                         // 1157
      , i = 0;                                                                          // 1158
                                                                                        // 1159
    try {                                                                               // 1160
      tokens = Lexer.lex(src, opt)                                                      // 1161
    } catch (e) {                                                                       // 1162
      return callback(e);                                                               // 1163
    }                                                                                   // 1164
                                                                                        // 1165
    pending = tokens.length;                                                            // 1166
                                                                                        // 1167
    var done = function(err) {                                                          // 1168
      if (err) {                                                                        // 1169
        opt.highlight = highlight;                                                      // 1170
        return callback(err);                                                           // 1171
      }                                                                                 // 1172
                                                                                        // 1173
      var out;                                                                          // 1174
                                                                                        // 1175
      try {                                                                             // 1176
        out = Parser.parse(tokens, opt);                                                // 1177
      } catch (e) {                                                                     // 1178
        err = e;                                                                        // 1179
      }                                                                                 // 1180
                                                                                        // 1181
      opt.highlight = highlight;                                                        // 1182
                                                                                        // 1183
      return err                                                                        // 1184
        ? callback(err)                                                                 // 1185
        : callback(null, out);                                                          // 1186
    };                                                                                  // 1187
                                                                                        // 1188
    if (!highlight || highlight.length < 3) {                                           // 1189
      return done();                                                                    // 1190
    }                                                                                   // 1191
                                                                                        // 1192
    delete opt.highlight;                                                               // 1193
                                                                                        // 1194
    if (!pending) return done();                                                        // 1195
                                                                                        // 1196
    for (; i < tokens.length; i++) {                                                    // 1197
      (function(token) {                                                                // 1198
        if (token.type !== 'code') {                                                    // 1199
          return --pending || done();                                                   // 1200
        }                                                                               // 1201
        return highlight(token.text, token.lang, function(err, code) {                  // 1202
          if (err) return done(err);                                                    // 1203
          if (code == null || code === token.text) {                                    // 1204
            return --pending || done();                                                 // 1205
          }                                                                             // 1206
          token.text = code;                                                            // 1207
          token.escaped = true;                                                         // 1208
          --pending || done();                                                          // 1209
        });                                                                             // 1210
      })(tokens[i]);                                                                    // 1211
    }                                                                                   // 1212
                                                                                        // 1213
    return;                                                                             // 1214
  }                                                                                     // 1215
  try {                                                                                 // 1216
    if (opt) opt = merge({}, marked.defaults, opt);                                     // 1217
    return Parser.parse(Lexer.lex(src, opt), opt);                                      // 1218
  } catch (e) {                                                                         // 1219
    e.message += '\nPlease report this to https://github.com/chjj/marked.';             // 1220
    if ((opt || marked.defaults).silent) {                                              // 1221
      return '<p>An error occured:</p><pre>'                                            // 1222
        + escape(e.message + '', true)                                                  // 1223
        + '</pre>';                                                                     // 1224
    }                                                                                   // 1225
    throw e;                                                                            // 1226
  }                                                                                     // 1227
}                                                                                       // 1228
                                                                                        // 1229
/**                                                                                     // 1230
 * Options                                                                              // 1231
 */                                                                                     // 1232
                                                                                        // 1233
marked.options =                                                                        // 1234
marked.setOptions = function(opt) {                                                     // 1235
  merge(marked.defaults, opt);                                                          // 1236
  return marked;                                                                        // 1237
};                                                                                      // 1238
                                                                                        // 1239
marked.defaults = {                                                                     // 1240
  gfm: true,                                                                            // 1241
  tables: true,                                                                         // 1242
  breaks: false,                                                                        // 1243
  pedantic: false,                                                                      // 1244
  sanitize: false,                                                                      // 1245
  sanitizer: null,                                                                      // 1246
  mangle: true,                                                                         // 1247
  smartLists: false,                                                                    // 1248
  silent: false,                                                                        // 1249
  highlight: null,                                                                      // 1250
  langPrefix: 'lang-',                                                                  // 1251
  smartypants: false,                                                                   // 1252
  headerPrefix: '',                                                                     // 1253
  renderer: new Renderer,                                                               // 1254
  xhtml: false                                                                          // 1255
};                                                                                      // 1256
                                                                                        // 1257
/**                                                                                     // 1258
 * Expose                                                                               // 1259
 */                                                                                     // 1260
                                                                                        // 1261
marked.Parser = Parser;                                                                 // 1262
marked.parser = Parser.parse;                                                           // 1263
                                                                                        // 1264
marked.Renderer = Renderer;                                                             // 1265
                                                                                        // 1266
marked.Lexer = Lexer;                                                                   // 1267
marked.lexer = Lexer.lex;                                                               // 1268
                                                                                        // 1269
marked.InlineLexer = InlineLexer;                                                       // 1270
marked.inlineLexer = InlineLexer.output;                                                // 1271
                                                                                        // 1272
marked.parse = marked;                                                                  // 1273
                                                                                        // 1274
if (typeof module !== 'undefined' && typeof exports === 'object') {                     // 1275
  module.exports = marked;                                                              // 1276
} else if (typeof define === 'function' && define.amd) {                                // 1277
  define(function() { return marked; });                                                // 1278
} else {                                                                                // 1279
  this.marked = marked;                                                                 // 1280
}                                                                                       // 1281
                                                                                        // 1282
}).call(function() {                                                                    // 1283
  return this || (typeof window !== 'undefined' ? window : global);                     // 1284
}());                                                                                   // 1285
                                                                                        // 1286
//////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// packages/chuangbo:marked/post-marked.js                                              //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //
marked = module.exports;                                                                // 1
//////////////////////////////////////////////////////////////////////////////////////////

}).call(this);

//////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['chuangbo:marked'] = {}, {
  marked: marked
});

})();

//# sourceMappingURL=chuangbo_marked.js.map
