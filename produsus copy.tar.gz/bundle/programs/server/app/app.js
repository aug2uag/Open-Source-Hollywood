var require = meteorInstall({"lib":{"prototypes.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// lib/prototypes.js                                                                                                 //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
String.prototype.format = function () {                                                                              // 1
    var formatted = this;                                                                                            // 2
    for (var i = 0; i < arguments.length; i++) {                                                                     // 3
        var regexp = new RegExp('\\{' + i + '\\}', 'gi');                                                            // 4
        formatted = formatted.replace(regexp, arguments[i]);                                                         // 5
    }                                                                                                                //
    return formatted;                                                                                                // 7
};                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"utils.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// lib/utils.js                                                                                                      //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
allowIsBoardAdmin = function allowIsBoardAdmin(userId, board) {                                                      // 1
	console.log('allowIsBoardAdmin');                                                                                   // 2
	var user = Users.findOne(userId);                                                                                   // 3
	return _.contains(_.pluck(_.where(board.members, { isAdmin: true }), 'userId'), user._id);                          // 4
};                                                                                                                   //
                                                                                                                     //
allowIsBoardMember = function allowIsBoardMember(userId, board) {                                                    // 7
	console.log('allowIsBoardMember');                                                                                  // 8
	var user = Users.findOne(userId);                                                                                   // 9
	return _.contains(_.pluck(board.members, 'userId'), user._id);                                                      // 10
};                                                                                                                   //
                                                                                                                     //
isServer = function isServer(callback) {                                                                             // 13
	return Meteor.isServer && callback();                                                                               // 14
};                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":["babel-runtime/helpers/typeof","aws-sdk","uuid","fs","base64-img","stripe","meteor-node-stubs/deps/fs",function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// lib/main.js                                                                                                       //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var _typeof2 = require('babel-runtime/helpers/typeof');                                                              //
                                                                                                                     //
var _typeof3 = _interopRequireDefault(_typeof2);                                                                     //
                                                                                                                     //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                    //
                                                                                                                     //
var StripePublicKey = 'pk_test_Dgvlv9PBf6RuZJMPkqCp00wg';                                                            // 1
var StripeServerKey = 'sk_test_ZINoK7ZfA5Axdr06AewQzZuh';                                                            // 2
var AWS = require('aws-sdk');                                                                                        // 3
var s3 = new AWS.S3({ accessKeyId: 'AKIAJPOLFUWAXQYOBVQQ', secretAccessKey: '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', region: 'us-east-1', params: { Bucket: 'producehour/headshots', Key: 'bdPxm5qOGkODp73bIx7RJbHlHDfX3UDbA7DEcl6i' } });
var uuid = require('uuid');                                                                                          // 5
var fs = require('fs');                                                                                              // 6
var base64Img = require('base64-img');                                                                               // 7
                                                                                                                     //
function uploadToS3(options) {                                                                                       // 9
  console.log('to base64Img upload');                                                                                // 10
  base64Img.img(options.data, '', options.name, Meteor.bindEnvironment(function (err, filepath) {                    // 11
    s3.upload({                                                                                                      // 12
      Body: fs.createReadStream(filepath),                                                                           // 13
      ACL: 'public-read',                                                                                            // 14
      Key: options.name                                                                                              // 15
    }, Meteor.bindEnvironment(function (err) {                                                                       //
      if (err) console.log(err);                                                                                     // 17
      // set modified object to user                                                                                 //
      fs.unlink(filepath);                                                                                           // 16
    }, function () {                                                                                                 //
      console.log('failed to bind environment');                                                                     // 21
    }));                                                                                                             //
  }, function () {                                                                                                   //
    console.log('failed to bind environment');                                                                       // 24
  }));                                                                                                               //
}                                                                                                                    //
                                                                                                                     //
function guid() {                                                                                                    // 28
  function s4() {                                                                                                    // 29
    return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);                                      // 30
  }                                                                                                                  //
  return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();                              // 34
}                                                                                                                    //
                                                                                                                     //
// var Receipts = new Mongo.Collection('receipts');                                                                  //
Date.prototype.getUnixTime = function () {                                                                           // 39
  return this.getTime() / 1000 | 0;                                                                                  // 39
};                                                                                                                   //
if (Meteor.isClient) {                                                                                               // 40
  Meteor.startup(function () {                                                                                       // 41
    //search                                                                                                         //
    Session.set('query', '');                                                                                        // 43
    //pagination                                                                                                     //
    Session.set('iSkip', 0);                                                                                         // 41
    Session.set('iLimit', 30);                                                                                       // 46
    Session.set('pSkip', 0);                                                                                         // 47
    Session.set('pLimit', 30);                                                                                       // 48
    // portal tabs                                                                                                   //
    Session.set('register', false);                                                                                  // 41
    Session.set('signin', true);                                                                                     // 51
    Session.set('forgot', false);                                                                                    // 52
  });                                                                                                                //
} /* isClient */                                                                                                     //
                                                                                                                     //
/* Meteor methods */                                                                                                 //
Meteor.methods({                                                                                                     // 57
  uploadSettingFiles: function () {                                                                                  // 58
    function uploadSettingFiles(key, options) {                                                                      // 58
      check(options, Object);                                                                                        // 59
      check(key, String);                                                                                            // 60
      if (Meteor.isServer) {                                                                                         // 61
        if (key === 'headshots') {                                                                                   // 62
          var d = new Date().getTime();                                                                              // 63
          var _d = uuid();                                                                                           // 64
          var __d = d.toString().substr(0, 8) + _d.substr(0, 4);                                                     // 65
          base64Img.img(options.data, '', __d, Meteor.bindEnvironment(function (err, filepath) {                     // 66
            s3.upload({                                                                                              // 67
              Body: fs.createReadStream(filepath),                                                                   // 68
              ACL: 'public-read',                                                                                    // 69
              Key: __d                                                                                               // 70
            }, Meteor.bindEnvironment(function (err) {                                                               //
              if (err) console.log(err);                                                                             // 72
              // set modified object to user                                                                         //
              var o = {};                                                                                            // 71
              o[key] = {};                                                                                           // 75
              o[key].name = options.name;                                                                            // 76
              o[key].date = options.date;                                                                            // 77
              o[key].url = __d;                                                                                      // 78
              o[key].size = options.size;                                                                            // 79
              o[key].type = options.type;                                                                            // 80
              o[key].tags = options.tags;                                                                            // 81
              o[key].description = options.description;                                                              // 82
              Meteor.users.update({ _id: Meteor.user()._id }, { $push: o });                                         // 83
              fs.unlink(filepath);                                                                                   // 84
            }, function () {                                                                                         //
              console.log('failed to bind environment');                                                             // 86
            }));                                                                                                     //
          }, function () {                                                                                           //
            console.log('failed to bind environment');                                                               // 89
          }));                                                                                                       //
          return;                                                                                                    // 91
        };                                                                                                           //
                                                                                                                     //
        var k = {};                                                                                                  // 94
        k[key] = options;                                                                                            // 95
        Meteor.users.update({ _id: Meteor.user()._id }, { $push: k });                                               // 96
      };                                                                                                             //
    }                                                                                                                //
                                                                                                                     //
    return uploadSettingFiles;                                                                                       //
  }(),                                                                                                               //
  upgradeProfile: function () {                                                                                      // 99
    function upgradeProfile(options) {                                                                               // 99
      check(options, Object);                                                                                        // 100
      console.log(options);                                                                                          // 101
      for (var key in meteorBabelHelpers.sanitizeForInObject(options)) {                                             // 102
        if (key === 'avatar' && options[key].data) {                                                                 // 103
          var datum = options[key].data;                                                                             // 104
          delete options[key];                                                                                       // 105
          var d = new Date().getTime();                                                                              // 106
          var _d = uuid();                                                                                           // 107
          var __d = d.toString().substr(0, 8) + _d.substr(0, 4);                                                     // 108
          console.log(1);                                                                                            // 109
          base64Img.img(datum, '', __d, Meteor.bindEnvironment(function (err, filepath) {                            // 110
            s3.upload({                                                                                              // 111
              Body: fs.createReadStream(filepath),                                                                   // 112
              ACL: 'public-read',                                                                                    // 113
              Key: __d                                                                                               // 114
            }, Meteor.bindEnvironment(function (err) {                                                               //
              console.log(2);                                                                                        // 116
              if (err) console.log(err);                                                                             // 117
              var __x = 'https://s3-us-west-2.amazonaws.com/producehour/headshots/' + __d;                           // 118
              Meteor.users.update({ _id: Meteor.user()._id }, { $set: { 'avatar': __x } });                          // 119
              fs.unlink(filepath);                                                                                   // 120
            }, function () {                                                                                         //
              console.log(2);                                                                                        // 122
              console.log('failed to bind environment');                                                             // 123
            }));                                                                                                     //
          }, function () {                                                                                           //
            console.log(4);                                                                                          // 126
            console.log('failed to bind environment');                                                               // 127
          }));                                                                                                       //
        };                                                                                                           //
        if ((0, _typeof3['default'])(options[key]) === 'object') {                                                   // 130
          if (Object.keys(options[key]).length === 0) {                                                              // 131
            delete options[key];                                                                                     // 132
          };                                                                                                         //
        } else if (typeof options[key] === 'array') {                                                                //
          if (options[key].length === 0) {                                                                           // 135
            delete options[key];                                                                                     // 136
          };                                                                                                         //
        } else if (!options[key]) {                                                                                  //
          delete options[key];                                                                                       // 139
        }                                                                                                            //
      };                                                                                                             //
                                                                                                                     //
      if (Meteor.user().didSetProfile === true && Meteor.user().degenerateIAM === true) {                            // 143
        if (options.iam && options.iam.length > 0) {                                                                 // 144
          options.degenerateIAM = false;                                                                             // 145
        }                                                                                                            //
      };                                                                                                             //
                                                                                                                     //
      if (Meteor.user().didSetProfile === false) {                                                                   // 149
        if (options.primaryRole && options.iam && options.iam.length > 0) {                                          // 150
          options.didSetProfile = true;                                                                              // 151
          options.degenerateIAM = false;                                                                             // 152
        } else {                                                                                                     //
          options.didSetProfile = true;                                                                              // 154
          options.degenerateIAM = true;                                                                              // 155
        }                                                                                                            //
      };                                                                                                             //
                                                                                                                     //
      if (Object.keys(options).length > 0) {                                                                         // 159
        Meteor.users.update({ _id: Meteor.user()._id }, { $set: options });                                          // 160
      };                                                                                                             //
                                                                                                                     //
      if (Meteor.isClient) {                                                                                         // 163
        bootbox.alert('Your profile was updated', function () {                                                      // 164
          Router.go('Home');                                                                                         // 165
        });                                                                                                          //
      };                                                                                                             //
    }                                                                                                                //
                                                                                                                     //
    return upgradeProfile;                                                                                           //
  }(),                                                                                                               //
  updateList: function () {                                                                                          // 169
    function updateList(listName, humanReadable, object) {                                                           // 169
      check(listName, String);                                                                                       // 170
      check(humanReadable, String);                                                                                  // 171
      check(object, Object);                                                                                         // 172
                                                                                                                     //
      var q = {};                                                                                                    // 174
      q[listName] = object;                                                                                          // 175
      Meteor.users.update({ _id: Meteor.user()._id }, { $push: q });                                                 // 176
      if (Meteor.isClient) bootbox.alert(humanReadable + ' has been changed.');                                      // 177
    }                                                                                                                //
                                                                                                                     //
    return updateList;                                                                                               //
  }(),                                                                                                               //
  removeFromList: function () {                                                                                      // 179
    function removeFromList(listName, humanReadable, key, val) {                                                     // 179
      check(listName, String);                                                                                       // 180
      check(humanReadable, String);                                                                                  // 181
      check(key, String);                                                                                            // 182
      check(val, String);                                                                                            // 183
      var q = {};                                                                                                    // 184
      q[listName] = {};                                                                                              // 185
      q[listName][key] = val;                                                                                        // 186
      console.log(q);                                                                                                // 187
      Meteor.users.update({ _id: Meteor.user()._id }, { $pull: q });                                                 // 188
      if (Meteor.isClient) bootbox.alert(humanReadable + ' has been changed.');                                      // 189
    }                                                                                                                //
                                                                                                                     //
    return removeFromList;                                                                                           //
  }(),                                                                                                               //
  // should add project receipt to be paid when project goes live                                                    //
  addProject: function () {                                                                                          // 192
    function addProject(options) {                                                                                   // 192
      check(options, Object);                                                                                        // 193
      if (Meteor.isServer) {                                                                                         // 194
        var ownerId = Meteor.user()._id,                                                                             // 195
            slug = ownerId.substr(ownerId.length - 4) + new Date().getTime(),                                        //
            _user = {                                                                                                //
          userId: ownerId,                                                                                           // 198
          isAdmin: true                                                                                              // 199
        },                                                                                                           //
            permission = 'public',                                                                                   //
            members = [_user];                                                                                       //
                                                                                                                     //
        options.ownerId = ownerId;                                                                                   // 204
        options.ownerName = Meteor.user().firstName + ' ' + Meteor.user().lastName;                                  // 205
        options.ownerAvatar = Meteor.user().avatar;                                                                  // 206
        options.createdAt = moment().format('MMMM D, YYYY');                                                         // 207
        options.createTimeActual = new Date();                                                                       // 208
        options.isApproved = true;                                                                                   // 209
        options.archived = false;                                                                                    // 210
        options.count = 0;                                                                                           // 211
        options.funded = 0;                                                                                          // 212
        options.applied = 0;                                                                                         // 213
        options.approved = 0;                                                                                        // 214
        options.upvotedUsers = [];                                                                                   // 215
        options.downvotedUsers = [];                                                                                 // 216
        options.usersApplied = [];                                                                                   // 217
        options.usersApproved = [];                                                                                  // 218
        options.slug = slug;                                                                                         // 219
                                                                                                                     //
        // upload avatar and gift files                                                                              //
        if (options._banner) {                                                                                       // 194
          var fn = guid() + new Date().getTime();                                                                    // 223
          uploadToS3({                                                                                               // 224
            name: fn,                                                                                                // 225
            data: options._banner                                                                                    // 226
          });                                                                                                        //
          options.banner = 'https://s3-us-west-2.amazonaws.com/producehour/headshots/' + fn;                         // 228
        };                                                                                                           //
        options.gifts = [];                                                                                          // 230
        options._gifts.forEach(function (obj) {                                                                      // 231
          if (obj.data) {                                                                                            // 232
            var fn = guid() + new Date().getTime();                                                                  // 233
            uploadToS3({                                                                                             // 234
              name: fn,                                                                                              // 235
              data: obj.data                                                                                         // 236
            });                                                                                                      //
            obj.url = 'https://s3-us-west-2.amazonaws.com/producehour/headshots/' + fn;                              // 238
            delete obj['data'];                                                                                      // 239
            options.gifts.push(obj);                                                                                 // 240
          } else if (obj.url) {                                                                                      //
            options.gifts.push(obj);                                                                                 // 242
          }                                                                                                          //
        });                                                                                                          //
                                                                                                                     //
        var project = Projects.insert(options);                                                                      // 246
        Receipts.insert({                                                                                            // 247
          projectId: project,                                                                                        // 248
          userId: ownerId,                                                                                           // 249
          projTitle: options.title,                                                                                  // 250
          projAccepted: true,                                                                                        // 251
          amount: 0,                                                                                                 // 252
          purpose: 'create',                                                                                         // 253
          forProjectCreate: true,                                                                                    // 254
          forProjectApply: false,                                                                                    // 255
          created: new Date()                                                                                        // 256
        });                                                                                                          //
                                                                                                                     //
        Boards.insert({                                                                                              // 259
          title: options.title,                                                                                      // 260
          slug: slug,                                                                                                // 261
          permission: permission,                                                                                    // 262
          members: members,                                                                                          // 263
          archived: false,                                                                                           // 264
          createdAt: new Date(),                                                                                     // 265
          createdBy: ownerId,                                                                                        // 266
          purpose: options.purpose,                                                                                  // 267
          needs: options.needs                                                                                       // 268
        });                                                                                                          //
                                                                                                                     //
        var stripe = require("stripe")('sk_test_ZINoK7ZfA5Axdr06AewQzZuh');                                          // 271
        stripe.accounts.create({                                                                                     // 274
          email: Meteor.user().email,                                                                                // 275
          country: 'US',                                                                                             // 276
          managed: true                                                                                              // 277
        }, Meteor.bindEnvironment(function (err, account) {                                                          //
          if (err) console.log(err);                                                                                 // 279
          Projects.update({ _id: project }, { $set: { account: account } });                                         // 280
        }));                                                                                                         //
      };                                                                                                             //
                                                                                                                     //
      if (Meteor.isClient) {                                                                                         // 284
        bootbox.alert("Project created! Check your Dashboard for information about applicants, and to share your project with the world.");
        Router.go('Projects');                                                                                       // 286
      }                                                                                                              //
    }                                                                                                                //
                                                                                                                     //
    return addProject;                                                                                               //
  }(),                                                                                                               //
  editProject: function () {                                                                                         // 290
    function editProject(options) {                                                                                  // 290
      check(options, Object);                                                                                        // 291
      var project = Projects.findOne({ slug: options.slug });                                                        // 292
      if (project.ownerId !== Meteor.user()._id) {                                                                   // 293
        // Make sure only the owner can edit it                                                                      //
        throw new Meteor.Error("not-authorized");                                                                    // 295
      } else {                                                                                                       //
                                                                                                                     //
        Projects.update({ slug: options.slug }, { $set: options });                                                  // 299
        if (Meteor.isClient) {                                                                                       // 300
          Router.go('Projects');                                                                                     // 301
          bootbox.alert("Project updated!");                                                                         // 302
        }                                                                                                            //
      }                                                                                                              //
    }                                                                                                                //
                                                                                                                     //
    return editProject;                                                                                              //
  }(),                                                                                                               //
  // should refund all users applied                                                                                 //
  deleteProject: function () {                                                                                       // 307
    function deleteProject(slug) {                                                                                   // 307
      check(slug, String);                                                                                           // 308
      var project = Projects.findOne({ slug: slug });                                                                // 309
      if (project.ownerId !== Meteor.user()._id) {                                                                   // 310
        // Make sure only the owner can delete it                                                                    //
        throw new Meteor.Error("not-authorized");                                                                    // 312
      } else {                                                                                                       //
        var items;                                                                                                   //
                                                                                                                     //
        (function () {                                                                                               //
          // Async task (same in all examples in this chapter)                                                       //
                                                                                                                     //
          var async = function () {                                                                                  //
            function async(userApplied, callback) {                                                                  // 316
                                                                                                                     //
              // refund userApplied                                                                                  //
              var _receipt = Receipts.findOne({                                                                      // 319
                userId: userApplied.id,                                                                              // 320
                projectId: project._id                                                                               // 321
              });                                                                                                    //
              if (!_receipt || !_receipt.receipt) {                                                                  // 323
                if (Meteor.isServer) {                                                                               // 324
                  // create refund Receipt object, add to user                                                       //
                  Receipts.update({                                                                                  // 326
                    userId: userApplied.id,                                                                          // 327
                    projectId: project._id                                                                           // 328
                  }, { $set: {                                                                                       //
                      error: true                                                                                    // 330
                    } });                                                                                            //
                };                                                                                                   //
                return callback();                                                                                   // 333
              };                                                                                                     //
              var cardId = _receipt.receipt.id;                                                                      // 335
              var returnAmount = userApplied.contribution;                                                           // 336
              var reasonRefund = 'Refund of $' + parseInt(returnAmount).toFixed(2) + ' because project "' + project.title + '" did cancel.';
              var returnObj = {                                                                                      // 338
                charge: cardId,                                                                                      // 339
                amount: returnAmount * 95,                                                                           // 340
                currency: 'usd',                                                                                     // 341
                reason: reasonRefund,                                                                                // 342
                metadata: {                                                                                          // 343
                  projectId: project._id,                                                                            // 344
                  projectOwner: project.ownerId,                                                                     // 345
                  userId: userApplied.id                                                                             // 346
                }                                                                                                    //
              };                                                                                                     //
                                                                                                                     //
              if (Meteor.isServer) {                                                                                 // 350
                var stripe = require("stripe")(StripeServerKey);                                                     // 351
                                                                                                                     //
                stripe.refunds.create(returnObj, Meteor.bindEnvironment(function (err, refundObj) {                  // 355
                  if (Meteor.isServer) {                                                                             // 356
                    // create refund Receipt object, add to user                                                     //
                    Receipts.update({                                                                                // 358
                      userId: userApplied.id,                                                                        // 359
                      projectId: project._id                                                                         // 360
                    }, { $set: {                                                                                     //
                        refundAmount: returnAmount,                                                                  // 362
                        refunded: true,                                                                              // 363
                        receipt: refundObj                                                                           // 364
                      } });                                                                                          //
                  };                                                                                                 //
                  callback();                                                                                        // 367
                }));                                                                                                 //
              };                                                                                                     //
            }                                                                                                        //
                                                                                                                     //
            return async;                                                                                            //
          }();                                                                                                       //
                                                                                                                     //
          var final = function () {                                                                                  //
            function final() {                                                                                       // 372
              if (Meteor.isServer) {                                                                                 // 373
                Projects.update({ slug: slug }, { $set: { archived: true } });                                       // 374
                Boards.update({ slug: slug }, { $set: { archived: true } });                                         // 375
                Receipts.update({                                                                                    // 376
                  projectId: project._id                                                                             // 377
                }, { $set: {                                                                                         //
                    projStarted: false,                                                                              // 379
                    projFinished: false                                                                              // 380
                  } });                                                                                              //
              };                                                                                                     //
              if (Meteor.isClient) {                                                                                 // 383
                Router.go('Projects');                                                                               // 384
                bootbox.alert("Project deleted!");                                                                   // 385
              }                                                                                                      //
            }                                                                                                        //
                                                                                                                     //
            return final;                                                                                            //
          }();                                                                                                       //
                                                                                                                     //
          // A simple async series:                                                                                  //
                                                                                                                     //
          var series = function () {                                                                                 //
            function series(item) {                                                                                  // 392
              if (item) {                                                                                            // 393
                async(item, function () {                                                                            // 394
                  return series(items.shift());                                                                      // 395
                });                                                                                                  //
              } else {                                                                                               //
                return final();                                                                                      // 398
              }                                                                                                      //
            }                                                                                                        //
                                                                                                                     //
            return series;                                                                                           //
          }();                                                                                                       //
                                                                                                                     //
          items = project.usersApplied;                                                                              // 390
                                                                                                                     //
          items = items.concat(project.usersApproved);                                                               // 391
                                                                                                                     //
          if (!items || items.length === 0) {                                                                        // 401
            final();                                                                                                 // 402
          } else {                                                                                                   //
            series(items.shift());                                                                                   // 404
          }                                                                                                          //
        })();                                                                                                        //
      }                                                                                                              //
    }                                                                                                                //
                                                                                                                     //
    return deleteProject;                                                                                            //
  }(),                                                                                                               //
  startProject: function () {                                                                                        // 408
    function startProject(slug) {                                                                                    // 408
      check(slug, String);                                                                                           // 409
      var project = Projects.findOne({ slug: slug });                                                                // 410
      if (project.ownerId !== Meteor.user()._id) {                                                                   // 411
        // Make sure only the owner can delete it                                                                    //
        throw new Meteor.Error("not-authorized");                                                                    // 413
      } else {                                                                                                       //
        var items;                                                                                                   //
                                                                                                                     //
        (function () {                                                                                               //
          // refund each userApplied                                                                                 //
                                                                                                                     //
          var async = function () {                                                                                  //
            function async(userApplied, callback) {                                                                  // 416
              var cardId = userApplied.receipt.id;                                                                   // 417
              var returnAmount = userApplied.contribution;                                                           // 418
              var reasonRefund = 'Refund of $' + parseInt(userApplied.contribution).toFixed(2) + ' because project "' + project.title + '" did start, and you were not selected.';
              var returnObj = {                                                                                      // 420
                charge: cardId,                                                                                      // 421
                amount: returnAmount * 100,                                                                          // 422
                currency: 'usd',                                                                                     // 423
                reason: reasonRefund,                                                                                // 424
                metadata: {                                                                                          // 425
                  projectId: project._id,                                                                            // 426
                  projectOwner: project.ownerId,                                                                     // 427
                  userId: userApplied.id                                                                             // 428
                }                                                                                                    //
              };                                                                                                     //
              if (Meteor.isServer) {                                                                                 // 431
                var stripe = require("stripe")(StripeServerKey);                                                     // 432
                                                                                                                     //
                stripe.refunds.create(returnObj, Meteor.bindEnvironment(function (err, refundObj) {                  // 436
                  if (Meteor.isServer) {                                                                             // 437
                    // create refund Receipt object, add to user                                                     //
                    Receipts.update({                                                                                // 439
                      userId: userApplied.id,                                                                        // 440
                      projectId: project._id                                                                         // 441
                    }, { $set: {                                                                                     //
                        refundAmount: returnAmount,                                                                  // 443
                        refunded: true,                                                                              // 444
                        receipt: refundObj                                                                           // 445
                      } });                                                                                          //
                  };                                                                                                 //
                  callback();                                                                                        // 448
                }));                                                                                                 //
              };                                                                                                     //
            }                                                                                                        //
                                                                                                                     //
            return async;                                                                                            //
          }();                                                                                                       //
                                                                                                                     //
          var final = function () {                                                                                  //
            function final() {                                                                                       // 453
              // transfer sum contributions of usersApproved to project receipt card                                 //
              var usersApproved = project.usersApproved;                                                             // 455
              var sumContributions = 0;                                                                              // 456
              usersApproved.forEach(function (u) {                                                                   // 457
                sumContributions += parseInt(u.contribution);                                                        // 458
                                                                                                                     //
                // update Receipt object to project_accepted = true                                                  //
              });                                                                                                    //
              // sum to cardId                                                                                       // 457
              var cardId = project.receipt.card.id;                                                                  // 453
              var recipientId = project.receipt.id;                                                                  // 465
              var descriptor = 'The project "' + project.title + '" is now live, and you have been awarded the total amount of contributions promised to you by your approved project members that total to $' + parseInt(sumContributions).toFixed(2);
                                                                                                                     //
              if (Meteor.isServer) {                                                                                 // 468
                var stripe = require("stripe")(StripeServerKey);                                                     // 469
                                                                                                                     //
                var transferObject = {                                                                               // 473
                  amount: sumContributions * 95,                                                                     // 474
                  currency: "usd",                                                                                   // 475
                  recipient: recipientId,                                                                            // 476
                  card: cardId,                                                                                      // 477
                  statement_descriptor: descriptor                                                                   // 478
                };                                                                                                   //
                                                                                                                     //
                Receipts.update({                                                                                    // 481
                  userId: project.ownerId,                                                                           // 482
                  projectId: project._id                                                                             // 483
                }, { $set: {                                                                                         //
                    projStarted: true,                                                                               // 485
                    outstandingBalance: 0                                                                            // 486
                  } });                                                                                              //
                                                                                                                     //
                Receipts.update({                                                                                    // 489
                  projectId: project._id                                                                             // 490
                }, { $set: {                                                                                         //
                    projStarted: true                                                                                // 492
                  } });                                                                                              //
                                                                                                                     //
                stripe.transfers.create(transferObject, Meteor.bindEnvironment(function (err, transfer) {            // 495
                  // remove all users applied from the project, and transfer receipt                                 //
                  Projects.update({ _id: project._id }, { $set: { usersApplied: [], isLive: true, transferReceipt: transfer } });
                }));                                                                                                 //
              };                                                                                                     //
                                                                                                                     //
              if (Meteor.isClient) bootbox.alert('Project "' + project.title + '" is now in PRODUCTION phase!');     // 501
            }                                                                                                        //
                                                                                                                     //
            return final;                                                                                            //
          }();                                                                                                       //
                                                                                                                     //
          var series = function () {                                                                                 //
            function series(item) {                                                                                  // 506
              if (item) {                                                                                            // 507
                async(item, function () {                                                                            // 508
                  return series(items.shift());                                                                      // 509
                });                                                                                                  //
              } else {                                                                                               //
                return final();                                                                                      // 512
              }                                                                                                      //
            }                                                                                                        //
                                                                                                                     //
            return series;                                                                                           //
          }();                                                                                                       //
                                                                                                                     //
          ;                                                                                                          // 502
                                                                                                                     //
          // A simple async series:                                                                                  //
          items = project.usersApplied;                                                                              // 505
                                                                                                                     //
          if (!items || items.length === 0) {                                                                        // 515
            final();                                                                                                 // 516
          } else {                                                                                                   //
            series(items.shift());                                                                                   // 518
          }                                                                                                          //
        })();                                                                                                        //
      }                                                                                                              //
    }                                                                                                                //
                                                                                                                     //
    return startProject;                                                                                             //
  }(),                                                                                                               //
  addProjectComment: function () {                                                                                   // 523
    function addProjectComment(slug, parent, text) {                                                                 // 523
      var user = Meteor.user();                                                                                      // 524
      if (user) {                                                                                                    // 525
        if (Meteor.isServer) {                                                                                       // 526
          check(slug, String);                                                                                       // 527
          check(parent, Number);                                                                                     // 528
          check(text, String);                                                                                       // 529
          Comments.insert({                                                                                          // 530
            projectId: slug,                                                                                         // 531
            parent: parent,                                                                                          // 532
            text: text,                                                                                              // 533
            ownerId: user._id,                                                                                       // 534
            ownerName: user.services.auth0.name,                                                                     // 535
            ownerAvatar: user.services.auth0.picture,                                                                // 536
            createdAt: moment().format("MMMM D, YYYY"),                                                              // 537
            createTimeActual: moment().format()                                                                      // 538
          });                                                                                                        //
        } else {                                                                                                     //
          $('#comment-box').val('');                                                                                 // 541
        }                                                                                                            //
      } else {                                                                                                       //
        bootbox.alert('You must be signed in to do that.');                                                          // 544
      }                                                                                                              //
    }                                                                                                                //
                                                                                                                     //
    return addProjectComment;                                                                                        //
  }(),                                                                                                               //
  addCommunicationsMessage: function () {                                                                            // 547
    function addCommunicationsMessage(slug, _type, text, targetUser) {                                               // 547
      var user = Meteor.user();                                                                                      // 548
      var project = Projects.findOne({ slug: slug });                                                                // 549
      check(slug, String);                                                                                           // 550
      check(_type, String);                                                                                          // 551
      check(text, String);                                                                                           // 552
      check(targetUser, String);                                                                                     // 553
                                                                                                                     //
      var obj = {                                                                                                    // 555
        text: text,                                                                                                  // 556
        createdAt: moment().format("MMMM D, YYYY"),                                                                  // 557
        ownerId: user._id,                                                                                           // 558
        ownerName: user.services.auth0.name,                                                                         // 559
        ownerAvatar: user.services.auth0.picture,                                                                    // 560
        unread: true                                                                                                 // 561
      };                                                                                                             //
      var idMatch = project.ownerId === user._id ? targetUser : user._id;                                            // 563
      var _q, _p;                                                                                                    // 564
      if (_type === 'applied') {                                                                                     // 565
        _q = 'usersApplied.id';                                                                                      // 566
        _p = 'usersApplied.$.communications';                                                                        // 567
      } else {                                                                                                       //
        _q = 'usersApproved.id';                                                                                     // 569
        _p = 'usersApproved.$.communications';                                                                       // 570
      };                                                                                                             //
      var query = {};                                                                                                // 572
      query['slug'] = slug;                                                                                          // 573
      query[_q] = idMatch;                                                                                           // 574
      var update = {};                                                                                               // 575
      update[_p] = obj;                                                                                              // 576
      Projects.update(query, { $push: update });                                                                     // 577
    }                                                                                                                //
                                                                                                                     //
    return addCommunicationsMessage;                                                                                 //
  }(),                                                                                                               //
  upvoteProject: function () {                                                                                       // 579
    function upvoteProject(slug) {                                                                                   // 579
      check(slug, String);                                                                                           // 580
      var query = { slug: slug };                                                                                    // 581
      var thisUser = Meteor.user()._id;                                                                              // 582
      if (!thisUser) {                                                                                               // 583
        // Make sure logged out public can't upvote it                                                               //
        throw new Meteor.Error("not-authorized");                                                                    // 585
      } else {                                                                                                       //
        if (!Projects.findOne({ slug: slug, upvotedUsers: thisUser })) {                                             // 588
          Projects.update(query, { $inc: { count: 1 } });                                                            // 589
          Projects.update(query, { $push: { upvotedUsers: thisUser } });                                             // 590
                                                                                                                     //
          if (Projects.findOne({ slug: slug, downvotedUsers: thisUser })) {                                          // 592
            Projects.update(query, { $pull: { downvotedUsers: thisUser } });                                         // 593
          };                                                                                                         //
        }                                                                                                            //
      }                                                                                                              //
    }                                                                                                                //
                                                                                                                     //
    return upvoteProject;                                                                                            //
  }(),                                                                                                               //
  downvoteProject: function () {                                                                                     // 598
    function downvoteProject(slug) {                                                                                 // 598
      check(slug, String);                                                                                           // 599
      var query = { slug: slug };                                                                                    // 600
      var thisUser = Meteor.user()._id;                                                                              // 601
      if (!thisUser) {                                                                                               // 602
        // Make sure logged out public can't downvote it                                                             //
        throw new Meteor.Error("not-authorized");                                                                    // 604
      } else {                                                                                                       //
        if (!Projects.findOne({ slug: slug, downvotedUsers: thisUser })) {                                           // 607
          Projects.update(query, { $inc: { count: -1 } });                                                           // 608
          Projects.update(query, { $push: { downvotedUsers: thisUser } });                                           // 609
                                                                                                                     //
          if (Projects.findOne({ slug: slug, upvotedUsers: thisUser })) {                                            // 611
            Projects.update(query, { $pull: { upvotedUsers: thisUser } });                                           // 612
          };                                                                                                         //
        }                                                                                                            //
      }                                                                                                              //
    }                                                                                                                //
                                                                                                                     //
    return downvoteProject;                                                                                          //
  }(),                                                                                                               //
  subscribeEmail: function () {                                                                                      // 617
    function subscribeEmail(email) {                                                                                 // 617
      check(email, String);                                                                                          // 618
      console.log(new Array(100).join('i '));                                                                        // 619
      console.log('subscribe email');                                                                                // 620
      console.log(email, '= email');                                                                                 // 621
      if (Meteor.isServer) {                                                                                         // 622
        Subscribers.insert({                                                                                         // 623
          email: email,                                                                                              // 624
          date: new Date()                                                                                           // 625
        });                                                                                                          //
      };                                                                                                             //
    }                                                                                                                //
                                                                                                                     //
    return subscribeEmail;                                                                                           //
  }(),                                                                                                               //
  // charge user                                                                                                     //
  addUserToProject: function () {                                                                                    // 630
    function addUserToProject(contribution, processedFee, slug, description, title, professionalOffer, angel) {      // 630
      check(contribution, Number);                                                                                   // 631
      check(processedFee, Number);                                                                                   // 632
      check(slug, String);                                                                                           // 633
      check(description, String);                                                                                    // 634
      check(title, String);                                                                                          // 635
      check(professionalOffer, Boolean);                                                                             // 636
      check(angel, Boolean);                                                                                         // 637
                                                                                                                     //
      var thisUser = Meteor.user()._id;                                                                              // 639
      var project = Projects.findOne({ slug: slug });                                                                // 640
      if (project.ownerId === thisUser) {                                                                            // 641
        if (Meteor.isClient) bootbox.alert("You're the owner of the project!");                                      // 642
        return;                                                                                                      // 643
      };                                                                                                             //
                                                                                                                     //
      var falsy = false;                                                                                             // 646
      project.usersApplied.forEach(function (u) {                                                                    // 647
        if (u.id === thisUser) {                                                                                     // 648
          falsy = true;                                                                                              // 649
          return;                                                                                                    // 650
        };                                                                                                           //
      });                                                                                                            //
      if (falsy && !angel) {                                                                                         // 653
        if (Meteor.isClient) bootbox.alert("You've already applied!");                                               // 654
        return;                                                                                                      // 655
      };                                                                                                             //
                                                                                                                     //
      // check if user in rejected list                                                                              //
      falsy = false;                                                                                                 // 630
      project.usersRejected = project.usersRejected || [];                                                           // 660
      project.usersRejected.forEach(function (u) {                                                                   // 661
        if (u === thisUser) {                                                                                        // 662
          falsy = true;                                                                                              // 663
          return;                                                                                                    // 664
        };                                                                                                           //
      });                                                                                                            //
      if (falsy && !angel) {                                                                                         // 667
        if (Meteor.isClient) bootbox.alert("Haven't you already applied to this project??");                         // 668
        return;                                                                                                      // 669
      };                                                                                                             //
      var _receipt;                                                                                                  // 671
      // charge card and apply                                                                                       //
      if (Meteor.isClient) {                                                                                         // 630
        StripeCheckout.open({                                                                                        // 674
          key: StripePublicKey,                                                                                      // 675
          amount: processedFee * 100,                                                                                // 676
          currency: 'usd',                                                                                           // 677
          name: 'Apply to ' + title,                                                                                 // 678
          description: description,                                                                                  // 679
          panelLabel: 'Pay Now',                                                                                     // 680
          token: function () {                                                                                       // 681
            function token(receipt) {                                                                                // 681
              // Do something with res.id                                                                            //
              // Store it in Mongo and/or create a charge on the server-side                                         //
              thisUser = { id: thisUser, contribution: contribution, receipt: receipt, communications: [], professional: professionalOffer, angel: angel };
              Projects.update({ _id: project._id }, { $push: { usersApplied: thisUser }, $inc: { applied: 1, funded: contribution } });
              // create Receipt and add to user                                                                      //
              Receipts.insert({                                                                                      // 681
                projectId: project._id,                                                                              // 688
                userId: Meteor.user()._id,                                                                           // 689
                projTitle: project.title,                                                                            // 690
                amount: processedFee,                                                                                // 691
                forProjectCreate: false,                                                                             // 692
                forProjectApply: true,                                                                               // 693
                created: new Date(),                                                                                 // 694
                receipt: receipt,                                                                                    // 695
                professional: professionalOffer,                                                                     // 696
                angel: angel                                                                                         // 697
              });                                                                                                    //
              var msg = '';                                                                                          // 699
              if (angel) {                                                                                           // 700
                msg += 'Your support was added to the project.';                                                     // 701
                msg += 'Check back in for updates of this campaign.';                                                // 702
              } else {                                                                                               //
                if (professionalOffer) {                                                                             // 704
                  msg += 'Your offer was sent for approval. ';                                                       // 705
                } else {                                                                                             //
                  msg += 'Project applied! ';                                                                        // 707
                }                                                                                                    //
                msg += 'Check back in for updates to your status.';                                                  // 709
              }                                                                                                      //
              bootbox.alert(msg);                                                                                    // 711
            }                                                                                                        //
                                                                                                                     //
            return token;                                                                                            //
          }()                                                                                                        //
        });                                                                                                          //
      };                                                                                                             //
    }                                                                                                                //
                                                                                                                     //
    return addUserToProject;                                                                                         //
  }(),                                                                                                               //
  supportProjectForGift: function () {                                                                               // 716
    function supportProjectForGift(contribution, processedFee, slug, description, title, gift) {                     // 716
      check(contribution, Number);                                                                                   // 717
      check(processedFee, Number);                                                                                   // 718
      check(slug, String);                                                                                           // 719
      check(description, String);                                                                                    // 720
      check(title, String);                                                                                          // 721
      check(professionalOffer, Boolean);                                                                             // 722
      check(angel, Boolean);                                                                                         // 723
                                                                                                                     //
      var thisUser = Meteor.user()._id;                                                                              // 725
      var project = Projects.findOne({ slug: slug });                                                                // 726
      if (project.ownerId === thisUser) {                                                                            // 727
        if (Meteor.isClient) bootbox.alert("You're the owner of the project!");                                      // 728
        return;                                                                                                      // 729
      };                                                                                                             //
                                                                                                                     //
      var _receipt;                                                                                                  // 733
      // charge card and apply                                                                                       //
      if (Meteor.isClient) {                                                                                         // 716
        StripeCheckout.open({                                                                                        // 736
          key: StripePublicKey,                                                                                      // 737
          amount: processedFee * 100,                                                                                // 738
          currency: 'usd',                                                                                           // 739
          name: 'Apply to ' + title,                                                                                 // 740
          description: description,                                                                                  // 741
          panelLabel: 'Pay Now',                                                                                     // 742
          token: function () {                                                                                       // 743
            function token(receipt) {                                                                                // 743
              // Do something with res.id                                                                            //
              // Store it in Mongo and/or create a charge on the server-side                                         //
              thisUser = { id: thisUser, contribution: contribution, receipt: receipt, communications: [], gift: gift };
              Projects.update({ _id: project._id }, { $push: { usersApplied: thisUser }, $inc: { applied: 1, funded: contribution }, $pull: { gifts: gift } });
              // create Receipt and add to user                                                                      //
              Receipts.insert({                                                                                      // 743
                projectId: project._id,                                                                              // 750
                userId: Meteor.user()._id,                                                                           // 751
                projTitle: project.title,                                                                            // 752
                amount: processedFee,                                                                                // 753
                forProjectCreate: false,                                                                             // 754
                forProjectApply: true,                                                                               // 755
                created: new Date(),                                                                                 // 756
                receipt: receipt,                                                                                    // 757
                professional: professionalOffer,                                                                     // 758
                angel: angel                                                                                         // 759
              });                                                                                                    //
              var msg = 'Your support has been sent, and your gift will be processed.';                              // 761
              bootbox.alert(msg);                                                                                    // 762
            }                                                                                                        //
                                                                                                                     //
            return token;                                                                                            //
          }()                                                                                                        //
        });                                                                                                          //
      };                                                                                                             //
    }                                                                                                                //
                                                                                                                     //
    return supportProjectForGift;                                                                                    //
  }(),                                                                                                               //
  // update accept count of project                                                                                  //
  acceptUserToProject: function () {                                                                                 // 768
    function acceptUserToProject(userId, contribution, slug) {                                                       // 768
      contribution = parseInt(contribution);                                                                         // 769
      check(contribution, Number);                                                                                   // 770
      check(userId, String);                                                                                         // 771
      check(slug, String);                                                                                           // 772
      var project = Projects.findOne({ slug: slug });                                                                // 773
      var truthy = true;                                                                                             // 774
      project.usersApproved = project.usersApproved || [];                                                           // 775
      project.usersApproved.forEach(function (user) {                                                                // 776
        if (user.id === thisUser) {                                                                                  // 777
          truthy = false;                                                                                            // 778
          return;                                                                                                    // 779
        };                                                                                                           //
      });                                                                                                            //
      if (truthy) {                                                                                                  // 782
        var thisUser = { id: userId, contribution: contribution, communications: [] };                               // 783
        var query = { slug: slug };                                                                                  // 784
        Projects.update(query, { $push: { usersApproved: thisUser, contribution: contribution }, $pull: { 'usersApplied': { id: thisUser.id } }, $inc: { approved: 1 } });
        Boards.update(query, { $push: { members: {                                                                   // 786
              "userId": thisUser.id,                                                                                 // 787
              "isAdmin": false                                                                                       // 788
            } } });                                                                                                  //
        Receipts.update({                                                                                            // 790
          projectId: project._id,                                                                                    // 791
          userId: userId }, { $set: {                                                                                // 792
            projAccepted: true                                                                                       // 793
          } });                                                                                                      //
      }                                                                                                              //
    }                                                                                                                //
                                                                                                                     //
    return acceptUserToProject;                                                                                      //
  }(),                                                                                                               //
  // send refund to single project applicant                                                                         //
  rejectUserFromProject: function () {                                                                               // 798
    function rejectUserFromProject(userId, slug) {                                                                   // 798
      check(userId, String);                                                                                         // 799
      check(slug, String);                                                                                           // 800
      var project = Projects.findOne({ slug: slug });                                                                // 801
      var truthy = true;                                                                                             // 802
      project.usersRejected = project.usersRejected || [];                                                           // 803
      project.usersApplied.forEach(function (u) {                                                                    // 804
        if (u.id === userId) {                                                                                       // 805
          // refund account                                                                                          //
          var cardId = u.receipt.id;                                                                                 // 807
          var returnAmount = u.contribution;                                                                         // 808
          var reasonRefund = 'Refund of $' + parseInt(u.contribution).toFixed(2) + ' because project "' + project.title + '" did not select you.';
          var returnObj = {                                                                                          // 810
            charge: cardId,                                                                                          // 811
            amount: returnAmount * 100,                                                                              // 812
            currency: 'usd',                                                                                         // 813
            reason: reasonRefund,                                                                                    // 814
            metadata: {                                                                                              // 815
              projectId: project._id,                                                                                // 816
              projectOwner: project.ownerId,                                                                         // 817
              userId: u.id                                                                                           // 818
            }                                                                                                        //
          };                                                                                                         //
                                                                                                                     //
          if (Meteor.isServer) {                                                                                     // 822
                                                                                                                     //
            var stripe = require("stripe")(testPublishableKey);                                                      // 824
            stripe.refunds.create(returnObj, Meteor.bindEnvironment(function (err, refundObj) {                      // 827
              Users.update({ _id: userId }, { $push: { contributionRefunds: refundObj }, $push: { receiptsHistory: {
                    project: {                                                                                       // 829
                      name: project.title,                                                                           // 830
                      slug: project.slug,                                                                            // 831
                      date: project.createdAt                                                                        // 832
                    },                                                                                               //
                    offer: u.contribution,                                                                           // 834
                    receipt1: u.receipt,                                                                             // 835
                    receipt2: refundObj,                                                                             // 836
                    type: 'refund'                                                                                   // 837
                  } } });                                                                                            //
              Receipts.update({                                                                                      // 839
                projectId: project._id,                                                                              // 840
                userId: userId                                                                                       // 841
              }, { $set: {                                                                                           //
                  refunded: true,                                                                                    // 843
                  receipt: refundObj                                                                                 // 844
                } });                                                                                                //
              Projects.update({ slug: slug }, { $push: { usersRejected: {                                            // 846
                    id: u.id,                                                                                        // 847
                    receipt: u.receipt                                                                               // 848
                  } },                                                                                               //
                $pull: { usersApplied: { id: u.id } }                                                                // 850
              });                                                                                                    //
            }));                                                                                                     //
          };                                                                                                         //
        };                                                                                                           //
      });                                                                                                            //
    }                                                                                                                //
                                                                                                                     //
    return rejectUserFromProject;                                                                                    //
  }(),                                                                                                               //
  // close project                                                                                                   //
  closeProject: function () {                                                                                        // 858
    function closeProject(slug) {                                                                                    // 858
      check(slug, String);                                                                                           // 859
      if (Meteor.isServer) {                                                                                         // 860
        var project = Projects.findOne({ slug: slug });                                                              // 861
        // TODO, update influence scores                                                                             //
        var board = Boards.findOne({ slug: slug });                                                                  // 860
        Projects.update({ slug: slug }, { archived: true });                                                         // 864
        Boards.update({ slug: slug }, { archived: true });                                                           // 865
        Cards.update({ boardId: board._id }, { archived: true });                                                    // 866
        Receipts.update({                                                                                            // 867
          projectId: project._id                                                                                     // 868
        }, { $set: {                                                                                                 //
            projFinished: true                                                                                       // 870
          } });                                                                                                      //
      };                                                                                                             //
      if (Meteor.isClient) {                                                                                         // 873
        bootbox.confirm('The project is history.', function () {                                                     // 874
          Router.go('Home');                                                                                         // 875
        });                                                                                                          //
      };                                                                                                             //
    }                                                                                                                //
                                                                                                                     //
    return closeProject;                                                                                             //
  }(),                                                                                                               //
  // refund users on expired projects                                                                                //
  projectsHousekeeping: function () {                                                                                // 880
    function projectsHousekeeping() {                                                                                // 880
      var projects = Projects.find({ archived: false });                                                             // 881
      projects.forEach(function (proj) {                                                                             // 882
        if (--proj.duration < 1) {                                                                                   // 883
          Projects.update(proj._id, { $set: { archived: true } });                                                   // 884
        } else {                                                                                                     //
          Projects.update(proj._id, { $set: { duration: proj.duration - 1 } });                                      // 886
        };                                                                                                           //
      });                                                                                                            //
    }                                                                                                                //
                                                                                                                     //
    return projectsHousekeeping;                                                                                     //
  }()                                                                                                                //
});                                                                                                                  //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"server":{"publications":{"boards.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/publications/boards.js                                                                                     //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
// This is the publication used to display the board list. We publish all the                                        //
// non-archived boards:                                                                                              //
// 1. that the user is a member of                                                                                   //
// 2. the user has starred                                                                                           //
Meteor.publish('boards', function () {                                                                               // 5
    // Ensure that the user is connected                                                                             //
    check(this.userId, String);                                                                                      // 7
                                                                                                                     //
    // Defensive programming to verify that starredBoards has the expected                                           //
    // format -- since the field is in the `profile` a user can modify it.                                           //
    var starredBoards = Users.findOne(this.userId).profile.starredBoards || [];                                      // 5
    check(starredBoards, [String]);                                                                                  // 12
                                                                                                                     //
    return Boards.find({                                                                                             // 14
        archived: false,                                                                                             // 15
        $or: [{ 'members.userId': this.userId }, { _id: { $in: starredBoards } }]                                    // 16
    }, {                                                                                                             //
        fields: {                                                                                                    // 21
            _id: 1,                                                                                                  // 22
            slug: 1,                                                                                                 // 23
            title: 1,                                                                                                // 24
            background: 1                                                                                            // 25
        }                                                                                                            //
    });                                                                                                              //
});                                                                                                                  //
                                                                                                                     //
Meteor.publishComposite('board', function (boardId, slug) {                                                          // 30
    check(boardId, String);                                                                                          // 31
    check(slug, String);                                                                                             // 32
    var user = Users.findOne(this.userId);                                                                           // 33
    return {                                                                                                         // 34
        find: function () {                                                                                          // 35
            function find() {                                                                                        // 35
                return Boards.find({                                                                                 // 36
                    _id: boardId,                                                                                    // 37
                    slug: slug,                                                                                      // 38
                    archived: false,                                                                                 // 39
                    $or: [                                                                                           // 40
                    // If the board is not public the user has to be a member of                                     //
                    // it to see it.                                                                                 //
                    { permission: 'public' }, { 'members.userId': this.userId }]                                     // 43
                }, { limit: 1 });                                                                                    //
            }                                                                                                        //
                                                                                                                     //
            return find;                                                                                             //
        }(),                                                                                                         //
        // XXX For efficiency we shouldn't publish all activities and comments                                       //
        // in this publication, and instead use the card publication for that                                        //
        // purpose.                                                                                                  //
        children: [                                                                                                  // 51
        // Lists                                                                                                     //
        {                                                                                                            // 53
            find: function () {                                                                                      // 54
                function find(board) {                                                                               // 54
                    return Lists.find({                                                                              // 55
                        boardId: board._id                                                                           // 56
                    });                                                                                              //
                }                                                                                                    //
                                                                                                                     //
                return find;                                                                                         //
            }()                                                                                                      //
        },                                                                                                           //
                                                                                                                     //
        // Cards and cards comments                                                                                  //
        // XXX Originally we were publishing the card documents as a child                                           //
        // of the list publication defined above using the following                                                 //
        // selector `{ listId: list._id }`. But it was causing a race                                                //
        // condition in publish-composite, that I documented here:                                                   //
        //                                                                                                           //
        //   https://github.com/englue/meteor-publish-composite/issues/29                                            //
        //                                                                                                           //
        // I then tried to replace publish-composite by cottz:publish, but                                           //
        // it had a similar problem:                                                                                 //
        //                                                                                                           //
        //   https://github.com/Goluis/cottz-publish/issues/4                                                        //
        //   https://github.com/libreboard/libreboard/pull/78                                                        //
        //                                                                                                           //
        // The current state of relational publishing in meteor is a bit                                             //
        // sad, there are a lot of various packages, with various APIs, some                                         //
        // of them are unmaintained. Fortunately this is something that will                                         //
        // be fixed by meteor-core at some point:                                                                    //
        //                                                                                                           //
        //   https://trello.com/c/BGvIwkEa/48-easy-joins-in-subscriptions                                            //
        //                                                                                                           //
        // And in the meantime our code below works pretty well -- it's not                                          //
        // even a hack!                                                                                              //
        {                                                                                                            // 84
            find: function () {                                                                                      // 85
                function find(board) {                                                                               // 85
                    return Cards.find({                                                                              // 86
                        boardId: board._id                                                                           // 87
                    });                                                                                              //
                }                                                                                                    //
                                                                                                                     //
                return find;                                                                                         //
            }(),                                                                                                     //
                                                                                                                     //
            children: [                                                                                              // 91
            // comments                                                                                              //
            {                                                                                                        // 93
                find: function () {                                                                                  // 94
                    function find(card) {                                                                            // 94
                        return CardComments.find({                                                                   // 95
                            cardId: card._id                                                                         // 96
                        });                                                                                          //
                    }                                                                                                //
                                                                                                                     //
                    return find;                                                                                     //
                }()                                                                                                  //
            },                                                                                                       //
            // Attachments                                                                                           //
            {                                                                                                        // 101
                find: function () {                                                                                  // 102
                    function find(card) {                                                                            // 102
                        return Attachments.find({                                                                    // 103
                            cardId: card._id                                                                         // 104
                        });                                                                                          //
                    }                                                                                                //
                                                                                                                     //
                    return find;                                                                                     //
                }()                                                                                                  //
            }]                                                                                                       //
        },                                                                                                           //
                                                                                                                     //
        // Board members                                                                                             //
        {                                                                                                            // 112
            find: function () {                                                                                      // 113
                function find(board) {                                                                               // 113
                    return Users.find({                                                                              // 114
                        '_id': { $in: _.pluck(board.members, 'userId') }                                             // 115
                    });                                                                                              //
                }                                                                                                    //
                                                                                                                     //
                return find;                                                                                         //
            }()                                                                                                      //
        },                                                                                                           //
                                                                                                                     //
        // Activities                                                                                                //
        {                                                                                                            // 121
            find: function () {                                                                                      // 122
                function find(board) {                                                                               // 122
                    return Activities.find({                                                                         // 123
                        boardId: board._id                                                                           // 124
                    });                                                                                              //
                }                                                                                                    //
                                                                                                                     //
                return find;                                                                                         //
            }(),                                                                                                     //
            children: [                                                                                              // 127
            // Activities members. In general activity members are                                                   //
            // already published in the board member publication above,                                              //
            // but it can be the case that a board member was removed                                                //
            // and we still want to read his activity history.                                                       //
            // XXX A more efficient way to do this would be to keep a                                                //
            // {active: Boolean} field in the `board.members` so we can                                              //
            // publish former board members in one single publication,                                               //
            // and have a easy way to distinguish between current and                                                //
            // former members.                                                                                       //
            {                                                                                                        // 137
                find: function () {                                                                                  // 138
                    function find(activity) {                                                                        // 138
                        if (activity.memberId) return Users.find(activity.memberId);                                 // 139
                    }                                                                                                //
                                                                                                                     //
                    return find;                                                                                     //
                }()                                                                                                  //
            }]                                                                                                       //
        }]                                                                                                           //
    };                                                                                                               //
});                                                                                                                  //
                                                                                                                     //
Meteor.publish('gotoBoard', function (slug) {                                                                        // 149
    check(slug, String);                                                                                             // 150
    return Boards.find({ slug: slug });                                                                              // 151
});                                                                                                                  //
                                                                                                                     //
Meteor.publish('getTasks', function (boardId) {                                                                      // 154
    check(boardId, String);                                                                                          // 155
    return Cards.find({                                                                                              // 156
        boardId: boardId                                                                                             // 157
    });                                                                                                              //
});                                                                                                                  //
                                                                                                                     //
Meteor.publish('getMyTasks', function (boardId) {                                                                    // 161
    check(boardId, String);                                                                                          // 162
    return Cards.find({                                                                                              // 163
        boardId: boardId,                                                                                            // 164
        userId: this.userId                                                                                          // 165
    });                                                                                                              //
});                                                                                                                  //
                                                                                                                     //
Meteor.publish('getAssets', function (boardId) {                                                                     // 169
    check(boardId, String);                                                                                          // 170
    return Attachments.find({                                                                                        // 171
        boardId: boardId                                                                                             // 172
    });                                                                                                              //
});                                                                                                                  //
                                                                                                                     //
Meteor.publish('getExpiringTasks', function (boardId) {                                                              // 176
    check(boardId, String);                                                                                          // 177
    // sort by date descending, limit to 5 items                                                                     //
    return Cards.find({                                                                                              // 176
        boardId: boardId                                                                                             // 180
    }, {                                                                                                             //
        sort: {                                                                                                      // 182
            createdAt: -1                                                                                            // 183
        },                                                                                                           //
        limit: 5                                                                                                     // 185
    });                                                                                                              //
});                                                                                                                  //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"cards.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/publications/cards.js                                                                                      //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
Meteor.publish('card', function (cardId) {                                                                           // 1
    check(cardId, String);                                                                                           // 2
    return Cards.find({ _id: cardId });                                                                              // 3
});                                                                                                                  //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"projects.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/publications/projects.js                                                                                   //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
Meteor.publish('projectsList', function () {                                                                         // 1
  // Ensure that the user is connected                                                                               //
  //check(this.userId, String);                                                                                      //
  return Projects.find({                                                                                             // 4
    archived: false                                                                                                  // 5
  });                                                                                                                //
});                                                                                                                  //
                                                                                                                     //
Meteor.publish('activeProjects', function () {                                                                       // 9
  // Ensure that the user is connected                                                                               //
  check(this.userId, String);                                                                                        // 11
  return Projects.find({                                                                                             // 12
    $and: [{ archived: false }, { $or: [{ ownerId: this.userId }, { usersApproved: { $elemMatch: { id: this.userId } } }] }]
  });                                                                                                                //
});                                                                                                                  //
                                                                                                                     //
Meteor.publish('receiptsHistory', function () {                                                                      // 23
  check(this.userId, String);                                                                                        // 24
  return Users.find({ _id: this.userId });                                                                           // 25
});                                                                                                                  //
                                                                                                                     //
Meteor.publish('userActiveProjects', function (_id) {                                                                // 28
  // Ensure that the user is connected                                                                               //
  check(_id, String);                                                                                                // 30
  return Projects.find({                                                                                             // 31
    $and: [{ archived: false }, { ownerId: _id }]                                                                    // 32
  });                                                                                                                //
});                                                                                                                  //
                                                                                                                     //
Meteor.publish('activeProjectsApplied', function (_id) {                                                             // 39
  // Ensure that the user is connected                                                                               //
  check(_id, String);                                                                                                // 41
  return Projects.find({                                                                                             // 42
    $and: [{ archived: false }, { usersApplied: { $elemMatch: { id: _id } } }]                                       // 43
  });                                                                                                                //
});                                                                                                                  //
                                                                                                                     //
Meteor.publish('activeProjectsApproved', function (_id) {                                                            // 50
  // Ensure that the user is connected                                                                               //
  check(_id, String);                                                                                                // 52
  return Projects.find({                                                                                             // 53
    $and: [{ archived: false }, { usersApproved: { $elemMatch: { id: _id } } }]                                      // 54
  });                                                                                                                //
});                                                                                                                  //
                                                                                                                     //
Meteor.publish('getProject', function (slug) {                                                                       // 61
  check(slug, String);                                                                                               // 62
  return Projects.find({ slug: slug });                                                                              // 63
});                                                                                                                  //
                                                                                                                     //
Meteor.publish('commentsList', function (slug) {                                                                     // 66
  check(slug, String);                                                                                               // 67
  return Comments.find({ projectId: slug });                                                                         // 68
});                                                                                                                  //
                                                                                                                     //
Meteor.publish('tagsList', function () {                                                                             // 71
  return Tags.find();                                                                                                // 72
});                                                                                                                  //
                                                                                                                     //
Meteor.publish('usersList', function () {                                                                            // 75
  return Meteor.users.find({});                                                                                      // 76
});                                                                                                                  //
                                                                                                                     //
Meteor.publish('getUser', function (_id) {                                                                           // 79
  check(_id, String);                                                                                                // 80
  return Meteor.users.find({ '_id': _id });                                                                          // 81
});                                                                                                                  //
                                                                                                                     //
Meteor.publish('paidForProjects', function () {                                                                      // 84
  check(this.userId, String);                                                                                        // 85
  // get projects live with accepted user = this.userId                                                              //
  return Projects.find({ live: true, usersApproved: { $elemMatch: { id: this.userId } } });                          // 84
});                                                                                                                  //
                                                                                                                     //
Meteor.publish('projectsHousekeeping', function () {                                                                 // 90
  console.log('do projectsHousekeeping here');                                                                       // 91
});                                                                                                                  //
                                                                                                                     //
/*  WITH FIELDS ON                                                                                                   //
                                                                                                                     //
  Meteor.publish('getUser', function(meetupId) {                                                                     //
    check(meetupId, String);                                                                                         //
    return Meteor.users.find({'profile.meetupId': meetupId}, {fields: {                                              //
      _id: 1,                                                                                                        //
      "profile.bio": 1,                                                                                              //
      "profile.createdAt": 1,                                                                                        //
      "profile.meetupId": 1,                                                                                         //
      "profile.name": 1,                                                                                             //
      "profile.socialLinks": 1,                                                                                      //
      "profile.thumbnailUrl": 1                                                                                      //
    }});                                                                                                             //
  });                                                                                                                //
                                                                                                                     //
*/                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"receipts.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/publications/receipts.js                                                                                   //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
Meteor.publish('getReceipts', function () {                                                                          // 1
    check(this.userId, String);                                                                                      // 2
    return Receipts.find({                                                                                           // 3
        userId: this.userId                                                                                          // 4
    });                                                                                                              //
});                                                                                                                  //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"users.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/publications/users.js                                                                                      //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
/*                                                                                                                   //
*                                                                                                                    //
* To make this available on the client, use a reactive cursor,                                                       //
* such as by creating a publication on the server:                                                                   //
*/                                                                                                                   //
Meteor.publish('connectUser', function () {                                                                          // 6
                                                                                                                     //
    var user = Users.findOne(this.userId);                                                                           // 8
                                                                                                                     //
    // if user then ready subscribe                                                                                  //
    if (user) {                                                                                                      // 6
                                                                                                                     //
        // status offline then                                                                                       //
        if (!user.status) {                                                                                          // 14
                                                                                                                     //
            // User profile.status update online                                                                     //
            Users.update(this.userId, { $set: { 'status': 'online' } });                                             // 17
        }                                                                                                            //
                                                                                                                     //
        // user close subscribe onStop callback update user.profile.status 'offline'                                 //
        this.onStop(function () {                                                                                    // 11
                                                                                                                     //
            // update offline user                                                                                   //
            Users.update(this.userId, { $set: { 'status': false } });                                                // 24
        });                                                                                                          //
    }                                                                                                                //
                                                                                                                     //
    // subscribe ready                                                                                               //
    this.ready();                                                                                                    // 6
});                                                                                                                  //
                                                                                                                     //
Meteor.publish('profile', function (_id) {                                                                           // 33
    check(_id, Object);                                                                                              // 34
    return Users.find({ '_id': _id });                                                                               // 35
});                                                                                                                  //
                                                                                                                     //
Meteor.publish('getUsers', function () {                                                                             // 38
    return Users.find({});                                                                                           // 39
});                                                                                                                  //
                                                                                                                     //
Meteor.publish('getMe', function () {                                                                                // 42
    if (this.userId) {                                                                                               // 43
        return Users.find({ _id: this.userId });                                                                     // 44
    } else {                                                                                                         //
        this.ready();                                                                                                // 46
    }                                                                                                                //
});                                                                                                                  //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"accounts.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/accounts.js                                                                                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
Meteor.startup(function () {                                                                                         // 1
  Accounts.onCreateUser(function (options, user) {                                                                   // 2
                                                                                                                     //
    return user;                                                                                                     // 4
  });                                                                                                                //
});                                                                                                                  //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"cron.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/cron.js                                                                                                    //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
Meteor.startup(function () {                                                                                         // 1
  SyncedCron.options = {                                                                                             // 2
    log: true,                                                                                                       // 3
    collectionName: 'Housekeeping',                                                                                  // 4
    utc: true                                                                                                        // 5
  };                                                                                                                 //
                                                                                                                     //
  SyncedCron.add({                                                                                                   // 8
    name: 'projectsHousekeeping',                                                                                    // 9
    schedule: function () {                                                                                          // 10
      function schedule(parser) {                                                                                    // 10
        return parser.text('every weekday');                                                                         // 11
      }                                                                                                              //
                                                                                                                     //
      return schedule;                                                                                               //
    }(),                                                                                                             //
    job: function () {                                                                                               // 13
      function job() {                                                                                               // 13
        Meteor.call('projectsHousekeeping');                                                                         // 14
      }                                                                                                              //
                                                                                                                     //
      return job;                                                                                                    //
    }()                                                                                                              //
  });                                                                                                                //
                                                                                                                     //
  SyncedCron.start();                                                                                                // 18
});                                                                                                                  //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"email.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/email.js                                                                                                   //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
// process.env.MAIL_URL='smtp://postmaster%40BlendLA.meteor.com:9c0ae480c2af7804d7052b06ba9480b7@smtp.mailgun.org:587';
                                                                                                                     //
Meteor.methods({                                                                                                     // 3
	email: function () {                                                                                                // 4
		function email(options) {                                                                                          // 4
			// 		options['to'] = 'info@produs.Us';                                                                            //
			// 		Email.send(options);                                                                                         //
		}                                                                                                                  //
                                                                                                                     //
		return email;                                                                                                      //
	}()                                                                                                                 //
});                                                                                                                  //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"migrations.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/migrations.js                                                                                              //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
// Anytime you change the schema of one of the collection in a non-backward                                          //
// compatible way you have to write a migration in this file using the following                                     //
// API:                                                                                                              //
//                                                                                                                   //
//   Migrations.add(name, migrationCallback, optionalOrder);                                                         //
                                                                                                                     //
Migrations.add('board-background-color', function () {                                                               // 7
    var defaultColor = '#16A085';                                                                                    // 8
    Boards.update({                                                                                                  // 9
        background: {                                                                                                // 10
            $exists: false                                                                                           // 11
        }                                                                                                            //
    }, {                                                                                                             //
        $set: {                                                                                                      // 14
            background: {                                                                                            // 15
                type: 'color',                                                                                       // 16
                color: defaultColor                                                                                  // 17
            }                                                                                                        //
        }                                                                                                            //
    }, {                                                                                                             //
        multi: true                                                                                                  // 21
    });                                                                                                              //
});                                                                                                                  //
                                                                                                                     //
Migrations.add('lowercase-board-permission', function () {                                                           // 25
    _.forEach(['Public', 'Private'], function (permission) {                                                         // 26
        Boards.update({ permission: permission }, { $set: { permission: permission.toLowerCase() } }, { multi: true });
    });                                                                                                              //
});                                                                                                                  //
                                                                                                                     //
// Security migration: see https://github.com/libreboard/libreboard/issues/99                                        //
Migrations.add('change-attachments-type-for-non-images', function () {                                               // 36
    var newTypeForNonImage = "application/octet-stream";                                                             // 37
    Attachments.find().forEach(function (file) {                                                                     // 38
        if (!file.isImage()) {                                                                                       // 39
            Attachments.update(file._id, {                                                                           // 40
                $set: {                                                                                              // 41
                    "original.type": newTypeForNonImage,                                                             // 42
                    "copies.attachments.type": newTypeForNonImage                                                    // 43
                }                                                                                                    //
            });                                                                                                      //
        }                                                                                                            //
    });                                                                                                              //
});                                                                                                                  //
                                                                                                                     //
Migrations.add('card-covers', function () {                                                                          // 50
    Cards.find().forEach(function (card) {                                                                           // 51
        var cover = Attachments.findOne({ cardId: card._id, cover: true });                                          // 52
        if (cover) {                                                                                                 // 53
            Cards.update(card._id, { $set: { coverId: cover._id } });                                                // 54
        }                                                                                                            //
    });                                                                                                              //
    Attachments.update({}, { $unset: { cover: "" } }, { multi: true });                                              // 57
});                                                                                                                  //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"stripe.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/stripe.js                                                                                                  //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
Meteor.startup(function () {});                                                                                      // 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"collections":{"activities.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// collections/activities.js                                                                                         //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
// Activities don't need a schema because they are always set from the a trusted                                     //
// environment - the server - and there is no risk that a user change the logic                                      //
// we use with this collection. Moreover using a schema for this collection                                          //
// would be difficult (different activities have different fields) and wouldn't                                      //
// bring any direct advantage.                                                                                       //
//                                                                                                                   //
// XXX The activities API is not so nice and need some functionalities. For                                          //
// instance if a user archive a card, and un-archive it a few seconds later                                          //
// we should remove both activities assuming it was an error the user decided                                        //
// to revert.                                                                                                        //
                                                                                                                     //
Activities = new Mongo.Collection('activities');                                                                     // 12
                                                                                                                     //
Activities.helpers({                                                                                                 // 14
    board: function () {                                                                                             // 15
        function board() {                                                                                           // 15
            return Boards.findOne(this.boardId);                                                                     // 16
        }                                                                                                            //
                                                                                                                     //
        return board;                                                                                                //
    }(),                                                                                                             //
    user: function () {                                                                                              // 18
        function user() {                                                                                            // 18
            return Users.findOne(this.userId);                                                                       // 19
        }                                                                                                            //
                                                                                                                     //
        return user;                                                                                                 //
    }(),                                                                                                             //
    member: function () {                                                                                            // 21
        function member() {                                                                                          // 21
            return Users.findOne(this.memberId);                                                                     // 22
        }                                                                                                            //
                                                                                                                     //
        return member;                                                                                               //
    }(),                                                                                                             //
    list: function () {                                                                                              // 24
        function list() {                                                                                            // 24
            return Lists.findOne(this.listId);                                                                       // 25
        }                                                                                                            //
                                                                                                                     //
        return list;                                                                                                 //
    }(),                                                                                                             //
    oldList: function () {                                                                                           // 27
        function oldList() {                                                                                         // 27
            return Lists.findOne(this.oldListId);                                                                    // 28
        }                                                                                                            //
                                                                                                                     //
        return oldList;                                                                                              //
    }(),                                                                                                             //
    card: function () {                                                                                              // 30
        function card() {                                                                                            // 30
            return Cards.findOne(this.cardId);                                                                       // 31
        }                                                                                                            //
                                                                                                                     //
        return card;                                                                                                 //
    }(),                                                                                                             //
    comment: function () {                                                                                           // 33
        function comment() {                                                                                         // 33
            return CardComments.findOne(this.commentId);                                                             // 34
        }                                                                                                            //
                                                                                                                     //
        return comment;                                                                                              //
    }(),                                                                                                             //
    attachment: function () {                                                                                        // 36
        function attachment() {                                                                                      // 36
            return Attachments.findOne(this.attachmentId);                                                           // 37
        }                                                                                                            //
                                                                                                                     //
        return attachment;                                                                                           //
    }()                                                                                                              //
});                                                                                                                  //
                                                                                                                     //
Activities.before.insert(function (userId, doc) {                                                                    // 41
    doc.createdAt = new Date();                                                                                      // 42
});                                                                                                                  //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"attachments.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// collections/attachments.js                                                                                        //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
Attachments = new FS.Collection("attachments", {                                                                     // 1
    stores: [                                                                                                        // 2
    // XXX Add a new store for cover thumbnails so we don't load big images                                          //
    // in the general board view                                                                                     //
    new FS.Store.GridFS("attachments")]                                                                              // 5
});                                                                                                                  //
                                                                                                                     //
Attachments.allow({                                                                                                  // 9
    insert: function () {                                                                                            // 10
        function insert(userId, doc) {                                                                               // 10
            return allowIsBoardMember(userId, Boards.findOne(doc.boardId));                                          // 11
        }                                                                                                            //
                                                                                                                     //
        return insert;                                                                                               //
    }(),                                                                                                             //
    update: function () {                                                                                            // 13
        function update(userId, doc) {                                                                               // 13
            return allowIsBoardMember(userId, Boards.findOne(doc.boardId));                                          // 14
        }                                                                                                            //
                                                                                                                     //
        return update;                                                                                               //
    }(),                                                                                                             //
    remove: function () {                                                                                            // 16
        function remove(userId, doc) {                                                                               // 16
            return allowIsBoardMember(userId, Boards.findOne(doc.boardId));                                          // 17
        }                                                                                                            //
                                                                                                                     //
        return remove;                                                                                               //
    }(),                                                                                                             //
    // We authorize the attachment download either:                                                                  //
    // - if the board is public, everyone (even unconnected) can download it                                         //
    // - if the board is private, only board members can download it                                                 //
    //                                                                                                               //
    // XXX We have a bug with the userId verification:                                                               //
    //                                                                                                               //
    //   https://github.com/CollectionFS/Meteor-CollectionFS/issues/449                                              //
    //                                                                                                               //
    download: function () {                                                                                          // 27
        function download(userId, doc) {                                                                             // 27
            var query = {                                                                                            // 28
                $or: [{ 'members.userId': userId }, { permission: 'public' }]                                        // 29
            };                                                                                                       //
            return !!Boards.findOne(doc.boardId, query);                                                             // 34
        }                                                                                                            //
                                                                                                                     //
        return download;                                                                                             //
    }(),                                                                                                             //
    fetch: ['boardId']                                                                                               // 36
});                                                                                                                  //
                                                                                                                     //
// XXX Enforce a schema for the Attachments CollectionFS                                                             //
                                                                                                                     //
Attachments.files.before.insert(function (userId, doc) {                                                             // 41
    var file = new FS.File(doc);                                                                                     // 42
    doc.userId = userId;                                                                                             // 43
                                                                                                                     //
    // If the uploaded document is not an image we need to enforce browser                                           //
    // download instead of execution. This is particularly important for HTML                                        //
    // files that the browser will just execute if we don't serve them with the                                      //
    // appropriate `application/octet-stream` MIME header which can lead to user                                     //
    // data leaks. I imagine other formats (like PDF) can also be attack                                             //
    // vectors.                                                                                                      //
    // See https://github.com/libreboard/libreboard/issues/99                                                        //
    // XXX Should we use `beforeWrite` option of CollectionFS instead of                                             //
    // collection-hooks?                                                                                             //
    if (!file.isImage()) {                                                                                           // 41
        file.original.type = "application/octet-stream";                                                             // 55
    }                                                                                                                //
});                                                                                                                  //
                                                                                                                     //
isServer(function () {                                                                                               // 59
    Attachments.files.after.insert(function (userId, doc) {                                                          // 60
        Activities.insert({                                                                                          // 61
            type: 'card',                                                                                            // 62
            activityType: "addAttachment",                                                                           // 63
            attachmentId: doc._id,                                                                                   // 64
            boardId: doc.boardId,                                                                                    // 65
            cardId: doc.cardId,                                                                                      // 66
            userId: userId                                                                                           // 67
        });                                                                                                          //
    });                                                                                                              //
                                                                                                                     //
    Attachments.files.after.remove(function (userId, doc) {                                                          // 71
        Activities.remove({                                                                                          // 72
            attachmentId: doc._id                                                                                    // 73
        });                                                                                                          //
    });                                                                                                              //
});                                                                                                                  //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"boards.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// collections/boards.js                                                                                             //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
Boards = new Mongo.Collection('boards');                                                                             // 1
                                                                                                                     //
Boards.attachSchema(new SimpleSchema({                                                                               // 3
    title: {                                                                                                         // 4
        type: String                                                                                                 // 5
    },                                                                                                               //
    slug: {                                                                                                          // 7
        type: String                                                                                                 // 8
    },                                                                                                               //
    purpose: {                                                                                                       // 10
        type: String                                                                                                 // 11
    },                                                                                                               //
    archived: {                                                                                                      // 13
        type: Boolean                                                                                                // 14
    },                                                                                                               //
    createdAt: {                                                                                                     // 16
        type: Date,                                                                                                  // 17
        denyUpdate: true                                                                                             // 18
    },                                                                                                               //
    createdBy: {                                                                                                     // 20
        type: String                                                                                                 // 21
    },                                                                                                               //
    // XXX Inconsistent field naming                                                                                 //
    modifiedAt: {                                                                                                    // 24
        type: Date,                                                                                                  // 25
        denyInsert: true,                                                                                            // 26
        optional: true                                                                                               // 27
    },                                                                                                               //
    // De-normalized label system                                                                                    //
    'labels.$._id': {                                                                                                // 30
        // We don't specify that this field must be unique in the board because                                      //
        // that will cause performance penalties and is not necessary because                                        //
        // this field is always set on the server.                                                                   //
        // XXX Actually if we create a new label, the `_id` is set on the client                                     //
        // without being overwritten by the server, could it be a problem?                                           //
        type: String                                                                                                 // 36
    },                                                                                                               //
    'labels.$.name': {                                                                                               // 38
        type: String,                                                                                                // 39
        optional: true                                                                                               // 40
    },                                                                                                               //
    'labels.$.color': {                                                                                              // 42
        type: String                                                                                                 // 43
    },                                                                                                               //
    // XXX We might want to maintain more informations under the member                                              //
    // sub-documents like an `isActive` boolean (so we can keep a trace of                                           //
    // former members) or de-normalized meta-data (the date the member joined                                        //
    // the board, the number of contributions, etc.).                                                                //
    'members.$.userId': {                                                                                            // 49
        type: String                                                                                                 // 50
    },                                                                                                               //
    'members.$.isAdmin': {                                                                                           // 52
        type: Boolean                                                                                                // 53
    },                                                                                                               //
    permission: {                                                                                                    // 55
        type: String,                                                                                                // 56
        allowedValues: ['public', 'private']                                                                         // 57
    },                                                                                                               //
    'background.type': {                                                                                             // 59
        type: String,                                                                                                // 60
        allowedValues: ['color']                                                                                     // 61
    },                                                                                                               //
    'background.color': {                                                                                            // 63
        // It's important to be strict about what we accept here, because if                                         //
        // certain malicious data are inserted this could lead to XSS injections                                     //
        // since we display this variable in a <style> tag.                                                          //
        type: String,                                                                                                // 67
        regEx: /^#[0-9A-F]{6}$/                                                                                      // 68
    }                                                                                                                //
}));                                                                                                                 //
                                                                                                                     //
// ALLOWS                                                                                                            //
Boards.allow({                                                                                                       // 73
    insert: Meteor.userId,                                                                                           // 74
    update: allowIsBoardAdmin,                                                                                       // 75
    remove: allowIsBoardAdmin,                                                                                       // 76
    fetch: ['members']                                                                                               // 77
});                                                                                                                  //
                                                                                                                     //
// We can't remove a member if it is the last administrator                                                          //
Boards.deny({                                                                                                        // 81
    update: function () {                                                                                            // 82
        function update(userId, doc, fieldNames, modifier) {                                                         // 82
            if (!_.contains(fieldNames, 'members')) return false;                                                    // 83
                                                                                                                     //
            // We only care in case of a $pull operation, ie remove a member                                         //
            if (!_.isObject(modifier.$pull && modifier.$pull.members)) return false;                                 // 82
                                                                                                                     //
            // If there is more than one admin, it's ok to remove anyone                                             //
            var nbAdmins = _.filter(doc.members, function (member) {                                                 // 82
                return member.isAdmin;                                                                               // 92
            }).length;                                                                                               //
            if (nbAdmins > 1) return false;                                                                          // 94
                                                                                                                     //
            // If all the previous conditions where verified, we can't remove                                        //
            // a user if it's an admin                                                                               //
            var removedMemberId = modifier.$pull.members.userId;                                                     // 82
            return !!_.findWhere(doc.members, {                                                                      // 100
                userId: removedMemberId,                                                                             // 101
                isAdmin: true                                                                                        // 102
            });                                                                                                      //
        }                                                                                                            //
                                                                                                                     //
        return update;                                                                                               //
    }(),                                                                                                             //
    fetch: ['members']                                                                                               // 105
});                                                                                                                  //
                                                                                                                     //
// HELPERS                                                                                                           //
Boards.helpers({                                                                                                     // 109
    isPublic: function () {                                                                                          // 110
        function isPublic() {                                                                                        // 110
            return this.permission === 'public';                                                                     // 111
        }                                                                                                            //
                                                                                                                     //
        return isPublic;                                                                                             //
    }(),                                                                                                             //
    lists: function () {                                                                                             // 113
        function lists() {                                                                                           // 113
            return Lists.find({ boardId: this._id, archived: false }, { sort: { sort: 1 } });                        // 114
        }                                                                                                            //
                                                                                                                     //
        return lists;                                                                                                //
    }(),                                                                                                             //
    activities: function () {                                                                                        // 116
        function activities() {                                                                                      // 116
            return Activities.find({ boardId: this._id }, { sort: { createdAt: -1 } });                              // 117
        }                                                                                                            //
                                                                                                                     //
        return activities;                                                                                           //
    }(),                                                                                                             //
    absoluteUrl: function () {                                                                                       // 119
        function absoluteUrl() {                                                                                     // 119
            return Router.path("Board", { boardId: this._id, slug: this.slug });                                     // 120
        }                                                                                                            //
                                                                                                                     //
        return absoluteUrl;                                                                                          //
    }()                                                                                                              //
});                                                                                                                  //
                                                                                                                     //
// We define a set of six default background colors that we took from the FlatUI                                     //
// palette: http://flatuicolors.com                                                                                  //
// XXX Unfortunately since we need this list in both the board insert hook and                                       //
// in one of the client side helper we have to makes it global. Change this when                                     //
// the variable sharing model of meteor is improved.                                                                 //
DefaultBoardBackgroundColors = ["#16A085", "#C0392B", "#2980B9", "#8E44AD", "#2C3E50", "#E67E22"];                   // 129
                                                                                                                     //
// HOOKS                                                                                                             //
Boards.before.insert(function (userId, doc) {                                                                        // 133
    // Handle labels                                                                                                 //
    var defaultLabels = ['green', 'yellow', 'orange', 'red', 'purple', 'blue'];                                      // 135
    doc.labels = [];                                                                                                 // 136
    _.each(defaultLabels, function (val) {                                                                           // 137
        doc.labels.push({                                                                                            // 138
            _id: Random.id(6),                                                                                       // 139
            name: '',                                                                                                // 140
            color: val                                                                                               // 141
        });                                                                                                          //
    });                                                                                                              //
                                                                                                                     //
    // We randomly chose one of the default background colors for the board                                          //
    if (Meteor.isClient) {                                                                                           // 133
        doc.background = {                                                                                           // 147
            type: "color",                                                                                           // 148
            color: Random.choice(DefaultBoardBackgroundColors)                                                       // 149
        };                                                                                                           //
    }                                                                                                                //
});                                                                                                                  //
                                                                                                                     //
Boards.before.update(function (userId, doc, fieldNames, modifier) {                                                  // 154
    modifier.$set = modifier.$set || {};                                                                             // 155
    modifier.$set.modifiedAt = moment().format('MMMM D, YYYY');                                                      // 156
});                                                                                                                  //
                                                                                                                     //
isServer(function () {                                                                                               // 160
                                                                                                                     //
    // Let MongoDB ensure that a member is not included twice in the same board                                      //
    Meteor.startup(function () {                                                                                     // 163
        Boards._collection._ensureIndex({                                                                            // 164
            '_id': 1,                                                                                                // 165
            'members.userId': 1                                                                                      // 166
        }, { unique: true });                                                                                        //
    });                                                                                                              //
                                                                                                                     //
    // Genesis: the first activity of the newly created board                                                        //
    Boards.after.insert(function (userId, doc) {                                                                     // 160
                                                                                                                     //
        var project = doc;                                                                                           // 173
        console.log(doc);                                                                                            // 174
                                                                                                                     //
        Activities.insert({                                                                                          // 176
            type: 'board',                                                                                           // 177
            activityTypeId: doc._id,                                                                                 // 178
            activityType: "createBoard",                                                                             // 179
            boardId: doc._id,                                                                                        // 180
            userId: userId                                                                                           // 181
        });                                                                                                          //
                                                                                                                     //
        // fill in lists and cards relative to purpose                                                               //
        /*                                                                                                           //
        list on before                                                                                               //
        doc.title: title.value,                                                                                      //
        boardId: this.board._id,                                                                                     //
        doc.createdAt = new Date();                                                                                  //
        doc.archived = false;                                                                                        //
        var user = Users.findOne(userId);                                                                            //
        if (!doc.userId) doc.userId = userId;                                                                        //
        */                                                                                                           //
                                                                                                                     //
        /*                                                                                                           //
        card on before                                                                                               //
         doc.createdAt = new Date();                                                                                 //
        doc.dateLastActivity = new Date();                                                                           //
         // defaults                                                                                                 //
        doc.archived = false;                                                                                        //
         // userId native set.                                                                                       //
        if (!doc.userId) {                                                                                           //
            doc.userId = userId;                                                                                     //
        }                                                                                                            //
        */                                                                                                           //
                                                                                                                     //
        // generic board template                                                                                    //
        var listPreplanId = Lists.insert({                                                                           // 171
            title: "Baseline",                                                                                       // 212
            boardId: doc._id,                                                                                        // 213
            createdAt: new Date(),                                                                                   // 214
            archived: false,                                                                                         // 215
            userId: userId                                                                                           // 216
        });                                                                                                          //
        Cards.insert({                                                                                               // 218
            createdAt: new Date(),                                                                                   // 219
            dateLastActivity: new Date(),                                                                            // 220
            archived: false,                                                                                         // 221
            userId: userId,                                                                                          // 222
            title: "build team",                                                                                     // 223
            listId: listPreplanId,                                                                                   // 224
            boardId: doc._id,                                                                                        // 225
            sort: 0                                                                                                  // 226
        });                                                                                                          //
        Cards.insert({                                                                                               // 228
            createdAt: new Date(),                                                                                   // 229
            dateLastActivity: new Date(),                                                                            // 230
            archived: false,                                                                                         // 231
            userId: userId,                                                                                          // 232
            title: "finalize member agreements and commitments",                                                     // 233
            listId: listPreplanId,                                                                                   // 234
            boardId: doc._id,                                                                                        // 235
            sort: 1                                                                                                  // 236
        });                                                                                                          //
        Cards.insert({                                                                                               // 238
            createdAt: new Date(),                                                                                   // 239
            dateLastActivity: new Date(),                                                                            // 240
            archived: false,                                                                                         // 241
            userId: userId,                                                                                          // 242
            title: "brainstorm/team meeting",                                                                        // 243
            listId: listPreplanId,                                                                                   // 244
            boardId: doc._id,                                                                                        // 245
            sort: 2                                                                                                  // 246
        });                                                                                                          //
        switch (doc.purpose) {                                                                                       // 248
            case "Motion Picture":                                                                                   // 249
                {                                                                                                    // 249
                                                                                                                     //
                    Cards.insert({                                                                                   // 251
                        createdAt: new Date(),                                                                       // 252
                        dateLastActivity: new Date(),                                                                // 253
                        archived: false,                                                                             // 254
                        userId: userId,                                                                              // 255
                        title: "script readthrough",                                                                 // 256
                        listId: listPreplanId,                                                                       // 257
                        boardId: doc._id,                                                                            // 258
                        sort: 3                                                                                      // 259
                    });                                                                                              //
                                                                                                                     //
                    Cards.insert({                                                                                   // 262
                        createdAt: new Date(),                                                                       // 263
                        dateLastActivity: new Date(),                                                                // 264
                        archived: false,                                                                             // 265
                        userId: userId,                                                                              // 266
                        title: "framing, videography discussion",                                                    // 267
                        listId: listPreplanId,                                                                       // 268
                        boardId: doc._id,                                                                            // 269
                        sort: 4                                                                                      // 270
                    });                                                                                              //
                                                                                                                     //
                    Cards.insert({                                                                                   // 273
                        createdAt: new Date(),                                                                       // 274
                        dateLastActivity: new Date(),                                                                // 275
                        archived: false,                                                                             // 276
                        userId: userId,                                                                              // 277
                        title: "audio/score discussion",                                                             // 278
                        listId: listPreplanId,                                                                       // 279
                        boardId: doc._id,                                                                            // 280
                        sort: 5                                                                                      // 281
                    });                                                                                              //
                                                                                                                     //
                    Cards.insert({                                                                                   // 284
                        createdAt: new Date(),                                                                       // 285
                        dateLastActivity: new Date(),                                                                // 286
                        archived: false,                                                                             // 287
                        userId: userId,                                                                              // 288
                        title: "secure locations",                                                                   // 289
                        listId: listPreplanId,                                                                       // 290
                        boardId: doc._id,                                                                            // 291
                        sort: 6                                                                                      // 292
                    });                                                                                              //
                                                                                                                     //
                    Cards.insert({                                                                                   // 295
                        createdAt: new Date(),                                                                       // 296
                        dateLastActivity: new Date(),                                                                // 297
                        archived: false,                                                                             // 298
                        userId: userId,                                                                              // 299
                        title: "secure props",                                                                       // 300
                        listId: listPreplanId,                                                                       // 301
                        boardId: doc._id,                                                                            // 302
                        sort: 7                                                                                      // 303
                    });                                                                                              //
                                                                                                                     //
                    Cards.insert({                                                                                   // 306
                        createdAt: new Date(),                                                                       // 307
                        dateLastActivity: new Date(),                                                                // 308
                        archived: false,                                                                             // 309
                        userId: userId,                                                                              // 310
                        title: "discussion with support teams",                                                      // 311
                        listId: listPreplanId,                                                                       // 312
                        boardId: doc._id,                                                                            // 313
                        sort: 8                                                                                      // 314
                    });                                                                                              //
                                                                                                                     //
                    Cards.insert({                                                                                   // 318
                        createdAt: new Date(),                                                                       // 319
                        dateLastActivity: new Date(),                                                                // 320
                        archived: false,                                                                             // 321
                        userId: userId,                                                                              // 322
                        title: "finalize storyboarding",                                                             // 323
                        listId: listPreplanId,                                                                       // 324
                        boardId: doc._id,                                                                            // 325
                        sort: 9                                                                                      // 326
                    });                                                                                              //
                                                                                                                     //
                    Cards.insert({                                                                                   // 330
                        createdAt: new Date(),                                                                       // 331
                        dateLastActivity: new Date(),                                                                // 332
                        archived: false,                                                                             // 333
                        userId: userId,                                                                              // 334
                        title: "finalize scheduling",                                                                // 335
                        listId: listPreplanId,                                                                       // 336
                        boardId: doc._id,                                                                            // 337
                        sort: 10                                                                                     // 338
                    });                                                                                              //
                                                                                                                     //
                    Cards.insert({                                                                                   // 342
                        createdAt: new Date(),                                                                       // 343
                        dateLastActivity: new Date(),                                                                // 344
                        archived: false,                                                                             // 345
                        userId: userId,                                                                              // 346
                        title: "finalize legal documents, permits, and waivers",                                     // 347
                        listId: listPreplanId,                                                                       // 348
                        boardId: doc._id,                                                                            // 349
                        sort: 11                                                                                     // 350
                    });                                                                                              //
                                                                                                                     //
                    Lists.insert({                                                                                   // 353
                        title: "Video Assets",                                                                       // 354
                        boardId: doc._id,                                                                            // 355
                        createdAt: new Date(),                                                                       // 356
                        archived: false,                                                                             // 357
                        userId: userId                                                                               // 358
                    });                                                                                              //
                                                                                                                     //
                    Lists.insert({                                                                                   // 361
                        title: "Audio Assets",                                                                       // 362
                        boardId: doc._id,                                                                            // 363
                        createdAt: new Date(),                                                                       // 364
                        archived: false,                                                                             // 365
                        userId: userId                                                                               // 366
                    });                                                                                              //
                                                                                                                     //
                    Lists.insert({                                                                                   // 369
                        title: "SFX Assets",                                                                         // 370
                        boardId: doc._id,                                                                            // 371
                        createdAt: new Date(),                                                                       // 372
                        archived: false,                                                                             // 373
                        userId: userId                                                                               // 374
                    });                                                                                              //
                                                                                                                     //
                    Lists.insert({                                                                                   // 377
                        title: "Writing Assets",                                                                     // 378
                        boardId: doc._id,                                                                            // 379
                        createdAt: new Date(),                                                                       // 380
                        archived: false,                                                                             // 381
                        userId: userId                                                                               // 382
                    });                                                                                              //
                                                                                                                     //
                    var listPostId = Lists.insert({                                                                  // 385
                        title: "Post",                                                                               // 386
                        boardId: doc._id,                                                                            // 387
                        createdAt: new Date(),                                                                       // 388
                        archived: false,                                                                             // 389
                        userId: userId                                                                               // 390
                    });                                                                                              //
                                                                                                                     //
                    Cards.insert({                                                                                   // 393
                        createdAt: new Date(),                                                                       // 394
                        dateLastActivity: new Date(),                                                                // 395
                        archived: false,                                                                             // 396
                        userId: userId,                                                                              // 397
                        title: "screenings",                                                                         // 398
                        listId: listPostId,                                                                          // 399
                        boardId: doc._id,                                                                            // 400
                        sort: 0                                                                                      // 401
                    });                                                                                              //
                                                                                                                     //
                    Cards.insert({                                                                                   // 404
                        createdAt: new Date(),                                                                       // 405
                        dateLastActivity: new Date(),                                                                // 406
                        archived: false,                                                                             // 407
                        userId: userId,                                                                              // 408
                        title: "post edits",                                                                         // 409
                        listId: listPostId,                                                                          // 410
                        boardId: doc._id,                                                                            // 411
                        sort: 1                                                                                      // 412
                    });                                                                                              //
                                                                                                                     //
                    Cards.insert({                                                                                   // 415
                        createdAt: new Date(),                                                                       // 416
                        dateLastActivity: new Date(),                                                                // 417
                        archived: false,                                                                             // 418
                        userId: userId,                                                                              // 419
                        title: "conference submissions",                                                             // 420
                        listId: listPostId,                                                                          // 421
                        boardId: doc._id,                                                                            // 422
                        sort: 2                                                                                      // 423
                    });                                                                                              //
                                                                                                                     //
                    break;                                                                                           // 426
                }                                                                                                    //
                                                                                                                     //
            case "Print Media":                                                                                      // 248
                {                                                                                                    // 429
                    Lists.insert({                                                                                   // 430
                        title: "Writing Assets",                                                                     // 431
                        boardId: doc._id,                                                                            // 432
                        createdAt: new Date(),                                                                       // 433
                        archived: false,                                                                             // 434
                        userId: userId                                                                               // 435
                    });                                                                                              //
                                                                                                                     //
                    var listPostId = Lists.insert({                                                                  // 438
                        title: "Post",                                                                               // 439
                        boardId: doc._id,                                                                            // 440
                        createdAt: new Date(),                                                                       // 441
                        archived: false,                                                                             // 442
                        userId: userId                                                                               // 443
                    });                                                                                              //
                                                                                                                     //
                    Cards.insert({                                                                                   // 446
                        createdAt: new Date(),                                                                       // 447
                        dateLastActivity: new Date(),                                                                // 448
                        archived: false,                                                                             // 449
                        userId: userId,                                                                              // 450
                        title: "editing, polish, finish",                                                            // 451
                        listId: listPostId,                                                                          // 452
                        boardId: doc._id,                                                                            // 453
                        sort: 0                                                                                      // 454
                    });                                                                                              //
                                                                                                                     //
                    break;                                                                                           // 457
                }                                                                                                    //
                                                                                                                     //
            case "Performance":                                                                                      // 248
                {                                                                                                    // 460
                    Lists.insert({                                                                                   // 461
                        title: "Audio Assets",                                                                       // 462
                        boardId: doc._id,                                                                            // 463
                        createdAt: new Date(),                                                                       // 464
                        archived: false,                                                                             // 465
                        userId: userId                                                                               // 466
                    });                                                                                              //
                                                                                                                     //
                    var listPostId = Lists.insert({                                                                  // 469
                        title: "Post",                                                                               // 470
                        boardId: doc._id,                                                                            // 471
                        createdAt: new Date(),                                                                       // 472
                        archived: false,                                                                             // 473
                        userId: userId                                                                               // 474
                    });                                                                                              //
                                                                                                                     //
                    Cards.insert({                                                                                   // 477
                        createdAt: new Date(),                                                                       // 478
                        dateLastActivity: new Date(),                                                                // 479
                        archived: false,                                                                             // 480
                        userId: userId,                                                                              // 481
                        title: "final master",                                                                       // 482
                        listId: listPostId,                                                                          // 483
                        boardId: doc._id,                                                                            // 484
                        sort: 0                                                                                      // 485
                    });                                                                                              //
                                                                                                                     //
                    break;                                                                                           // 488
                }                                                                                                    //
                                                                                                                     //
            default:                                                                                                 // 248
                {                                                                                                    // 491
                    // production, resource, location, finance, general labor, legal, marketing, distribution, other
                    var productionNeeds = ['Interviews, casting, and auditions.', 'Compliance and paperwork.', 'Introductory team meeting.', 'Pre-production goals defined in a document and shared with the team.', 'Team evaluation.', 'Post-production goals defined in a document and shared with the team.'];
                    var resourceNeeds = ['Schedule resource agreement.', 'Sign resource sharing agreement.', 'Define resource state, condition, and flaws.', 'Return resource and sign waiver.'];
                    var locationNeeds = ['Location evaluations and decision.', 'Visit location and dry run.', 'Permits, waivers, and agreements.', 'Setup location.', 'Breakdown and cleanup.'];
                    var financeNeeds = ['Write business plan.', 'Write marketing, sales, and distribution plan.', 'Meet investors and pitch.', 'Accounting and paperwork.'];
                    var laborNeeds = ['Define labor tasks.', 'Arrange transportation, food, and materials.', 'Insurance, waivers, and compliance.'];
                    var legalNeeds = ['Initial consultation.', 'Agreement and retainer.', 'Define issues.'];         // 498
                    var marketingNeeds = ['Marketing media.', 'Marketing technologies.', 'Marketing subscriptions.', 'Payment and accounting.'];
                    var distributionNeeds = ['Define markets.', 'Define target audience persona.', 'Analysis and evaluation.'];
                    var genericNeeds = ['Define tasks.'];                                                            // 501
                    var tagsMapped = {                                                                               // 502
                        production: ['Production Goals', productionNeeds],                                           // 503
                        resource: ['Resource Allocation', resourceNeeds],                                            // 504
                        location: ['Locations, Venues, and Scenes', locationNeeds],                                  // 505
                        finance: ['Financial Needs', financeNeeds],                                                  // 506
                        'general labor': ['Labor & General Work', laborNeeds],                                       // 507
                        legal: ['Intellectual Property & Compliance', legalNeeds],                                   // 508
                        marketing: ['Social Media, Marketing, and Technology', marketingNeeds],                      // 509
                        distribution: ['Sales, Distribution, and Markets', distributionNeeds]                        // 510
                    };                                                                                               //
                    // define cards by tags                                                                          //
                    tagsHolder.forEach(function (t) {                                                                // 491
                        if (Object.keys(tagsMapped).indexOf(t) === -1) return;                                       // 514
                        var _title = tagsMapped[t][0];                                                               // 515
                        var targetArr = tagsMapped[t][1];                                                            // 516
                        var _list = Lists.insert({                                                                   // 517
                            title: _title,                                                                           // 518
                            boardId: doc._id,                                                                        // 519
                            createdAt: new Date(),                                                                   // 520
                            archived: false,                                                                         // 521
                            userId: userId                                                                           // 522
                        });                                                                                          //
                        targetArr.forEach(function (_t, idx) {                                                       // 524
                            Cards.insert({                                                                           // 525
                                createdAt: new Date(),                                                               // 526
                                dateLastActivity: new Date(),                                                        // 527
                                archived: false,                                                                     // 528
                                userId: userId,                                                                      // 529
                                title: _t,                                                                           // 530
                                listId: _list,                                                                       // 531
                                boardId: doc._id,                                                                    // 532
                                sort: idx                                                                            // 533
                            });                                                                                      //
                        });                                                                                          //
                    });                                                                                              //
                }                                                                                                    //
        }                                                                                                            // 248
    });                                                                                                              //
                                                                                                                     //
    // If the user remove one label from a board, we cant to remove reference of                                     //
    // this label in any card of this board.                                                                         //
    Boards.after.update(function (userId, doc, fieldNames, modifier) {                                               // 160
        if (!_.contains(fieldNames, 'labels') || !modifier.$pull || !modifier.$pull.labels || !modifier.$pull.labels._id) return;
                                                                                                                     //
        var removedLabelId = modifier.$pull.labels._id;                                                              // 550
        Cards.update({ boardId: doc._id }, {                                                                         // 551
            $pull: {                                                                                                 // 554
                labels: removedLabelId                                                                               // 555
            }                                                                                                        //
        }, { multi: true });                                                                                         //
    });                                                                                                              //
                                                                                                                     //
    // Add a new activity if we add or remove a member to the board                                                  //
    Boards.after.update(function (userId, doc, fieldNames, modifier) {                                               // 160
        if (!_.contains(fieldNames, 'members')) return;                                                              // 564
                                                                                                                     //
        // Say hello to the new member                                                                               //
        if (modifier.$push && modifier.$push.members) {                                                              // 563
            var memberId = modifier.$push.members.userId;                                                            // 569
            Activities.insert({                                                                                      // 570
                type: 'member',                                                                                      // 571
                activityType: "addBoardMember",                                                                      // 572
                boardId: doc._id,                                                                                    // 573
                userId: userId,                                                                                      // 574
                memberId: memberId                                                                                   // 575
            });                                                                                                      //
        }                                                                                                            //
                                                                                                                     //
        // Say goodbye to the former member                                                                          //
        if (modifier.$pull && modifier.$pull.members) {                                                              // 563
            var memberId = modifier.$pull.members.userId;                                                            // 581
            Activities.insert({                                                                                      // 582
                type: 'member',                                                                                      // 583
                activityType: "removeBoardMember",                                                                   // 584
                boardId: doc._id,                                                                                    // 585
                userId: userId,                                                                                      // 586
                memberId: memberId                                                                                   // 587
            });                                                                                                      //
        }                                                                                                            //
    });                                                                                                              //
});                                                                                                                  //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"cards.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// collections/cards.js                                                                                              //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
Cards = new Mongo.Collection('cards');                                                                               // 1
CardComments = new Mongo.Collection('card_comments');                                                                // 2
                                                                                                                     //
// XXX To improve pub/sub performances a card document should included a                                             //
// de-normalized number of comments so we don't have to publish the whole list                                       //
// of comments just to display the number of them in the board view.                                                 //
Cards.attachSchema(new SimpleSchema({                                                                                // 7
    title: {                                                                                                         // 8
        type: String                                                                                                 // 9
    },                                                                                                               //
    archived: {                                                                                                      // 11
        type: Boolean                                                                                                // 12
    },                                                                                                               //
    listId: {                                                                                                        // 14
        type: String                                                                                                 // 15
    },                                                                                                               //
    // The system could work without this `boardId` information (we could deduce                                     //
    // the board identifier from the card), but it would make the system more                                        //
    // difficult to manage and less efficient.                                                                       //
    boardId: {                                                                                                       // 20
        type: String                                                                                                 // 21
    },                                                                                                               //
    coverId: {                                                                                                       // 23
        type: String,                                                                                                // 24
        optional: true                                                                                               // 25
    },                                                                                                               //
    createdAt: {                                                                                                     // 27
        type: Date,                                                                                                  // 28
        denyUpdate: true                                                                                             // 29
    },                                                                                                               //
    dateLastActivity: {                                                                                              // 31
        type: Date                                                                                                   // 32
    },                                                                                                               //
    dueDate: {                                                                                                       // 34
        type: Date,                                                                                                  // 35
        optional: true                                                                                               // 36
    },                                                                                                               //
    description: {                                                                                                   // 38
        type: String,                                                                                                // 39
        optional: true                                                                                               // 40
    },                                                                                                               //
    labelIds: {                                                                                                      // 42
        type: [String],                                                                                              // 43
        optional: true                                                                                               // 44
    },                                                                                                               //
    members: {                                                                                                       // 46
        type: [String],                                                                                              // 47
        optional: true                                                                                               // 48
    },                                                                                                               //
    // XXX Should probably be called `authorId`. Is it even needed since we have                                     //
    // the `members` field?                                                                                          //
    userId: {                                                                                                        // 52
        type: String                                                                                                 // 53
    },                                                                                                               //
    sort: {                                                                                                          // 55
        type: Number,                                                                                                // 56
        decimal: true                                                                                                // 57
    }                                                                                                                //
}));                                                                                                                 //
                                                                                                                     //
CardComments.attachSchema(new SimpleSchema({                                                                         // 61
    boardId: {                                                                                                       // 62
        type: String                                                                                                 // 63
    },                                                                                                               //
    cardId: {                                                                                                        // 65
        type: String                                                                                                 // 66
    },                                                                                                               //
    // XXX Rename in `content`? `text` is a bit vague...                                                             //
    text: {                                                                                                          // 69
        type: String                                                                                                 // 70
    },                                                                                                               //
    // XXX We probably don't need this information here, since we already have                                       //
    // it in the associated comment creation activity                                                                //
    createdAt: {                                                                                                     // 74
        type: Date,                                                                                                  // 75
        denyUpdate: false                                                                                            // 76
    },                                                                                                               //
    // XXX Should probably be called `authorId`                                                                      //
    userId: {                                                                                                        // 79
        type: String                                                                                                 // 80
    }                                                                                                                //
}));                                                                                                                 //
                                                                                                                     //
// ALLOWS                                                                                                            //
Cards.allow({                                                                                                        // 85
    insert: function () {                                                                                            // 86
        function insert(userId, doc) {                                                                               // 86
            return allowIsBoardMember(userId, Boards.findOne(doc.boardId));                                          // 87
        }                                                                                                            //
                                                                                                                     //
        return insert;                                                                                               //
    }(),                                                                                                             //
    update: function () {                                                                                            // 89
        function update(userId, doc) {                                                                               // 89
            return allowIsBoardMember(userId, Boards.findOne(doc.boardId));                                          // 90
        }                                                                                                            //
                                                                                                                     //
        return update;                                                                                               //
    }(),                                                                                                             //
    remove: function () {                                                                                            // 92
        function remove(userId, doc) {                                                                               // 92
            return allowIsBoardMember(userId, Boards.findOne(doc.boardId));                                          // 93
        }                                                                                                            //
                                                                                                                     //
        return remove;                                                                                               //
    }(),                                                                                                             //
    fetch: ['boardId']                                                                                               // 95
});                                                                                                                  //
                                                                                                                     //
CardComments.allow({                                                                                                 // 98
    insert: function () {                                                                                            // 99
        function insert(userId, doc) {                                                                               // 99
            return allowIsBoardMember(userId, Boards.findOne(doc.boardId));                                          // 100
        }                                                                                                            //
                                                                                                                     //
        return insert;                                                                                               //
    }(),                                                                                                             //
    update: function () {                                                                                            // 102
        function update(userId, doc) {                                                                               // 102
            return userId === doc.userId;                                                                            // 103
        }                                                                                                            //
                                                                                                                     //
        return update;                                                                                               //
    }(),                                                                                                             //
    remove: function () {                                                                                            // 105
        function remove(userId, doc) {                                                                               // 105
            return userId === doc.userId;                                                                            // 106
        }                                                                                                            //
                                                                                                                     //
        return remove;                                                                                               //
    }(),                                                                                                             //
    fetch: ['userId', 'boardId']                                                                                     // 108
});                                                                                                                  //
                                                                                                                     //
// HELPERS                                                                                                           //
Cards.helpers({                                                                                                      // 113
    list: function () {                                                                                              // 114
        function list() {                                                                                            // 114
            return Lists.findOne(this.listId);                                                                       // 115
        }                                                                                                            //
                                                                                                                     //
        return list;                                                                                                 //
    }(),                                                                                                             //
    board: function () {                                                                                             // 117
        function board() {                                                                                           // 117
            return Boards.findOne(this.boardId);                                                                     // 118
        }                                                                                                            //
                                                                                                                     //
        return board;                                                                                                //
    }(),                                                                                                             //
    labels: function () {                                                                                            // 120
        function labels() {                                                                                          // 120
            var self = this;                                                                                         // 121
            var boardLabels = self.board().labels;                                                                   // 122
            var cardLabels = _.filter(boardLabels, function (label) {                                                // 123
                return _.contains(self.labelIds, label._id);                                                         // 124
            });                                                                                                      //
            return cardLabels;                                                                                       // 126
        }                                                                                                            //
                                                                                                                     //
        return labels;                                                                                               //
    }(),                                                                                                             //
    user: function () {                                                                                              // 128
        function user() {                                                                                            // 128
            return Users.findOne(this.userId);                                                                       // 129
        }                                                                                                            //
                                                                                                                     //
        return user;                                                                                                 //
    }(),                                                                                                             //
    activities: function () {                                                                                        // 131
        function activities() {                                                                                      // 131
            return Activities.find({ type: 'card', cardId: this._id }, { sort: { createdAt: -1 } });                 // 132
        }                                                                                                            //
                                                                                                                     //
        return activities;                                                                                           //
    }(),                                                                                                             //
    comments: function () {                                                                                          // 134
        function comments() {                                                                                        // 134
            return CardComments.find({ cardId: this._id }, { sort: { createdAt: -1 } });                             // 135
        }                                                                                                            //
                                                                                                                     //
        return comments;                                                                                             //
    }(),                                                                                                             //
    attachments: function () {                                                                                       // 137
        function attachments() {                                                                                     // 137
            return Attachments.find({ cardId: this._id }, { sort: { uploadedAt: -1 } });                             // 138
        }                                                                                                            //
                                                                                                                     //
        return attachments;                                                                                          //
    }(),                                                                                                             //
    cover: function () {                                                                                             // 140
        function cover() {                                                                                           // 140
            return Attachments.findOne(this.coverId);                                                                // 141
        }                                                                                                            //
                                                                                                                     //
        return cover;                                                                                                //
    }(),                                                                                                             //
    absoluteUrl: function () {                                                                                       // 143
        function absoluteUrl() {                                                                                     // 143
            var board = this.board();                                                                                // 144
            return Router.path("Card", { boardId: board._id, slug: board.slug, cardId: this._id });                  // 145
        }                                                                                                            //
                                                                                                                     //
        return absoluteUrl;                                                                                          //
    }(),                                                                                                             //
    rootUrl: function () {                                                                                           // 147
        function rootUrl() {                                                                                         // 147
            return Meteor.absoluteUrl(this.absoluteUrl().replace('/', ''));                                          // 148
        }                                                                                                            //
                                                                                                                     //
        return rootUrl;                                                                                              //
    }()                                                                                                              //
});                                                                                                                  //
                                                                                                                     //
CardComments.helpers({                                                                                               // 152
    user: function () {                                                                                              // 153
        function user() {                                                                                            // 153
            return Users.findOne(this.userId);                                                                       // 154
        }                                                                                                            //
                                                                                                                     //
        return user;                                                                                                 //
    }()                                                                                                              //
});                                                                                                                  //
                                                                                                                     //
CardComments.hookOptions.after.update = { fetchPrevious: false };                                                    // 158
Cards.before.insert(function (userId, doc) {                                                                         // 159
    doc.createdAt = new Date();                                                                                      // 160
    doc.dateLastActivity = new Date();                                                                               // 161
                                                                                                                     //
    // defaults                                                                                                      //
    doc.archived = false;                                                                                            // 159
                                                                                                                     //
    // userId native set.                                                                                            //
    if (!doc.userId) {                                                                                               // 159
        doc.userId = userId;                                                                                         // 168
    }                                                                                                                //
});                                                                                                                  //
                                                                                                                     //
CardComments.before.insert(function (userId, doc) {                                                                  // 173
    doc.createdAt = new Date();                                                                                      // 174
    doc.userId = userId;                                                                                             // 175
});                                                                                                                  //
                                                                                                                     //
isServer(function () {                                                                                               // 178
    Cards.after.insert(function (userId, doc) {                                                                      // 179
        Activities.insert({                                                                                          // 180
            type: 'card',                                                                                            // 181
            activityType: "createCard",                                                                              // 182
            boardId: doc.boardId,                                                                                    // 183
            listId: doc.listId,                                                                                      // 184
            cardId: doc._id,                                                                                         // 185
            userId: userId                                                                                           // 186
        });                                                                                                          //
    });                                                                                                              //
                                                                                                                     //
    // New activity for card (un)archivage                                                                           //
    Cards.after.update(function (userId, doc, fieldNames, modifier) {                                                // 178
        if (_.contains(fieldNames, 'archived')) {                                                                    // 192
            var _id = userId;                                                                                        // 193
            if (doc.archived) {                                                                                      // 194
                Activities.insert({                                                                                  // 195
                    type: 'card',                                                                                    // 196
                    activityType: "archivedCard",                                                                    // 197
                    boardId: doc.boardId,                                                                            // 198
                    listId: doc.listId,                                                                              // 199
                    cardId: doc._id,                                                                                 // 200
                    userId: _id                                                                                      // 201
                });                                                                                                  //
            } else {                                                                                                 //
                Activities.insert({                                                                                  // 204
                    type: 'card',                                                                                    // 205
                    activityType: "restoredCard",                                                                    // 206
                    boardId: doc.boardId,                                                                            // 207
                    listId: doc.listId,                                                                              // 208
                    cardId: doc._id,                                                                                 // 209
                    userId: _id                                                                                      // 210
                });                                                                                                  //
            }                                                                                                        //
        }                                                                                                            //
    });                                                                                                              //
                                                                                                                     //
    // New activity for card moves                                                                                   //
    Cards.after.update(function (userId, doc, fieldNames, modifier) {                                                // 178
        var oldListId = this.previous.listId;                                                                        // 218
        if (_.contains(fieldNames, "listId") && doc.listId !== oldListId) {                                          // 219
            Activities.insert({                                                                                      // 220
                type: 'card',                                                                                        // 221
                activityType: "moveCard",                                                                            // 222
                listId: doc.listId,                                                                                  // 223
                oldListId: oldListId,                                                                                // 224
                boardId: doc.boardId,                                                                                // 225
                cardId: doc._id,                                                                                     // 226
                userId: userId                                                                                       // 227
            });                                                                                                      //
        }                                                                                                            //
    });                                                                                                              //
                                                                                                                     //
    // Add a new activity if we add or remove a member to the card                                                   //
    Cards.before.update(function (userId, doc, fieldNames, modifier) {                                               // 178
        if (!_.contains(fieldNames, 'members')) return;                                                              // 234
                                                                                                                     //
        // Say hello to the new member                                                                               //
        if (modifier.$addToSet && modifier.$addToSet.members) {                                                      // 233
            var memberId = modifier.$addToSet.members;                                                               // 239
            if (!_.contains(doc.members, memberId)) {                                                                // 240
                Activities.insert({                                                                                  // 241
                    type: 'card',                                                                                    // 242
                    activityType: "joinMember",                                                                      // 243
                    boardId: doc.boardId,                                                                            // 244
                    cardId: doc._id,                                                                                 // 245
                    userId: userId,                                                                                  // 246
                    memberId: memberId                                                                               // 247
                });                                                                                                  //
            }                                                                                                        //
        }                                                                                                            //
                                                                                                                     //
        // Say goodbye to the former member                                                                          //
        if (modifier.$pull && modifier.$pull.members) {                                                              // 233
            var memberId = modifier.$pull.members;                                                                   // 254
            Activities.insert({                                                                                      // 255
                type: 'card',                                                                                        // 256
                activityType: "unjoinMember",                                                                        // 257
                boardId: doc.boardId,                                                                                // 258
                cardId: doc._id,                                                                                     // 259
                userId: userId,                                                                                      // 260
                memberId: memberId                                                                                   // 261
            });                                                                                                      //
        }                                                                                                            //
    });                                                                                                              //
                                                                                                                     //
    // Remove all activities associated with a card if we remove the card                                            //
    Cards.after.remove(function (userId, doc) {                                                                      // 178
        Activities.remove({                                                                                          // 268
            cardId: doc._id                                                                                          // 269
        });                                                                                                          //
    });                                                                                                              //
                                                                                                                     //
    CardComments.after.insert(function (userId, doc) {                                                               // 273
        Activities.insert({                                                                                          // 274
            type: 'comment',                                                                                         // 275
            activityType: "addComment",                                                                              // 276
            boardId: doc.boardId,                                                                                    // 277
            cardId: doc.cardId,                                                                                      // 278
            commentId: doc._id,                                                                                      // 279
            userId: userId                                                                                           // 280
        });                                                                                                          //
    });                                                                                                              //
                                                                                                                     //
    CardComments.after.remove(function (userId, doc) {                                                               // 284
        var activity = Activities.findOne({ commentId: doc._id });                                                   // 285
        if (activity) {                                                                                              // 286
            Activities.remove(activity._id);                                                                         // 287
        }                                                                                                            //
    });                                                                                                              //
});                                                                                                                  //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"lists.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// collections/lists.js                                                                                              //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
Lists = new Mongo.Collection('lists');                                                                               // 1
                                                                                                                     //
Lists.attachSchema(new SimpleSchema({                                                                                // 3
    title: {                                                                                                         // 4
        type: String                                                                                                 // 5
    },                                                                                                               //
    archived: {                                                                                                      // 7
        type: Boolean                                                                                                // 8
    },                                                                                                               //
    boardId: {                                                                                                       // 10
        type: String                                                                                                 // 11
    },                                                                                                               //
    createdAt: {                                                                                                     // 13
        type: Date,                                                                                                  // 14
        denyUpdate: true                                                                                             // 15
    },                                                                                                               //
    sort: {                                                                                                          // 17
        type: Number,                                                                                                // 18
        decimal: true,                                                                                               // 19
        // XXX We should probably provide a default                                                                  //
        optional: true                                                                                               // 21
    },                                                                                                               //
    updatedAt: {                                                                                                     // 23
        type: Date,                                                                                                  // 24
        denyInsert: true,                                                                                            // 25
        optional: true                                                                                               // 26
    }                                                                                                                //
}));                                                                                                                 //
                                                                                                                     //
Lists.allow({                                                                                                        // 30
    insert: function () {                                                                                            // 31
        function insert(userId, doc) {                                                                               // 31
            return allowIsBoardMember(userId, Boards.findOne(doc.boardId));                                          // 32
        }                                                                                                            //
                                                                                                                     //
        return insert;                                                                                               //
    }(),                                                                                                             //
    update: function () {                                                                                            // 34
        function update(userId, doc) {                                                                               // 34
            return allowIsBoardMember(userId, Boards.findOne(doc.boardId));                                          // 35
        }                                                                                                            //
                                                                                                                     //
        return update;                                                                                               //
    }(),                                                                                                             //
    remove: function () {                                                                                            // 37
        function remove(userId, doc) {                                                                               // 37
            return allowIsBoardMember(userId, Boards.findOne(doc.boardId));                                          // 38
        }                                                                                                            //
                                                                                                                     //
        return remove;                                                                                               //
    }(),                                                                                                             //
    fetch: ['boardId']                                                                                               // 40
});                                                                                                                  //
                                                                                                                     //
Lists.helpers({                                                                                                      // 44
    cards: function () {                                                                                             // 45
        function cards() {                                                                                           // 45
            var o = Filter.getMongoSelector();                                                                       // 46
            if (o && o['$or'] && o['$or'][0]) {                                                                      // 47
                if ('dueDates' in o['$or'][0]) {                                                                     // 48
                    var l = o['$or'][0];                                                                             // 49
                    if (l['dueDates'] && l['dueDates']['$in'] && l['dueDates']['$in'].length > 0) {                  // 50
                        return Cards.find({                                                                          // 53
                            _id: { '$in': l['dueDates']['$in'] },                                                    // 54
                            listId: this._id,                                                                        // 55
                            archived: false                                                                          // 56
                        }, { sort: ['sort'] });                                                                      //
                    };                                                                                               //
                };                                                                                                   //
            };                                                                                                       //
            return Cards.find(_.extend(Filter.getMongoSelector(), {                                                  // 61
                listId: this._id,                                                                                    // 62
                archived: false                                                                                      // 63
            }), { sort: ['sort'] });                                                                                 //
        }                                                                                                            //
                                                                                                                     //
        return cards;                                                                                                //
    }(),                                                                                                             //
    board: function () {                                                                                             // 66
        function board() {                                                                                           // 66
            return Boards.findOne(this.boardId);                                                                     // 67
        }                                                                                                            //
                                                                                                                     //
        return board;                                                                                                //
    }()                                                                                                              //
});                                                                                                                  //
                                                                                                                     //
// HOOKS                                                                                                             //
Lists.hookOptions.after.update = { fetchPrevious: false };                                                           // 72
                                                                                                                     //
Lists.before.insert(function (userId, doc) {                                                                         // 74
    doc.createdAt = new Date();                                                                                      // 75
    doc.archived = false;                                                                                            // 76
    if (!doc.userId) doc.userId = userId;                                                                            // 77
});                                                                                                                  //
                                                                                                                     //
Lists.before.update(function (userId, doc, fieldNames, modifier) {                                                   // 80
    modifier.$set = modifier.$set || {};                                                                             // 81
    modifier.$set.modifiedAt = new Date();                                                                           // 82
});                                                                                                                  //
                                                                                                                     //
isServer(function () {                                                                                               // 86
    Lists.after.insert(function (userId, doc) {                                                                      // 87
        Activities.insert({                                                                                          // 88
            type: 'list',                                                                                            // 89
            activityType: "createList",                                                                              // 90
            boardId: doc.boardId,                                                                                    // 91
            listId: doc._id,                                                                                         // 92
            userId: userId                                                                                           // 93
        });                                                                                                          //
    });                                                                                                              //
                                                                                                                     //
    Lists.after.update(function (userId, doc) {                                                                      // 97
        if (doc.archived) {                                                                                          // 98
            Activities.insert({                                                                                      // 99
                type: 'list',                                                                                        // 100
                activityType: "archivedList",                                                                        // 101
                listId: doc._id,                                                                                     // 102
                boardId: doc.boardId,                                                                                // 103
                userId: userId                                                                                       // 104
            });                                                                                                      //
        }                                                                                                            //
    });                                                                                                              //
});                                                                                                                  //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"projects.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// collections/projects.js                                                                                           //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
Projects = new Mongo.Collection('projects');                                                                         // 1
Comments = new Mongo.Collection('comments');                                                                         // 2
                                                                                                                     //
function allowedUser(userId) {                                                                                       // 4
  var allowedUser = Meteor.users.findOne({ username: "admin" });                                                     // 5
  return userId && allowedUser && userId === allowedUser._id;                                                        // 6
}                                                                                                                    //
                                                                                                                     //
Projects.allow({                                                                                                     // 9
  insert: function () {                                                                                              // 10
    function insert(userId, doc) {                                                                                   // 10
      // only allow posting if you are logged in                                                                     //
      return !!userId;                                                                                               // 12
    }                                                                                                                //
                                                                                                                     //
    return insert;                                                                                                   //
  }(),                                                                                                               //
  update: function () {                                                                                              // 14
    function update(userId, doc) {                                                                                   // 14
      // only allow posting if you are logged in                                                                     //
      return !!userId;                                                                                               // 16
    }                                                                                                                //
                                                                                                                     //
    return update;                                                                                                   //
  }(),                                                                                                               //
  remove: function () {                                                                                              // 18
    function remove(userId, doc) {                                                                                   // 18
      // only allow posting if you are logged in                                                                     //
      return !!userId;                                                                                               // 20
    }                                                                                                                //
                                                                                                                     //
    return remove;                                                                                                   //
  }()                                                                                                                //
});                                                                                                                  //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"receipts.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// collections/receipts.js                                                                                           //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
Subscribers = new Mongo.Collection('subscribers');                                                                   // 1
                                                                                                                     //
Receipts = new Mongo.Collection('receipts');                                                                         // 3
                                                                                                                     //
// XXX To improve pub/sub performances a card document should included a                                             //
// de-normalized number of comments so we don't have to publish the whole list                                       //
// of comments just to display the number of them in the board view.                                                 //
// Receipts.attachSchema(new SimpleSchema({                                                                          //
//     userId: {                                                                                                     //
//         type: String                                                                                              //
//     },                                                                                                            //
//     projTitle: {                                                                                                  //
//         type: String                                                                                              //
//     },                                                                                                            //
//     projectId: {                                                                                                  //
//         type: String                                                                                              //
//     },                                                                                                            //
//     projAccepted: {                                                                                               //
//         type: Boolean                                                                                             //
//     },                                                                                                            //
//     projStarted: {                                                                                                //
//         type: Boolean                                                                                             //
//     },                                                                                                            //
//     amount: {                                                                                                     //
//         type: Number                                                                                              //
//     },                                                                                                            //
//     refundAmount: {                                                                                               //
//         type: Number                                                                                              //
//     },                                                                                                            //
//     refunded: {                                                                                                   //
//         type: Boolean                                                                                             //
//     },                                                                                                            //
//     forProjectCreate: {                                                                                           //
//         type: Boolean                                                                                             //
//     },                                                                                                            //
//     forProjectApply: {                                                                                            //
//         type: Boolean                                                                                             //
//     },                                                                                                            //
//     created: {                                                                                                    //
//         type: Date                                                                                                //
//     },                                                                                                            //
//     outstandingBalance: {                                                                                         //
//         type: Number                                                                                              //
//     },                                                                                                            //
//     receipt: {                                                                                                    //
//         type: Object                                                                                              //
//     }                                                                                                             //
// }));                                                                                                              //
                                                                                                                     //
// function allowedUser(userId) {                                                                                    //
//   var allowedUser = Meteor.users.findOne({_id: userId});                                                          //
//   return (userId && allowedUser && userId === allowedUser._id);                                                   //
// }                                                                                                                 //
                                                                                                                     //
// // ALLOWS                                                                                                         //
Receipts.allow({                                                                                                     // 56
    insert: function () {                                                                                            // 57
        function insert(userId, doc) {                                                                               // 57
            return true; //allowedUser(userId);                                                                      // 58
        }                                                                                                            // 57
                                                                                                                     //
        return insert;                                                                                               //
    }(),                                                                                                             //
    update: function () {                                                                                            // 60
        function update(userId, doc) {                                                                               // 60
            return true; //allowedUser(userId);                                                                      // 61
        }                                                                                                            // 60
                                                                                                                     //
        return update;                                                                                               //
    }(),                                                                                                             //
    remove: function () {                                                                                            // 63
        function remove(userId, doc) {                                                                               // 63
            return false;                                                                                            // 64
        }                                                                                                            //
                                                                                                                     //
        return remove;                                                                                               //
    }()                                                                                                              //
});                                                                                                                  //
                                                                                                                     //
Subscribers.allow({                                                                                                  // 68
    insert: function () {                                                                                            // 69
        function insert(userId, doc) {                                                                               // 69
            return true; //allowedUser(userId);                                                                      // 70
        }                                                                                                            // 69
                                                                                                                     //
        return insert;                                                                                               //
    }()                                                                                                              //
});                                                                                                                  //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"users.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// collections/users.js                                                                                              //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
Users = Meteor.users;                                                                                                // 1
// main ID = user.meetupId                                                                                           //
                                                                                                                     //
// Search a user in the complete server database by its name or username. This                                       //
// is used for instance to add a new user to a board.                                                                //
// var searchInFields = ['username', 'profile.name'];                                                                //
// Users.initEasySearch(searchInFields, {                                                                            //
//     use: 'mongo-db',                                                                                              //
//     returnFields: searchInFields                                                                                  //
// });                                                                                                               //
                                                                                                                     //
// HELPERS                                                                                                           //
Users.helpers({                                                                                                      // 16
    boards: function () {                                                                                            // 17
        function boards() {                                                                                          // 17
            return Boards.find({ userId: this._id });                                                                // 18
        }                                                                                                            //
                                                                                                                     //
        return boards;                                                                                               //
    }(),                                                                                                             //
    hasStarred: function () {                                                                                        // 20
        function hasStarred(boardId) {                                                                               // 20
            return this.profile.starredBoards && _.contains(this.starredBoards, boardId);                            // 21
        }                                                                                                            //
                                                                                                                     //
        return hasStarred;                                                                                           //
    }(),                                                                                                             //
    isBoardMember: function () {                                                                                     // 23
        function isBoardMember() {                                                                                   // 23
            var board = Boards.findOne(Router.current().params.boardId);                                             // 24
            return _.contains(_.pluck(board.members, 'userId'), this._id);                                           // 25
        }                                                                                                            //
                                                                                                                     //
        return isBoardMember;                                                                                        //
    }(),                                                                                                             //
    isBoardAdmin: function () {                                                                                      // 27
        function isBoardAdmin() {                                                                                    // 27
            var board = Boards.findOne(Router.current().params.boardId);                                             // 28
            return this.isBoardMember(board) && _.where(board.members, { userId: this._id })[0].isAdmin;             // 29
        }                                                                                                            //
                                                                                                                     //
        return isBoardAdmin;                                                                                         //
    }()                                                                                                              //
});                                                                                                                  //
                                                                                                                     //
// BEFORE HOOK                                                                                                       //
Users.before.insert(function (userId, doc) {                                                                         // 35
    // connect profile.status default =                                                                              //
    /** create Stripe managed account */                                                                             //
    doc.status = 'online';                                                                                           // 38
    doc.socialLinks = [];                                                                                            // 39
    doc.starredBoards = [];                                                                                          // 40
    doc.receiptsHistory = [];                                                                                        // 41
    doc.specialties = [];                                                                                            // 42
    doc.onlineWorks = [];                                                                                            // 43
    doc.headshots = [];                                                                                              // 44
    doc.resources = [];                                                                                              // 45
    doc.firstName = doc.services && doc.services.auth0 && doc.services.auth0.given_name || '';                       // 46
    doc.lastName = doc.services && doc.services.auth0 && doc.services.auth0.family_name || '';                       // 47
    doc.avatar = doc.services && doc.services.auth0 && doc.services.auth0.picture_large || doc.services && doc.services.auth0 && doc.services.auth0.picture || 'https://s3-us-west-2.amazonaws.com/producehour/avatar.png';
    doc.influenceScore = 1000;                                                                                       // 49
    doc.rating = 0;                                                                                                  // 50
    doc.didSetProfile = false;                                                                                       // 51
    doc.privacy = false;                                                                                             // 52
});                                                                                                                  //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"i18n":{"de.i18n.json":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// i18n/de.i18n.json                                                                                                 //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var _ = Package.underscore._,
    package_name = "project",
    namespace = "project";

if (package_name != "project") {
    namespace = TAPi18n.packages[package_name].namespace;
}
TAPi18n.languages_names["de"] = ["German","Deutsch"];
TAPi18n._enable({"helper_name":"_","supported_languages":null,"i18n_files_route":"/tap-i18n","preloaded_langs":[],"cdn_path":null});
TAPi18n.languages_names["en"] = ["English","English"];
if(_.isUndefined(TAPi18n.translations["de"])) {
  TAPi18n.translations["de"] = {};
}

if(_.isUndefined(TAPi18n.translations["de"][namespace])) {
  TAPi18n.translations["de"][namespace] = {};
}

_.extend(TAPi18n.translations["de"][namespace], {"account-details":"Account-Details","actions":"Aktionen","activity":"Aktivität","activity-archived":"hat %s archiviert","activity-created":"hat % erstellt","activity-added":"hat %s zu %s hinzugefügt","activity-excluded":"hat %s von %s ausgeschlossen","activity-moved":"hat %s von %s nach %s verschoben","activity-sent":"hat %s zu %s geschickt","activity-joined":"ist %s beigetreten","activity-unjoined":"hat %s verlassen","activity-removed":"hat %s von %s entfernt","activity-attached":"hat %s zu %s angehängt","activity-on":"bei %s","this-board":"dieses Board","this-card":"diese Karte","add":"Hinzufügen","add-board":"Neues Board hinzufügen","add-card":"Karte hinzufügen…","add-list":"Liste hinzufügen...","add-members":"Benutzer hinzufügen...","add-attachment":"Anhang hinzufügen...","added":"Hinzugefügt","attached":"angehängt","admin":"Admin","admin-desc":"Kann Karten anschauen und bearbeiten, Benutzer entfernen und Board-Einstellungen ändern.","already-have-account-question":"Hast du schon einen Account?","archive":"Archiv","archive-all":"Alles archivieren","archive-list":"Diese Liste archivieren","archive-title":"Karte von diesem Board entfernen.","archived-items":"Archivierte Einträge","back":"Zurück","bio":"Biographie","board-list-btn-title":"Liste der Boards anschauen","board-not-found":"Board nicht gefunden","board-public-info":"Dieses Board wird <strong>öffentlich</strong> sein.","boards":"Boards","bucket-example":"Zum Beispiel \"Lebensziele\"…","cancel":"Abbrechen","card-archived":"Diese Karte wurd archiviert.","card-comments-title":"Diese Karte hat %s Kommentare.","card-delete-notice":"Löschen ist irreversibel. Alle Aktionen, die mit dieser Karte zu tun haben werden ebenfalls gelöscht.","card-delete-pop":"Alle Aktionen werden vom Aktivitäts Feed entfernt und du kannst die Karte nicht mehr wiederherstellen. Es gibt kein zurück. Du kannst die Karte statdessen archivieren, um sie vom Board zu entfernen und die Aktivitäten beizubehalten.","attachment-delete-pop":"Dieser Anhang wird dauerhaft und irreversibel gelöscht.","change-avatar":"Profilbild ändern","change-background":"Hintergrund ändern","change-email":"Email-Adresse ändern","change-name-initials-bio":"Name, Initialen oder Biographie ändern","change-password":"Passwort ändern","change-permissions":"Berechtigungen ändern…","close":"Schließen","close-board":"Board schließen","close-board-pop":"Du kannst das Board wiederherstellen, indem du auf den Menüeintrag \"Boards\" in der Kopfleiste klickst, dann \"Zeige geschlossene Boards an\" auswählst und neben dem gesuchten Board auf \"Wiederherstellen\" klickst.","close-sidebar-title":"Schließe Seitenleiste.","comment":"Kommentar","comment-placeholder":"Schreibe einen Kommentar…","create":"Erstellen","create-account":"Account erstellen","create-new-account":"Neuen Account erstellen","delete":"Löschen","delete-title":"Lösche die Karte und ihren Verlauf. Dies kann nicht rückgängig gemacht werden.","description":"Beschreibung","edit":"Bearbeiten","edit-description":"Beschreibung bearbeiten…","edit-profile":"Profil bearbeiten","email":"E-Maildresse","email-or-username":"E-Mailadresse oder Benutzername","email-placeholder":"z.B. doc@frankenstein.com","filter-cards":"Karten filtern","filter-clear":"Filter zurücksetzen.","filter-on":"Filter sind eingeschaltet.","filter-on-desc":"Du filterst die Karten auf diesem Board. Klicke hier, um die Filter zu bearbeiten.","fullname":"Vollständiger Name","gloabal-search":"Globale Suche","header-logo-title":"Zurück zur Board-Seite.","home":"Home","home-button":"Melde dich an — Es ist kostenlos!","home-login":"Oder logge dich ein.","in-list":"in der Liste","info":"Informationen","joined":"beigetreten","labels":"Labels","labels-title":"Labels für diese Karte ändern.","label-create":"Neues Label erstellen.","label-delete-pop":"Es gibt kein zurück. Das Label wird von allen Karten entfernt und seine Historie gelöscht.","label-default":"%s Label (Default)","attachments":"Anhänge","attachment":"Anhang","last-admin-desc":"Du kannst die Rolle nicht ändern, es muss mindestens einen Admin geben.","language":"Sprache","leave-board":"Board verlassen…","link-card":"Link zu dieser Karte","list-move-cards":"Verschiebe alle Karten in dieser Liste…","list-archive-cards":"Archiviere alle Karten in dieser Liste…","list-archive-cards-pop":"Dies entfernt alle Karten in der Liste vom Board. Um archivierte Karten anzusehen und zurück zum Board zu bringen, klicke \"Menü\" > \"Archivierte Karten\". ","log-in":"Anmelden","log-out":"Abmelden","members":"Benutzer","members-title":"Füge Benutzer des Boards hinzu oder entferne sie von der Karte.","menu":"Menü","modal-close-title":"Schließe das Dialogfenster.","my-boards":"Meine Boards","name":"Name","name-placeholder":"z.B. Dr. Frankenstein","new-here-question":"Neu hier?","normal":"Normal","normal-desc":"Kann Karten anschauen und bearbeiten, aber keine Einstellungen ändern.","no-boards":"Keine Boards.","no-results":"Keine Ergebnisse","notifications-title":"Benachrichtigungen","optional":"optional","page-maybe-private":"Diese Seite könnte privat sein.  Vielleicht kannst du sie sehen, wenn du dich <a href='%s'>einloggst</a>.","page-not-found":"Seite nicht gefunden.","password":"Passwort","password-placeholder":"z.B: ••••••••••••••••","private":"Privat","private-desc":"Dieses Board ist privat. Nur Benutzer, die diesem Board hinzugefügt wurden, können es anschauen und bearbeiten. ","profile":"Profil","public":"Öffentlich","public-desc":"Dieses Board ist öffentlich. Es ist für jeden, der den Link kennt, sichtbar und taucht in Suchmaschienen wie Google auf. Nur Benutzer, die zum Board hinzugefügt wurden können es bearbeiten.","remove-from-board":"Vom Board entfernen…","remove-member":"Benutzer entfernen","remove-member-from-card":"Von Karte entfernen","remove-member-pop":"Entferne __name__ (__username__) von __boardTitle__? Das Mitglied wird von allen Karten auf diesem Board entfernt werden. Er wird eine Benachrichtigung erhalten.","add-cover":"Auf Vorderseite anzeigen","remove-cover":"Von Vorderseite entfernen","rename":"Umbenennen","save":"Speichern","search":"Suchen","computer":"Computer","download":"Herunterladen","search-member-desc":"Suche nach einer Person in LibreBord nach Name oder E-Mailadresse, oder lade jemanden über seine E-Mailadresse ein.","search-title":"Suche nach Boards, Karten, Benutzern und Organisationen.","select-color":"Wähle eine Farbe aus","send-to-board":"Zu Board schicken","send-to-board-title":"Schicke die Karte zurück zum Board.","settings":"einstellungen","share-and-more":"Teilen und mehr…","share-and-more-title":"Mehr Optionen teilen, drucken, exportieren und löschen.","show-sidebar":"Zeige Seitenleiste","sign-up":"Anmelden","star-board-title":"Klicke, um das Board zu favorisieren. Es erscheint dann oben in deiner Boardliste.","starred-boards":"Favorisierte Boards","starred-boards-description":"Favorisierte Boards erscheinen oben in deine Boardliste.","click-to-star":"Klicken um das Board zu favorisieren.","click-to-unstar":"Klicke, um den Stern zu entfernen.","subscribe":"Abonnieren","team":"Team","title":"Titel","user-profile-not-found":"Benutzer-Profil wurde nicht gefunden.","username":"Benutzername","warning-signup":"Kostenlos anmelden","cardLabelsPopup-title":"Labels","cardMembersPopup-title":"Benutzer","cardMorePopup-title":"Mehr","cardDeletePopup-title":"Karte entfernen?","boardChangeTitlePopup-title":"Board umbenennen","boardChangePermissionPopup-title":"Ändere Sichbarkeit","addMemberPopup-title":"Nutzer","closeBoardPopup-title":"Schliese Board?","removeMemberPopup-title":"Entferne Benutzer?","createBoardPopup-title":"Erstelle ein Board","listActionPopup-title":"Liste von Aktionen","editLabelPopup-title":"Ändere Label","listMoveCardsPopup-title":"Verschiebe alle Karten in der Liste","listArchiveCardsPopup-title":"Alle Karten in der Liste archivieren?","createLabelPopup-title":"Label erstellen","deleteLabelPopup-title":"Entferne Label?","changePermissionsPopup-title":"Ändere Erlaubnisse","setLanguagePopup-title":"Ändere Sprache","cardAttachmentsPopup-title":"Anhang von...","attachmentDeletePopup-title":"Anhang löschen?"});
TAPi18n._registerServerTranslator("de", namespace);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"en.i18n.json":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// i18n/en.i18n.json                                                                                                 //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var _ = Package.underscore._,
    package_name = "project",
    namespace = "project";

if (package_name != "project") {
    namespace = TAPi18n.packages[package_name].namespace;
}
// integrate the fallback language translations 
translations = {};
translations[namespace] = {"accept":"Accept","account-details":"Account Details","actions":"Actions","activity":"Activity","activity-archived":"archived %s","activity-created":"created %s","activity-added":"added %s to %s","activity-excluded":"excluded %s from %s","activity-moved":"moved %s from %s to %s","activity-sent":"sent %s to %s","activity-joined":"joined %s","activity-unjoined":"unjoined %s","activity-removed":"removed %s from %s","activity-attached":"attached %s to %s","activity-on":"on %s","applicants":"Applicants","this-board":"this board","this-card":"this task","add":"Add","add-board":"Add a new board","add-card":"Add a task","add-list":"Add a list…","add-members":"Add Members…","add-attachment":"Add an attachment…","added":"Added","attached":"attached","admin":"Admin","admin-desc":"Can view and edit tasks, remove members, and change settings for the board.","already-have-account-question":"Already have an account?","archive":"Archive","archive-all":"Archive All","archive-list":"Archive this list","archive-title":"Remove the task from the board.","archived-items":"Archived Items","assets":"assets","back":"Back","bio":"Bio","board-list-btn-title":"View list of boards","board-not-found":"Board not found","board-public-info":"This board will be <strong>public</strong>.","boards":"Boards","bucket-example":"Like “Bucket List” for example…","calendar":"calendar","calendar_view":"Tasks due","cancel":"Cancel","card-archived":"This task is archived.","card-comments-title":"This task has %s comment.","card-delete-notice":"Deleting is permanent. You will lose all actions associated with this card.","card-delete-pop":"All actions will be removed from the activity feed and you won't be able to re-open the card. There is no undo. You can archive a card to remove it from the board and preserve the activity.","attachment-delete-pop":"Deleting an attachment is permanent. There is no undo.","change-avatar":"Change Avatar","change-background":"Change background","change-email":"Change Email","change-name-initials-bio":"Change Name, Initials, or Bio","change-password":"Change Password","change-permissions":"Change permissions…","close":"Close","close-board":"Close Project…","close-board-pop":"You can re-open the board by clicking the “Boards” menu from the header, selecting “View Closed Boards”, finding the board and clicking “Re-open”.","close-sidebar-title":"Close the board sidebar.","comment":"Comment","comment-placeholder":"Write a comment…","contribution":"Contribution promised:","create":"Create","create-account":"Create an Account","create-new-account":"Create a new account","delete":"Delete","delete-title":"Delete the task and all history associated with it. It can’t be retrieved.","description":"Description","due_date":"Due Date","due-date-title":"Assign due date for the task","edit":"Edit","edit-description":"Edit the description…","edit-profile":"Edit profile","email":"Email","email-or-username":"Email or username","email-placeholder":"e.g., doc@frankenstein.com","filter-cards":"Filter Cards","filter-clear":"Clear filter.","filter-on":"Filtering is on.","filter-on-desc":"You are filtering cards on this board. Click here to edit filter.","fullname":"Full Name","gloabal-search":"Global Search","header-logo-title":"Go back to your boards page.","home":"Home","home-button":"Sign Up—It’s Free!","home-login":"Or log in","in-list":"in list","info":"Infos","joined":"joined","labels":"Labels","labels-title":"Change the labels for the task.","label-create":"Create a new label","label-delete-pop":"There is no undo. This will remove this label from all tasks and destroy its history.","label-default":"%s label (default)","attachments":"Assets","attachment":"Asset","last-admin-desc":"You can’t change roles because there must be at least one admin.","language":"Language","leave-board":"Leave Board…","link-card":"Link to this task","list-move-cards":"Move All Cards in This List…","list-archive-cards":"Archive All Cards in This List…","list-archive-cards-pop":"This will remove all the tasks in this list from the board. To view archived tasks and bring them back to the board, click “Menu” > “Archived Items”.","log-in":"Log In","log-out":"Log Out","members":"Members","members-title":"Add or remove members of the board from the task.","menu":"Menu","mine":"my tasks","modal-close-title":"Close this dialog window.","my-boards":"My Boards","name":"Name","name-placeholder":"e.g., Dr. Frankenstein","new-here-question":"New here?","normal":"Normal","normal-desc":"Can view and edit tasks. Can't change settings.","no-boards":"No boards.","no-results":"No results","notifications-title":"Notifications","optional":"optional","page-maybe-private":"This page may be private. You may be able to view it by <a href='%s'>logging in</a>.","page-not-found":"Page not found.","password":"Password","password-placeholder":"e.g., ••••••••••••••••","private":"Private","private-desc":"This board is private. Only people added to the board can view and edit it.","profile":"Profile","public":"Public","public-desc":"This board is public. It's visible to anyone with the link and will show up in search engines like Google. Only people added to the board can edit.","remove-from-board":"Remove from Board…","remove-member":"Remove Member","remove-member-from-card":"Remove from Task","remove-member-pop":"Remove __name__ (__username__) from __boardTitle__? The member will be removed from all cards on this board. They will receive a notification.","add-cover":"Add Cover","reject":"Reject","remove-cover":"Remove Cover","rename":"Rename","save":"Save","search":"Search","computer":"Computer","download":"Download","search-member-desc":"Search for a person in LibreBoard by name or email address, or enter an email address to invite someone new.","search-title":"Search for boards, tasks, members, and organizations.","select-color":"Select a color","send-to-board":"Unarchive","send-to-board-title":"Send the task back to the board.","settings":"settings","share-and-more":"Share and more…","share-and-more-title":"More options share, print, export, and delete.","show-sidebar":"Show sidebar","sign-up":"Sign Up","star-board-title":"Click to star this board. It will show up at top of your boards list.","starred-boards":"Starred Boards","starred-boards-description":"Starred boards show up at the top of your boards list.","stats":"stats","click-to-star":"Click to star this board.","click-to-unstar":"Click to unstar this board.","subscribe":"Subscribe","tasks":"tasks","team":"Team","title":"Title","user-profile-not-found":"User Profile not found.","username":"Username","warning-signup":"Sign up for free","cardLabelsPopup-title":"Labels","cardMembersPopup-title":"Members","cardMorePopup-title":"More","cardDeletePopup-title":"Delete Card?","boardChangeTitlePopup-title":"Rename Board","boardChangePermissionPopup-title":"Change Visibility","addMemberPopup-title":"Members","closeBoardPopup-title":"Close Board?","removeMemberPopup-title":"Remove Member?","createBoardPopup-title":"Create Board","listActionPopup-title":"List Actions","editLabelPopup-title":"Change Label","listMoveCardsPopup-title":"Move All Cards in List","listArchiveCardsPopup-title":"Archive All Cards in this List?","createLabelPopup-title":"Create Label","deleteLabelPopup-title":"Delete Label?","changePermissionsPopup-title":"Change Permissions","setLanguagePopup-title":"Change Language","cardAttachmentsPopup-title":"Upload From…","attachmentDeletePopup-title":"Delete Asset?"};
TAPi18n._loadLangFileObject("en", translations);
TAPi18n._registerServerTranslator("en", namespace);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"fr.i18n.json":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// i18n/fr.i18n.json                                                                                                 //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var _ = Package.underscore._,
    package_name = "project",
    namespace = "project";

if (package_name != "project") {
    namespace = TAPi18n.packages[package_name].namespace;
}
TAPi18n.languages_names["fr"] = ["French (France)","Français"];
if(_.isUndefined(TAPi18n.translations["fr"])) {
  TAPi18n.translations["fr"] = {};
}

if(_.isUndefined(TAPi18n.translations["fr"][namespace])) {
  TAPi18n.translations["fr"][namespace] = {};
}

_.extend(TAPi18n.translations["fr"][namespace], {"account-details":"Détails du compte","actions":"Actions","activity":"Activité","activity-archived":"a archivé %s","activity-created":"créé %s","activity-added":"a ajouté %s à %s","activity-excluded":"a exclu %s de %s","activity-moved":"a déplacé %s depuis %s vers %s","activity-sent":"a envoyé %s vers %s","activity-joined":"a rejoint %s","activity-unjoined":"a quitté %s","activity-removed":"a supprimé %s vers %s","activity-attached":"a attaché %s à %s","activity-on":"sur %s","this-board":"ce tableau","this-card":"cette carte","add":"Ajouter","add-board":"Ajouter un nouveau tableau","add-card":"Ajouter une carte…","add-list":"Ajouter une liste…","add-members":"Ajouter des membres…","add-attachment":"Ajouter une pièce jointe…","added":"Ajouté","attached":"joint","admin":"Admin","admin-desc":"Peut voir et éditer les cartes, supprimer des membres, et changer les paramètres du tableau.","already-have-account-question":"Vous avez déjà un compte?","archive":"Archiver","archive-all":"Tout archiver","archive-list":"Archiver cette liste","archive-title":"Retirer cette carte du tableau.","archived-items":"Éléments archivés","back":"Retour","bio":"Bio","board-list-btn-title":"Voir la liste des tableaux","board-not-found":"Tableau non trouvé","board-public-info":"Ce tableau sera <strong>public</strong>.","boards":"Tableaux","bucket-example":"par exemple « liste de courses »","cancel":"Annuler","card-archived":"Cette carte est archivée.","card-comments-title":"Cette carte a %s commentaires.","card-delete-notice":"La suppression est permanente. Vous perdrez toutes les actions associées à cette carte.","card-delete-pop":"Cette action est irréversible. Tous les commentaires et les activités associés à cette carte seront supprimés et il ne sera pas possible de ré-ouvrir la carte. Vous pouvez aussi archiver la carte pour l'enlever du tableau tout en préservant les activités.","attachment-delete-pop":"La suppression d'une pièce jointe est définitive. Elle ne peut être annulée.","change-avatar":"Changer l'avatar","change-background":"Changer le fond","change-email":"Changer l'email","change-name-initials-bio":"Change le nom, les initiales, la bio","change-password":"Changer le mot de passe","change-permissions":"Changer les permissions","close":"Fermer","close-board":"Clôturer le tableau…","close-board-pop":"Vous pouvez ré-ouvrir le tableau en cliquant sur le menu « Tableau » dans la barre d'en-tête, puis en sélection « Voir les tableaux fermés », en trouvant le tableau désiré puis en cliquant sur « Ré-ouvrir ».","close-sidebar-title":"Fermer le menu de tableau.","comment":"Commentaire","comment-placeholder":"Écrire un commentaire…","create":"Créer","create-account":"Créer un compe","create-new-account":"Créer un nouveau compte","delete":"Supprimer","delete-title":"Supprimer la carte et son historique d'activité. Cette action est irréversible.","description":"Description","edit":"Éditer","edit-description":"Éditer la description…","edit-profile":"Éditer le profil","email":"Email","email-or-username":"Email ou nom d'utilisateur","email-placeholder":"exemple, doc@frankenstein.com","filter-cards":"Filter Cards","filter-clear":"Clear filter.","filter-on":"Filtering is on.","filter-on-desc":"You are filtering cards on this board. Click here to edit filter.","fullname":"Nom complet","gloabal-search":"Recherche globale","header-logo-title":"Retourner à la page des tableaux","home":"Accueil","home-button":"Inscrivez vous — C'est gratuit !","home-login":"Ou connectez vous","in-list":"dans la liste","info":"Infos","joined":"a joint","labels":"Étiquettes","labels-title":"Modifier les étiquettes de la carte.","label-create":"Créer une nouvelle étiquette","label-delete-pop":"Cette action est irréversible. Elle supprimera cette étiquette de toutes les cartes ainsi que l'historique associé.","label-default":"%s label (default)","attachments":"Pièces jointes","attachment":"Pièce jointe","last-admin-desc":"Vous ne pouvez pas changer les rôles car il doit y avoir au moins un admin.","language":"Langage ","leave-board":"Quitter le tableau…","link-card":"Lier cette carte","list-move-cards":"Déplacer les cartes de cette liste…","list-archive-cards":"Archiver les cartes de cette liste…","list-archive-cards-pop":"Cela archivera toutes les cartes de cette liste. Pour voir les cartes archivées et les ramener vers le tableau, cliquez sur le « Menu » puis sur « Éléments archivés ».","log-in":"Connexion","log-out":"Déconnexion","members":"Membres","members-title":"Ajouter ou supprimer des membres à la carte.","menu":"Menu","modal-close-title":"Fermer cette boite de dialogue.","my-boards":"Mes tableaux","name":"Nom","name-placeholder":"exemple, Dr. Frankenstein","new-here-question":"Nouveau ici ?","normal":"Normal","normal-desc":"Peut voir et éditer les cartes. Ne peut pas changer les paramètres.","no-boards":"Pas de tableaux.","no-results":"Pas de résultats","notifications-title":"Notifications","optional":"optionnel","page-maybe-private":"Cette page est peut-être privée. Vous pourrez peut-être la voir en vous <a href='%s'>connectant</a>.","page-not-found":"Page non trouvé","password":"Mot de passe","password-placeholder":"exemple, ••••••••••••••••","private":"Privé","private-desc":"Ce tableau est privé. Seul les membres peuvent y accéder.","profile":"Profil","public":"Public","public-desc":"Ce tableau est public. Il est visible par toutes les personnes possédant le lien et visible dans les moteurs de recherche tels que Google. Seuls les membres peuvent l'éditer.","remove-from-board":"Supprimer du tableau…","remove-member":"Supprimer le membre","remove-member-from-card":"Supprimer de la carte","remove-member-pop":"Supprimer __name__ (__username__) de __boardTitle__ ? Ce membre sera supprimé de toutes les cartes du tableau et recevra une notification.","add-cover":"Ajouter la couverture","remove-cover":"Enlever la couverture","rename":"Renommer","save":"Sauvegarder","search":"Chercher","computer":"Ordinateur","download":"Télécharger","search-member-desc":"Chercher un utilisateur de LibreBoard par nom ou par son adresse email ou entrez une adrese email pour inviter un nouvel utilisateur.","search-title":"Chercher des tableaux, cartes, membres, et organisations.","select-color":"Choisissez une couleur","send-to-board":"Envoyer vers le tableau","send-to-board-title":"Renvoyer cette carte vers le tableau.","settings":"paramètres","share-and-more":"Partage et plus…","share-and-more-title":"Plus d'options partager, imprimer, exporter, et supprimer.","show-sidebar":"Afficher le menu","sign-up":"Inscription","star-board-title":"Cliquer pour ajouter ce tableau aux favoris. Il sera affiché en haut de votre liste de tableaux.","starred-boards":"Tableaux favoris","starred-boards-description":"Les tableaux favoris s'affichent en haut de votre liste de tableaux.","click-to-star":"Cliquez pour ajouter ce tableau aux favoris.","click-to-unstar":"Cliquez pour retirer ce tableau des favoris.","subscribe":"Suivre","team":"Équipe","title":"Titre","user-profile-not-found":"Profil utilisateur non trouvé.","username":"Nom d'utilisateur","warning-signup":"Inscription gratuite","cardLabelsPopup-title":"Étiquettes","cardMembersPopup-title":"Membres","cardMorePopup-title":"Plus","cardDeletePopup-title":"Supprimer la carte ?","boardChangeTitlePopup-title":"Renommer le tableau","boardChangePermissionPopup-title":"Changer la visibilité","addMemberPopup-title":"Membres","closeBoardPopup-title":"Fermer le tableau ?","removeMemberPopup-title":"Supprimer le membre ?","createBoardPopup-title":"Créer un tableau","listActionPopup-title":"Liste des actions","editLabelPopup-title":"Changer l'étiquette","listMoveCardsPopup-title":"Déplacer les cartes de la liste","listArchiveCardsPopup-title":"Archiver les cartes de la liste ?","createLabelPopup-title":"Créer un étiquette","deleteLabelPopup-title":"Supprimer l'étiquette ?","changePermissionsPopup-title":"Changer les permissions","setLanguagePopup-title":"Changer la langue","cardAttachmentsPopup-title":"Joindre depuis…","attachmentDeletePopup-title":"Supprimer la pièce jointe ?"});
TAPi18n._registerServerTranslator("fr", namespace);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"ja.i18n.json":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// i18n/ja.i18n.json                                                                                                 //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var _ = Package.underscore._,
    package_name = "project",
    namespace = "project";

if (package_name != "project") {
    namespace = TAPi18n.packages[package_name].namespace;
}
TAPi18n.languages_names["ja"] = ["Japanese","日本語"];
if(_.isUndefined(TAPi18n.translations["ja"])) {
  TAPi18n.translations["ja"] = {};
}

if(_.isUndefined(TAPi18n.translations["ja"][namespace])) {
  TAPi18n.translations["ja"][namespace] = {};
}

_.extend(TAPi18n.translations["ja"][namespace], {"account-details":"アカウント詳細","actions":"操作","activity":"アクティビティ","activity-archived":"%s をアーカイブしました","activity-created":"%s を作成しました","activity-added":"%s を %s に追加しました","activity-excluded":"%s を %s から除外しました","activity-moved":"%s を %s から %s に移動しました","activity-sent":"%s を %s に送りました","activity-joined":"%s にジョインしました","activity-unjoined":"%s から脱退しました","activity-removed":"%s を %s から削除しました","activity-attached":"%s を %s に添付しました","activity-on":"%s","this-board":"このボード","this-card":"このカード","add":"追加","add-board":"ボード追加","add-card":"カード追加...","add-list":"リスト追加...","add-members":"メンバー追加...","add-attachment":"添付ファイルの追加...","added":"追加しました","attached":"添付されました","admin":"管理","admin-desc":"カードの閲覧と編集、メンバーの削除、ボードの設定変更が可能","already-have-account-question":"すでにアカウントをお持ちですか？","archive":"アーカイブ","archive-all":"すべてをアーカイブ","archive-list":"このリストをアーカイブ","archive-title":"ボードからカードを取り除く","archived-items":"アーカイブされたアイテム","back":"戻る","bio":"自己紹介","board-list-btn-title":"ボード一覧を見る","board-not-found":"ボードが見つかりません","board-public-info":"ボードは公開されます。","boards":"ボード","bucket-example":"例：Bucket List","cancel":"キャンセル","card-archived":"カードはアーカイブされました。","card-comments-title":"%s 件のコメントがあります。","card-delete-notice":"削除は取り消しできません。このカードに関係するすべてのアクションがなくなります。","card-delete-pop":"すべての操作はアクティビティフィードから除去され、カードを再オープンすることはできなくなります。この操作は取り消しできません。ボードからカードを取り除きつつアクティビティを保存するためにはアーカイブ機能を利用してください。","attachment-delete-pop":"添付ファイルの削除をすると取り消しできません。","change-avatar":"アバターの変更","change-background":"背景の変更","change-email":"メールアドレスの変更","change-name-initials-bio":"名前、イニシャル、自己紹介の変更","change-password":"パスワードの変更","change-permissions":"権限の変更...","close":"閉じる","close-board":"ボードを閉じる","close-board-pop":"ヘッダーの\"ボード\"メニューから\"閉じたボードを見る\"を選択し、そこでボードを選択して、\"ボードの再開\"をクリックすると、ボードを再度利用できるようになります。","close-sidebar-title":"サイドバーを閉じる","comment":"コメント","comment-placeholder":"コメントする","create":"作成","create-account":"アカウント作成","create-new-account":"新規アカウント作成","delete":"削除","delete-title":"関係するカードと履歴を削除します。この操作は取り消しできません。","description":"詳細","edit":"編集","edit-description":"詳細を編集する","edit-profile":"プロフィール編集","email":"メールアドレス","email-or-username":"メールアドレスまたはユーザー名","email-placeholder":"例：doc@frankenstein.com","filter-cards":"カードをフィルターする","filter-clear":"フィルター解除","filter-on":"フィルターが有効です。","filter-on-desc":"このボードのカードをフィルターしています。フィルターを編集するにはこちらをクリックしてください。","fullname":"フルネーム","gloabal-search":"グローバル検索","header-logo-title":"自分のボードページに戻る。","home":"ホーム","home-button":"サインアップー無料!","home-login":"またはログイン","in-list":"リスト：","info":"情報","joined":"参加しました","labels":"ラベル","labels-title":"カードのラベルを変更する","label-create":"ラベル作成","label-delete-pop":"この操作は取り消しできません。このラベルはすべてのカードから外され履歴からも見えなくなります。","label-default":"%s ラベル(デフォルト)","attachments":"添付ファイル","attachment":"添付ファイル","last-admin-desc":"最低でも1人以上の管理者が必要なためロールを変更できません。","language":"言語","leave-board":"ボードから移動...","link-card":"このカードへのリンク","list-move-cards":"このリスト内の全カードを移動...","list-archive-cards":"このリスト内の全カードをアーカイブ...","list-archive-cards-pop":"ボードのこのリスト内のすべてのカードを取り除きます。アーカイブされたカードの確認やそれをボードに戻すには、メニューをクリックし、\"アーカイブされたアイテム\"をクリックしてください。","log-in":"ログイン","log-out":"ログアウト","members":"メンバー","members-title":"カードからボードメンバーを追加・削除する","menu":"メニュー","modal-close-title":"ダイアログを閉じる","my-boards":"自分のボード","name":"名前","name-placeholder":"例：Dr.フランケンシュタイン","new-here-question":"初めてですか？","normal":"通常","normal-desc":"カードの閲覧と編集が可能。設定変更不可。","no-boards":"ボードがありません。","no-results":"該当するものはありません","notifications-title":"通知","optional":"任意","page-maybe-private":"このページはプライベートです。<a href='%s'>ログイン</a>して見てください。","page-not-found":"ページが見つかりません。","password":"パスワード","password-placeholder":"例： ••••••••••••••••","private":"プライベート","private-desc":"このボードはプライベートです。ボードメンバーのみが閲覧・編集可能です。","profile":"プロフィール","public":"公開","public-desc":"このボードはパブリックです。リンクを知っていれば誰でもアクセス可能でGoogleのような検索エンジンの結果に表示されます。このボードに追加されている人だけがカード追加が可能です。","remove-from-board":"ボードから取り除く...","remove-member":"メンバーを外す","remove-member-from-card":"カードから取り除く","remove-member-pop":"__boardTitle__ から __name__ (__username__) を外しますか？メンバーはこのボードのすべてのカードから外れ、通知を受けます。","add-cover":"カバーの追加","remove-cover":"カバーの削除","rename":"名前変更","save":"保存","search":"検索","computer":"コンピューター","download":"ダウンロード","search-member-desc":"名前またはメールアドレスでLibreBoard内のユーザーを検索するか、新たなユーザーを招待するにはメールアドレスを入力してください。","search-title":"ボード、カード、メンバー、組織の検索","select-color":"色を選択","send-to-board":"ボードへ送る","send-to-board-title":"カードをボードに戻す","settings":"設定","share-and-more":"共有、その他","share-and-more-title":"共有、印刷、エクスポートおよび削除などのオプション","show-sidebar":"サイドバーを表示","sign-up":"サインアップ","star-board-title":"ボードにスターをつけると自分のボード一覧のトップに表示されます。","starred-boards":"スターのついたボード","starred-boards-description":"スターのついたボードはボードリストの先頭に表示されます。","click-to-star":"ボードにスターをつける","click-to-unstar":"ボードからスターを外す","subscribe":"購読","team":"チーム","title":"タイトル","user-profile-not-found":"プロフィールが見つかりません。","username":"ユーザー名","warning-signup":"無料でサインアップ","cardLabelsPopup-title":"ラベル","cardMembersPopup-title":"メンバー","cardMorePopup-title":"さらに見る","cardDeletePopup-title":"カードを削除しますか？","boardChangeTitlePopup-title":"ボード名の変更","boardChangePermissionPopup-title":"公開範囲の変更","addMemberPopup-title":"メンバー","closeBoardPopup-title":"ボードを閉じますか？","removeMemberPopup-title":"メンバーを外しますか？","createBoardPopup-title":"ボードの作成","listActionPopup-title":"操作一覧","editLabelPopup-title":"ラベルの変更","listMoveCardsPopup-title":"リスト内のすべてのカードを移動する","listArchiveCardsPopup-title":"このリスト内の善カードをアーカイブしますか？","createLabelPopup-title":"ラベルの作成","deleteLabelPopup-title":"ラベルを削除しますか？","changePermissionsPopup-title":"パーミッションの変更","setLanguagePopup-title":"言語の変更","cardAttachmentsPopup-title":"添付する...","attachmentDeletePopup-title":"添付ファイルを削除しますか？"});
TAPi18n._registerServerTranslator("ja", namespace);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"pt-BR.i18n.json":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// i18n/pt-BR.i18n.json                                                                                              //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var _ = Package.underscore._,
    package_name = "project",
    namespace = "project";

if (package_name != "project") {
    namespace = TAPi18n.packages[package_name].namespace;
}
TAPi18n.languages_names["pt-BR"] = ["Portuguese (Brazil)","Português do Brasil"];
if(_.isUndefined(TAPi18n.translations["pt-BR"])) {
  TAPi18n.translations["pt-BR"] = {};
}

if(_.isUndefined(TAPi18n.translations["pt-BR"][namespace])) {
  TAPi18n.translations["pt-BR"][namespace] = {};
}

_.extend(TAPi18n.translations["pt-BR"][namespace], {"account-details":"Detalhes da Conta","actions":"Ações","activity":"Atividade","activity-archived":"arquivou %s","activity-created":"criou %s","activity-added":"adicionou %s a %s","activity-excluded":"excluiu %s de %s","activity-moved":"moveu %s de %s para %s","activity-sent":"enviou %s de %s","activity-joined":"juntou-se a %s","activity-unjoined":"deixou %s","activity-removed":"removeu %s de %s","activity-attached":"anexou %s a %s","activity-on":"em %s","this-board":"este quadro","this-card":"este cartão","add":"Novo","add-board":"Criar um quadro novo","add-card":"Criar um cartão…","add-list":"Criar uma lista…","add-members":"Adicionar membros…","add-attachment":"Adicionar anexos…","added":"Criado","attached":"anexado","admin":"Administrador","admin-desc":"Pode ver e editar cartões, remover membros e alterar configurações do quadro.","already-have-account-question":"Já possui uma conta?","archive":"Arquivar","archive-all":"Arquivar Tudo","archive-list":"Arquivar esta lista","archive-title":"Remover cartão do quadro.","archived-items":"Itens Arquivados","back":"Voltar","bio":"Biografia","board-list-btn-title":"Ver lista de quadros","board-not-found":"Quadro não encontrado","board-public-info":"Este quadro será <strong>público</strong>.","boards":"Quadros","bucket-example":"“Lista de Compras”, por exemplo…","cancel":"Cancelar","card-archived":"Este cartão está arquivado.","card-comments-title":"Este cartão possui %s comentários.","card-delete-notice":"A exclusão será permanente. Você perderá todas as ações associadas a este cartão.","card-delete-pop":"Todas as ações serão excluídas da lista de atividades e o cartão não poderá ser reaberto. Você pode arquivá-lo para removê-lo do quadro preservando sua atividade.","attachment-delete-pop":"Excluir um anexo é permanente. Não será possível recuperá-lo.","change-avatar":"Alterar Avatar","change-background":"Alterar plano de fundo","change-email":"Alterar E-mail","change-name-initials-bio":"Alterar Nome, Iniciais ou Biografia","change-password":"Alterar Senha","change-permissions":"Alterar permissões…","close":"Fechar","close-board":"Fechar Quadro…","close-board-pop":"Você pode reabrir um quadro clicando em “Quadros” no menu no cabeçalho, selecionando “Exibir Quadros Fechados”, encontrando-o e clicando em “Reabrir”.","close-sidebar-title":"Fechar barra lateral.","comment":"Comentário","comment-placeholder":"Comentar…","create":"Criar","create-account":"Criar uma Conta","create-new-account":"Criar uma nova conta","delete":"Excluir","delete-title":"Excluir cartão e todo o seu histórico. Não será possível recuperá-lo.","description":"Descrição","edit":"Editar","edit-description":"Editar a descrição…","edit-profile":"Editar perfil","email":"E-mail","email-or-username":"E-mail ou nome de usuário","email-placeholder":"ex.: dr@frankenstein.com","filter-cards":"Filtrar Cartões","filter-clear":"Limpar filtro.","filter-on":"Filtro ativado.","filter-on-desc":"Você está filtrando cartões neste quadro. Clique aqui para editar o filtro.","fullname":"Nome Completo","gloabal-search":"Busca Global","header-logo-title":"Voltar para a lista de quadros.","home":"Início","home-button":"Cadastre-se. É gratuito!","home-login":"Ou entre","in-list":"na lista","info":"Informações","joined":"juntou-se","labels":"Etiquetas","labels-title":"Alterar etiquetas do cartão.","label-create":"Criar uma nova etiqueta","label-delete-pop":"Não será possível recuperá-la. A etiqueta será removida de todos os cartões e seu histórico será destruído.","label-default":"%s etiqueta (padrão)","attachments":"Anexos","attachment":"Anexo","last-admin-desc":"Você não pode alterar funções porque deve existir pelo menos um administrador.","language":"Idioma","leave-board":"Deixar Quadro…","link-card":"Vincular a este cartão","list-move-cards":"Mover Todos Os Cartões nesta Lista…","list-archive-cards":"Arquivar Todos Os Cartões nesta Lista…","list-archive-cards-pop":"Isto removerá todos os cartões desta lista do quadro. Para visualizar os cartões arquivados e trazê-los de volta para o quadro, clique em “Menu” > “Itens Arquivados”.","log-in":"Entrar","log-out":"Sair","members":"Membros","members-title":"Acrescentar ou remover membros do quadro deste cartão.","menu":"Menu","modal-close-title":"Fechar esta janela.","my-boards":"Meus Quadros","name":"Nome","name-placeholder":"ex.: Dr. Frankenstein","new-here-question":"Novo aqui?","normal":"Normal","normal-desc":"Pode ver e editar cartões. Não pode alterar configurações.","no-boards":"Nenhum quadro.","no-results":"Nenhum resultado.","notifications-title":"Notificações","optional":"opcional","page-maybe-private":"Esta página pode ser privada. Você poderá vê-la se estiver <a href='%s'>logado</a>.","page-not-found":"Página não encontrada.","password":"Senha","password-placeholder":"ex.: ••••••••••••••••","private":"Privado","private-desc":"Este quadro é privado. Apenas seus membros podem acessar e editá-lo.","profile":"Perfil","public":"Público","public-desc":"Este quadro é público. Ele é visível a qualquer pessoa com o link e será exibido em mecanismos de busca como o Google. Apenas seus membros podem editá-lo.","remove-from-board":"Remover do Quadro…","remove-member":"Remover Membro","remove-member-from-card":"Remover do Cartão","remove-member-pop":"Remover __name__ (__username__) de __boardTitle__? O membro será removido de todos os cartões neste quadro e será notificado.","add-cover":"Adicionar Capa","remove-cover":"Remover Capa","rename":"Renomear","save":"Salvar","search":"Buscar","computer":"Computador","download":"Baixar","search-member-desc":"Busque uma pessoa no LibreBoard por nome ou e-mail, ou digite um e-mail para convidar alguém.","search-title":"Busque quadros, cartões, membros e organizações.","select-color":"Selecione uma cor","send-to-board":"Enviar para o quadro","send-to-board-title":"Enviar cartão de volta para o quadro.","settings":"configurações","share-and-more":"Compartilhar e mais…","share-and-more-title":"Mais opções: compartilhar, imprimir, exportar e excluir.","show-sidebar":"Barra lateral","sign-up":"Cadastre-se","star-board-title":"Clique para marcar este quadro como favorito. Ele aparecerá no topo na lista dos seus quadros.","starred-boards":"Quadros Favoritos","starred-boards-description":"Quadros favoritos aparecem no topo da lista dos seus quadros.","click-to-star":"Marcar quadro como favorito.","click-to-unstar":"Remover quadro dos favoritos.","subscribe":"Acompanhar","team":"Equipe","title":"Título","user-profile-not-found":"Perfil de usuário não encontrado.","username":"Nome de usuário","warning-signup":"Cadastre-se gratuitamente","cardLabelsPopup-title":"Etiquetas","cardMembersPopup-title":"Membros","cardMorePopup-title":"Mais","cardDeletePopup-title":"Excluir Cartão?","boardChangeTitlePopup-title":"Renomear Quadro","boardChangePermissionPopup-title":"Alterar Visibilidade","addMemberPopup-title":"Membros","closeBoardPopup-title":"Fechar Quadro?","removeMemberPopup-title":"Remover Membro?","createBoardPopup-title":"Criar Quadro","listActionPopup-title":"Listar Ações","editLabelPopup-title":"Alterar Etiqueta","listMoveCardsPopup-title":"Mover Todos Os Cartões Nesta Lista","listArchiveCardsPopup-title":"Arquivar Todos Os Cartões Nesta Lista?","createLabelPopup-title":"Criar Etiqueta","deleteLabelPopup-title":"Excluir Etiqueta?","changePermissionsPopup-title":"Alterar Permissões","setLanguagePopup-title":"Alterar Idioma","cardAttachmentsPopup-title":"Anexar de…","attachmentDeletePopup-title":"Excluir Anexo?"});
TAPi18n._registerServerTranslator("pt-BR", namespace);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"tr.i18n.json":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// i18n/tr.i18n.json                                                                                                 //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var _ = Package.underscore._,
    package_name = "project",
    namespace = "project";

if (package_name != "project") {
    namespace = TAPi18n.packages[package_name].namespace;
}
TAPi18n.languages_names["tr"] = ["Turkish","Türkçe"];
if(_.isUndefined(TAPi18n.translations["tr"])) {
  TAPi18n.translations["tr"] = {};
}

if(_.isUndefined(TAPi18n.translations["tr"][namespace])) {
  TAPi18n.translations["tr"][namespace] = {};
}

_.extend(TAPi18n.translations["tr"][namespace], {"account-details":"Hesap Ayrıntıları","actions":"İşlemler","activity":"Etkinlik","activity-archived":"%s arşivledi","activity-created":"%s oluşturdu","activity-added":"added %s to %s","activity-excluded":"excluded %s from %s","activity-moved":"moved %s from %s to %s","activity-sent":"sent %s to %s","activity-joined":"joined %s","activity-unjoined":"unjoinded %s","activity-removed":"removed %s from %s","activity-attached":"attached %s to %s","activity-on":"on %s","this-board":"bu panoyu","this-card":"bu kart","add":"Ekle","add-board":"Yeni bir pano ekle","add-card":"Bir kart ekle...","add-list":"Bir liste ekle...","add-members":"Üye Ekle...","add-attachment":"Bir ek dosya ekle...","added":"Eklendi","attached":"dosya eklendi","admin":"Yönetici","admin-desc":"Kartları görüntüler ve düzenler, üyeleri çıkarır ve pano ayarlarını değiştirir.","already-have-account-question":"Bir hesabın mı var?","archive":"Arşiv","archive-all":"Tümünü Arşivle","archive-list":"Bu listeyi arşivle","archive-title":"Panodan bu kartı kaldır.","archived-items":"Arşivlenmiş Öğeler","back":"Geri","bio":"Biyografi","board-list-btn-title":"Pano listesini görüntüle","board-not-found":"Pano bulunamadı","board-public-info":"Bu pano <strong>genel</strong>e açılacaktır.","boards":"Panolar","bucket-example":"Örnek olarak “Yapılacaklar Listesi” gibi…","cancel":"İptal","card-archived":"Bu kart arşivlendi.","card-comments-title":"This card has %s comment.","card-delete-notice":"Silme işlemi kalıcıdır. Bu kartla ilişkili tüm eylemleri kaybedersiniz.","card-delete-pop":"Tüm eylemler etkinlik beslemesinden kaldırılacaktır ve kartı yeniden açmak mümkün olmayacaktır. Geri dönüşü yok. Panodan çıkarmak ve etkinlik kayıtlarını korumak için kartı arşivleyebilirsin.","attachment-delete-pop":"Ek dosya silme işlemi kalıcıdır. Geri dönüşü yok","change-avatar":"Avatar Değiştir","change-background":"Arkaplan rengi değiştir","change-email":"E-posta Değiştir","change-name-initials-bio":"Ad Soyad, Kullanıcı Adı veya Biyografi Değiştir","change-password":"Parola Değiştir","change-permissions":"Yetkileri değiştir...","close":"Kapat","close-board":"Panoyu Kapat...","close-board-pop":"You can re-open the board by clicking the “Boards” menu from the header, selecting “View Closed Boards”, finding the board and clicking “Re-open”.","close-sidebar-title":"Pano kenar çubuğunu kapat.","comment":"Yorum Gönder","comment-placeholder":"Bir yorum yaz...","create":"Oluştur","create-account":"Bir Hesap Oluştur","create-new-account":"Yeni bir hesap oluştur","delete":"Sil","delete-title":"\n","description":"Açıklama","edit":"Düzenle","edit-description":"Açıklamayı düzenle...","edit-profile":"Bilgilerini düzenle","email":"E-posta","email-or-username":"E-posta veya kullanıcı adı","email-placeholder":"örn., doc@frankenstein.com","filter-cards":"Kartları Süz","filter-clear":"Süzgeci kaldır.","filter-on":"Süzgeç açık.","filter-on-desc":"Bu panodaki kartları süzüyorsunuz. Süzgeci düzenlemek için tıklayın.","fullname":"Ad Soyad","gloabal-search":"Global Search","header-logo-title":"Panolar sayfanıza geri dön.","home":"Home","home-button":"Kaydol—Ücretsiz!","home-login":"Veya oturum aç","in-list":", listesinde","info":"Infos","joined":"joined","labels":"Etiketler","labels-title":"Change the labels for the card.","label-create":"Yeni bir etiket oluştur","label-delete-pop":"Geri dönüşü yok. Tüm kartlardan bu etiket kaldırılacaktır ve geçmişini yok edecektir.","label-default":"%s etiket (varsayılan)","attachments":"Ek Dosyalar","attachment":"Ek Dosya","last-admin-desc":"Rolleri değiştiremezsiniz çünkü burada en az bir yönetici olmalıdır.","language":"Dil","leave-board":"Panodan Ayrıl...","link-card":"Bu kartın bağlantısı","list-move-cards":"Bu Listedeki Tüm Kartları Taşı...","list-archive-cards":"Bu Listedeki Tüm Kartlar Arşivle...","list-archive-cards-pop":"This will remove all the cards in this list from the board. To view archived cards and bring them back to the board, click “Menu” > “Archived Items”.","log-in":"Oturum Aç","log-out":"Oturum Kapat","members":"Üyeler","members-title":"Add or remove members of the board from the card.","menu":"Menü","modal-close-title":"Bu iletişim penceresini kapatın.","my-boards":"Panolarım","name":"Adı","name-placeholder":"örn., Dr. Frankenstein","new-here-question":"Burada yeni misin?","normal":"Normal","normal-desc":"Kartları görüntüler ve düzenler. Ayarları değiştiremez.","no-boards":"Pano yok.","no-results":"Sonuç yok","notifications-title":"Bildirim","optional":"isteğe bağlı","page-maybe-private":"Bu sayfa özel olabilir. <a href='%s'>Oturum açarak</a> görülebilir.","page-not-found":"Sayda bulunamadı.","password":"Parola","password-placeholder":"örn., ••••••••••••••••","private":"Özel","private-desc":"Bu pano özel. Sadece panoya ekli kişiler görüntüleyebilir ve düzenleyebilir.","profile":"Kullanıcı Sayfası","public":"Genel","public-desc":"Bu pano geneldir. Bağlantı adresi ile herhangi bir kimseye  görünür ve Google gibi arama motorlarında  gösterilecektir. Panoyu, sadece eklenen kişiler düzenleyebilir.","remove-from-board":"Panodan çıkar...","remove-member":"Üyeyi Çıkar","remove-member-from-card":"Karttan Çıkar","remove-member-pop":"__boardTitle__ panosundan __name__ (__username__) çıkarılsın mı? Üye, bu panodaki tüm kartlardan çıkarılacak ve bir bildirim alacak.","add-cover":"Add Cover","remove-cover":"Remove Cover","rename":"Ad değiştir","save":"Kaydet","search":"Search","computer":"Bilgisayar","download":"İndir","search-member-desc":"LibreBoard'da, bir kişiyi adı veya e-posta adresi ile arayın ya da yeni birini davet etmek için bir e-posta adresi girin.","search-title":"Pano, kart, üye ve örgütleri ara.","select-color":"Bir renk seç","send-to-board":"Panoya gönder","send-to-board-title":"Kartı, panoya geri gönder.","settings":"ayarlar","share-and-more":"Paylaş ve daha...","share-and-more-title":"Birçok seçenek; paylaş, bastır, dışarı aktar ve sil.","show-sidebar":"Kenar çubuğunu göster","sign-up":"Kaydol","star-board-title":"Bu panoyu yıldızlamak için tıkla. Pano listesinin en üstünde gösterilir.","starred-boards":"Yıldızlı Panolar","starred-boards-description":"Yıldızlanmış panolar, pano listenin en üstünde gösterilir.","click-to-star":"Bu panoyu yıldızlamak için tıkla.","click-to-unstar":"Bu panunun yıldızını kaldırmak için tıkla.","subscribe":"Subscribe","team":"Takım","title":"Başlık","user-profile-not-found":"Kullanıcı Sayfası bulunamadı.","username":"Kullanıcı adı","warning-signup":"Ücretsiz Kaydol","cardLabelsPopup-title":"Etiketler","cardMembersPopup-title":"Üyeler","cardMorePopup-title":"More","cardDeletePopup-title":"Kart Silinsin mi?","boardChangeTitlePopup-title":"Pano Adı Değiştirme","boardChangePermissionPopup-title":"Görünebilirliği Değiştir","addMemberPopup-title":"Üyeler","closeBoardPopup-title":"Pano Kapatılsın mı?","removeMemberPopup-title":"Üyeyi Çıkarmak mı?","createBoardPopup-title":"Pano Oluşturma","listActionPopup-title":"Liste İşlemleri","editLabelPopup-title":"Etiket Değiştirme","listMoveCardsPopup-title":"Listedeki Tüm Kartları Taşıma","listArchiveCardsPopup-title":"Bu Listedeki Tüm Kartlar Taşınsın mı?","createLabelPopup-title":"Etiket Oluşturma","deleteLabelPopup-title":"Etiket Silinsin mi?","changePermissionsPopup-title":"Yetkileri Değiştirme","setLanguagePopup-title":"Dil Değiştir","cardAttachmentsPopup-title":"Şuradan Ekle...","attachmentDeletePopup-title":"Ek Dosya Silinsin Mi?"});
TAPi18n._registerServerTranslator("tr", namespace);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"zh-CN.i18n.json":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// i18n/zh-CN.i18n.json                                                                                              //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var _ = Package.underscore._,
    package_name = "project",
    namespace = "project";

if (package_name != "project") {
    namespace = TAPi18n.packages[package_name].namespace;
}
TAPi18n.languages_names["zh-CN"] = ["Chinese (China)","简体中文"];
if(_.isUndefined(TAPi18n.translations["zh-CN"])) {
  TAPi18n.translations["zh-CN"] = {};
}

if(_.isUndefined(TAPi18n.translations["zh-CN"][namespace])) {
  TAPi18n.translations["zh-CN"][namespace] = {};
}

_.extend(TAPi18n.translations["zh-CN"][namespace], {"account-details":"账户详情","actions":"动作","activity":"活动","activity-archived":"归档 %s","activity-created":"创建 %s","activity-added":"添加 %s 至 %s","activity-excluded":"排除 %s 从 %s","activity-moved":"将 %s 从 %s 移动到 %s","activity-sent":"发送 %s 至 %s","activity-joined":"关联 %s","activity-unjoined":"解除关联 %s","activity-removed":"移除 %s 从 %s 中","activity-attached":"附加 %s 至 %s","activity-on":"在 %s","this-board":"该看板","this-card":"该卡片","add":"添加","add-board":"添加一个新的看板","add-card":"添加新卡片","add-list":"添加列表","add-members":"添加成员","add-attachment":"添加附件","added":"添加","attached":"附加","admin":"管理员","admin-desc":"可以浏览并编辑卡片，移除成员，并且更改该看板的设置","already-have-account-question":"已有账户？","archive":"归档","archive-all":"归档所有","archive-list":"归档该列表","archive-title":"将该卡片从该看板中移除","archived-items":"归档项","back":"返回","bio":"介绍","board-list-btn-title":"浏览看板列表","board-not-found":"看板不存在","board-public-info":"该看板将 <strong>公开</strong>.","boards":"看板","bucket-example":"例如：\"目标清单\"","cancel":"取消","card-archived":"该卡片已被归档","card-comments-title":"该卡片拥有 %s 条评论","card-delete-notice":"删除操作不可恢复，你将会丢失该卡片的所有相关动作。","card-delete-pop":"所有动作将会从活动动态中被移除，您将无法重新开启该卡片。此操作不可逆，你可以进行归档卡片操作来将其从看板中移除并且保留活动。","attachment-delete-pop":"删除附件操作不可逆。","change-avatar":"更改头像","change-background":"更改背景","change-email":"更改邮箱","change-name-initials-bio":"更改姓名，昵称或简介","change-password":"更改密码","change-permissions":"更改权限","close":"关闭","close-board":"关闭看板","close-board-pop":"你可以通过点击头部的\"看板\"菜单，选择\"浏览已关闭看板\"，查找看板并且点击\"重开\"来重开看板。","close-sidebar-title":"关闭看板侧边栏","comment":"评论","comment-placeholder":"撰写评论","create":"创建","create-account":" 创建账户","create-new-account":"创建新账户","delete":"删除","delete-title":"删除该卡片以及与该卡片有关的任何历史记录，此操作不可逆。","description":"描述","edit":"编辑","edit-description":"编辑描述...","edit-profile":"编辑资料","email":"邮箱","email-or-username":"邮箱或用户名","email-placeholder":"例如 doc@frankenstein.com","filter-cards":"过滤卡片","filter-clear":"清除过滤.","filter-on":"过滤已开启","filter-on-desc":"你正在过滤该看板上的卡片，点此编辑过滤。","fullname":"全称","gloabal-search":"全局搜索","header-logo-title":"返回您的看板页","home":"首页","home-button":"免费注册","home-login":"或登录","in-list":"在列表中","info":"信息","joined":"关联","labels":"标签","labels-title":"更改该卡片上的标签","label-create":"创建新标签","label-delete-pop":"此操作不可逆，这将会删除该标签并清除它的历史记录。","label-default":"%s 标签 (默认)","attachments":"附件","attachment":"附件","last-admin-desc":"你不能更改角色，因为至少需要一名管理员。","language":"语言","leave-board":"离开看板","link-card":"关联至该卡片","list-move-cards":"移动该列表中的所有卡片...","list-archive-cards":"归档该列表中的所有卡片...","list-archive-cards-pop":"这将会从本看板中移除该列表中的所有卡片。如果需要浏览已归档的卡片并且将其恢复至看板，请点击\"菜单\">\"归档项\"","log-in":"登录","log-out":"登出","members":"成员","members-title":"在该卡片中添加或移除看板成员","menu":"菜单","modal-close-title":"关闭提示窗","my-boards":"我的看板","name":"名称","name-placeholder":"例如 弗兰克斯坦因博士","new-here-question":"初学者？","normal":"普通","normal-desc":"可以创建以及编辑卡片，无法更改设置。","no-boards":"无看板。","no-results":"无结果","notifications-title":"提示","optional":"可选","page-maybe-private":"本页面被设为私有. 您必须 <a href='%s'>登录</a>以浏览其中内容。","page-not-found":"页面不存在。","password":"密码","password-placeholder":"例如: ••••••••••••••••","private":"私有","private-desc":"该看板将被设为私有看板。只有该看板成员才可以进行查看和编辑。","profile":"资料","public":"公共","public-desc":"该看板将被公共。任何人均可通过链接查看，并且将对Google和其他搜索引擎开放，只有添加至该看板的成员才可进行编辑。","remove-from-board":"从该看板中移除...","remove-member":"移除成员","remove-member-from-card":"从该卡片中移除","remove-member-pop":"欲从 __boardTitle__ 中移除 __name__ (__username__) ? 该成员将会从该看板的所有卡片中被移除，他将会收到一条提醒。","add-cover":"添加封面","remove-cover":"移除封面","rename":"重命名","save":"保存","search":"搜索","computer":"从本机上传","download":"下载","search-member-desc":"通过名称或者邮箱地址搜索在LibreBoard中存在的会员，或者键入邮箱地址来邀请新成员。","search-title":"搜索看板、卡片、成员以及组织。","select-color":"选择颜色","send-to-board":"发送至看板","send-to-board-title":"发送该卡片并回到看板。","settings":"设置","share-and-more":"分享和更多...","share-and-more-title":"更多选项，包括分享、打印、导出及删除。","show-sidebar":"显示侧边栏","sign-up":"注册","star-board-title":"点此来标记该看板，它将会出现在您的看板列表顶部。","starred-boards":"已标记看板","starred-boards-description":"已标记看板将会出现在您的看板列表顶部。","click-to-star":"点此来标记该看板","click-to-unstar":"点此来去除该看板的标记","subscribe":"订阅","team":"团队","title":"标题","user-profile-not-found":"用户资料未找到","username":"用户名","warning-signup":"免费注册","cardLabelsPopup-title":"标签","cardMembersPopup-title":"成员","cardMorePopup-title":"更多","cardDeletePopup-title":"删除卡片？","boardChangeTitlePopup-title":"重命名看板","boardChangePermissionPopup-title":"更改可视级别","addMemberPopup-title":"成员","closeBoardPopup-title":"关闭看板？","removeMemberPopup-title":"删除成员？","createBoardPopup-title":"创建看板","listActionPopup-title":"列出动作","editLabelPopup-title":"更改标签","listMoveCardsPopup-title":"移动该列表的所有卡片","listArchiveCardsPopup-title":"归档该列表中的所有卡片？","createLabelPopup-title":"创建标签","deleteLabelPopup-title":"删除标签？","changePermissionsPopup-title":"更改权限","setLanguagePopup-title":"更改语言","cardAttachmentsPopup-title":"附加自...","attachmentDeletePopup-title":"删除附件？"});
TAPi18n._registerServerTranslator("zh-CN", namespace);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{"extensions":[".js",".json"]});
require("./lib/prototypes.js");
require("./lib/utils.js");
require("./server/publications/boards.js");
require("./server/publications/cards.js");
require("./server/publications/projects.js");
require("./server/publications/receipts.js");
require("./server/publications/users.js");
require("./collections/activities.js");
require("./collections/attachments.js");
require("./collections/boards.js");
require("./collections/cards.js");
require("./collections/lists.js");
require("./collections/projects.js");
require("./collections/receipts.js");
require("./collections/users.js");
require("./i18n/de.i18n.json");
require("./i18n/en.i18n.json");
require("./i18n/fr.i18n.json");
require("./i18n/ja.i18n.json");
require("./i18n/pt-BR.i18n.json");
require("./i18n/tr.i18n.json");
require("./i18n/zh-CN.i18n.json");
require("./server/accounts.js");
require("./server/cron.js");
require("./server/email.js");
require("./server/migrations.js");
require("./server/stripe.js");
require("./lib/main.js");
//# sourceMappingURL=app.js.map
